import posts from './posts';

export default {
  posts
};
