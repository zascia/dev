import os
import json
import model
from models import *
from config import *
from parser import logger
from slugify import slugify

part = 50
item_count = 1000
item_idx = 0


def scraper_worker(q):
    while not q.empty():
        product_id = q.get()
        delete_item(s, product_id)
        q.task_done()


def delete_sqlite_items(items):
    session = model.get_session()
    for item in items:
        item = session.query(model.Product).get(item)
        if item:
            session.delete(item)
    session.commit()


def delete_item(s, product_id):
    logger.info('[{}] deleted'.format(product_id))
    item = s.query(ProductItem).get(product_id)
    images = s.query(ProductImage).filter(
        ProductImage.product_id == product_id).all()
    if images:
        images_path = [image.image for image in images]
        if item:
            if item.image not in images_path:
                images_path.append(item.image)
        for image in images_path:
            try:
                os.remove(os.path.join(IMAGE_DIR, image))
            except OSError:
                pass
        for image in images:
            s.delete(image)
    item_desc = s.query(ProductDescription).get(product_id)
    if item_desc:
        s.delete(item_desc)
    store = s.query(ProductToStore).get(product_id)
    if store:
        s.delete(store)
    cats = s.query(ProductToCategory).filter(
        ProductToCategory.product_id == product_id).all()
    if cats:
        for cat in cats:
            s.delete(cat)
    options = s.query(ProductOption).filter(
        ProductOption.product_id == product_id).all()
    if options:
        for option in options:
            s.delete(option)
    sizes = s.query(ProductOptionValue).filter(
        ProductOptionValue.product_id == product_id).all()
    if sizes:
        for size in sizes:
            s.delete(size)
    rels = s.query(ProductRelated).filter(
        ProductRelated.product_id == product_id).all()
    if rels:
        for rel in rels:
            s.delete(rel)
    spec = s.query(ProductSpecial).filter(
        ProductSpecial.product_id == product_id).first()
    if spec:
        s.delete(spec)
    slug = s.query(Url_Alias).filter(
        Url_Alias.query == 'product_id={}'.format(product_id)).first()
    if slug:
        s.delete(slug)
    if item:
        s.delete(item)


if __name__ == '__main__':
    s = get_session()
    to_delete = []
    with open('data/parsed_ids.json') as f:
        parsed_ids = json.load(f)
        if not parsed_ids:
            logger.info('ERROR!!! Parsed ids are empty!')
            exit('ERROR! Parsed ids are empty!')
    while True:
        start, stop = item_count * item_idx, item_count * (item_idx + 1)
        items = s.query(ProductItem).slice(start, stop).all()
        if not items:
            break
        for item in items:
            if item.product_id not in parsed_ids:
                to_delete.append(item.product_id)
        if len(items) < item_count:
            break
        item_idx += 1
        logger.info('{} * {} items'.format(item_idx, item_count))
    logger.info('{} items to delete'.format(len(to_delete)))
    with open('data/to_delete.json', 'w') as f:
        f.write(json.dumps(to_delete))
    to_delete_parts = [to_delete[i:i + part]
                       for i in range(0, len(to_delete), part)]
    for chunk in to_delete_parts:
        for item in chunk:
            delete_item(s, item)
        s.commit()
    s.commit()
    logger.info('Delete all main database items')
    delete_sqlite_items(to_delete)
    logger.info('Delete all sqlite items')
    s.close()
    s = get_session()
    item_ids = [i.product_id for i in s.query(ProductItem).all()]
    print(len(item_ids))
    url_ids = []
    urls = s.query(Url_Alias).all()
    print(len(urls))
    for url in urls:
        if 'product_id' in url.query:
            id = int(url.query.replace('product_id=', ''))
            url_ids.append(id)
    print(len(url_ids))
    diff = set(item_ids) - set(url_ids)
    print(len(diff))
    for item_id in diff:
        item_desc = s.query(ProductDescription).get(item_id)
        if item_desc:
            slug = Url_Alias(**{
                'query': 'product_id={}'.format(item_id),
                'keyword': slugify(item_desc.name, to_lower=True)
            })
            s.add(slug)
    s.commit()
