from sqlalchemy import (
    Column, String, Integer, Text, DateTime,
    Date, Numeric, ForeignKey, create_engine
)
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.orm.scoping import scoped_session
import datetime
import config

Base = declarative_base()


class ProductItem(Base):
    __tablename__ = 'oc_product'
    product_id = Column(Integer, primary_key=True)
    model = Column(String(64))
    sku = Column(String(64))
    image = Column(String(255))
    price = Column(Numeric(precision=15, scale=4))
    date_added = Column(DateTime, default=datetime.datetime.now)
    date_modified = Column(DateTime, default=datetime.datetime.now,
                           onupdate=datetime.datetime.now)
    date_available = Column(Date, default=datetime.date.today)
    upc = Column(String, default='')
    ean = Column(String, default='')
    jan = Column(String, default='')
    isbn = Column(String, default='')
    mpn = Column(String, default='')
    quantity = Column(Integer, default=1)
    location = Column(String, default='')
    stock_status_id = Column(Integer, default=7)
    manufacturer_id = Column(Integer)
    tax_class_id = Column(Integer, default=0)
    status = Column(Integer, default=1)
    url = Column(String(64))


class ProductDescription(Base):
    __tablename__ = 'oc_product_description'
    product_id = Column(ForeignKey('oc_product'), primary_key=True)
    language_id = Column(Integer, default=1)
    name = Column(String(255))
    description = Column(Text)
    tag = Column(Text, default='')
    meta_title = Column(String(255))
    meta_description = Column(String(255))
    meta_keyword = Column(String(255), default='')


class ProductImage(Base):
    __tablename__ = 'oc_product_image'
    product_image_id = Column(Integer, primary_key=True)
    product_id = Column(ForeignKey('oc_product'))
    image = Column(String(255))


class ProductToStore(Base):
    __tablename__ = 'oc_product_to_store'
    product_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, default=0)


class Category(Base):
    __tablename__ = 'oc_category'
    category_id = Column(Integer, primary_key=True)
    image = Column(String(255), default='')
    parent_id = Column(Integer, default=0)
    top = Column(Integer, default=0)
    column = Column(Integer, default=1)
    status = Column(Integer, default=1)
    date_added = Column(DateTime, default=datetime.datetime.now)
    date_modified = Column(DateTime, default=datetime.datetime.now,
                           onupdate=datetime.datetime.now)


class CategoryDescription(Base):
    __tablename__ = 'oc_category_description'
    category_id = Column(ForeignKey('oc_category'), primary_key=True)
    language_id = Column(Integer, default=1)
    name = Column(String(255))
    description = Column(Text, default='')
    meta_title = Column(String(255), default='')
    meta_description = Column(String(255), default='')
    meta_keyword = Column(String(255), default='')


class CategoryToStore(Base):
    __tablename__ = 'oc_category_to_store'
    category_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, default=0)


class CategoryToLayout(Base):
    __tablename__ = 'oc_category_to_layout'
    category_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, default=0)
    layout_id = Column(Integer, default=0)


class CategoryPath(Base):
    __tablename__ = 'oc_category_path'
    category_id = Column(Integer, primary_key=True)
    path_id = Column(Integer, primary_key=True)
    level = Column(Integer, default=0)


class ProductToCategory(Base):
    __tablename__ = 'oc_product_to_category'
    product_id = Column(ForeignKey('oc_product'), primary_key=True)
    category_id = Column(ForeignKey('oc_category'), primary_key=True)


class OptionValue(Base):
    __tablename__ = 'oc_option_value'
    option_value_id = Column(Integer, primary_key=True)
    option_id = Column(Integer, default=11)
    image = Column(String(255), default='')
    sort_order = Column(Integer, default=0)


class OptionValueDescription(Base):
    __tablename__ = 'oc_option_value_description'
    option_value_id = Column(Integer, primary_key=True)
    language_id = Column(Integer, default=1)
    option_id = Column(Integer, default=11)
    name = Column(String(128))


class ProductOption(Base):
    __tablename__ = 'oc_product_option'
    product_option_id = Column(Integer, primary_key=True)
    product_id = Column(Integer)
    option_id = Column(Integer)
    value = Column(Text, default='')
    required = Column(Integer, default=1)


class ProductOptionValue(Base):
    __tablename__ = 'oc_product_option_value'
    product_option_value_id = Column(Integer, primary_key=True)
    product_option_id = Column(Integer)
    product_id = Column(Integer)
    option_id = Column(Integer)
    option_value_id = Column(Integer)
    quantity = Column(Integer, default=1)
    subtract = Column(Integer, default=1)
    price = Column(Numeric(precision=15, scale=4), default=0)
    price_prefix = Column(String(1), default='+')
    points = Column(Integer, default=0)
    points_prefix = Column(String(1), default='+')
    weight = Column(Numeric(precision=15, scale=8), default=0)
    weight_prefix = Column(String(1), default='+')


class Manufacturer(Base):
    __tablename__ = 'oc_manufacturer'
    manufacturer_id = Column(Integer, primary_key=True)
    name = Column(String(64))
    sort_order = Column(Integer, default=0)


class ManufacturerToStore(Base):
    __tablename__ = 'oc_manufacturer_to_store'
    manufacturer_id = Column(Integer, primary_key=True)
    store_id = Column(Integer, default=0)


class ProductRelated(Base):
    __tablename__ = 'oc_product_related'
    product_id = Column(ForeignKey('oc_product'), primary_key=True)
    related_id = Column(Integer, primary_key=True)


class ProductSpecial(Base):
    __tablename__ = 'oc_product_special'
    product_special_id = Column(Integer, primary_key=True)
    product_id = Column(ForeignKey('oc_product'))
    customer_group_id = Column(Integer, default=1)
    price = Column(Numeric(precision=15, scale=4))
    date_start = Column(Date, default=datetime.date(2000, 1, 1))
    date_end = Column(Date, default=datetime.date(2100, 1, 1))


class Option(Base):
    __tablename__ = 'oc_option'
    option_id = Column(Integer, primary_key=True)
    type = Column(String(32), default='select')
    sort_order = Column(Integer, default=0)


class Option_Description(Base):
    __tablename__ = 'oc_option_description'
    option_id = Column(Integer, primary_key=True)
    language_id = Column(Integer, default=1)
    name = Column(String(128))


class Url_Alias(Base):
    __tablename__ = 'oc_url_alias'
    url_alias_id = Column(Integer, primary_key=True)
    query = Column(String(255))
    keyword = Column(String(255))


def get_session():
    engine = create_engine(config.DB_URI, pool_size=5, max_overflow=20)
    Session = sessionmaker(engine)
    return scoped_session(Session)


if __name__ == '__main__':
    s = get_session()
    s.close()
