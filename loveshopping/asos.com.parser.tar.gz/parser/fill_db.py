import sys
import json
from models import *
from parser import logger
from slugify import slugify
from queue import Queue
from threading import Thread
from delete_items import delete_item
from sqlalchemy.sql import exists
from sqlalchemy.exc import OperationalError, IntegrityError
meta = 'Купить {} на ASOS. Открой мир моды онлайн.'


def scraper_worker(q):
    while not q.empty():
        item = q.get()
        write_item_to_db(item)
        q.task_done()


def create_item(item, manufactor, sizes, color):
    new_item = ProductItem(**{
        'product_id': item['id'],
        'model': item['product_code'],
        'sku': item['product_code'],
        'image': item['images'][0][1],
        'price': item['current_price'],
        'url': item['url'],
        'manufacturer_id': manufactor})
    session.add(new_item)
    new_desc = ProductDescription(**{
        'product_id': item['id'],
        'name': item['title'],
        'description': '{} <br> {}'.format(item['description'], item['about'] or ''),
        'meta_description': meta.format(item['title'])[:254],
        'meta_title': '{} at asos.com'.format(item['title'])})
    session.add(new_desc)
    for image in item['images'][1:]:
        d = {'image': image[1], 'product_id': item['id']}
        new_image = ProductImage(**d)
        session.add(new_image)
    product_option = ProductOption(**{'product_id': item['id'],
                                      'option_id': 11})
    session.add(product_option)
    session.flush()
    for size in sizes:
        new_option_desc = ProductOptionValue(**{
            'product_option_id': product_option.product_option_id,
            'product_id': item['id'],
            'option_id': 11,
            'option_value_id': size})
        session.add(new_option_desc)
    color_prod_option = ProductOption(**{'product_id': item['id'],
                                         'option_id': 5})
    session.add(color_prod_option)
    session.flush()
    new_prod_color = ProductOptionValue(**{
        'product_option_id': color_prod_option.product_option_id,
        'product_id': item['id'],
        'option_id': 5,
        'option_value_id': color})
    session.add(new_prod_color)
    for rel in item['related']:
        p = session.query(ProductRelated).filter(
            ProductRelated.product_id == item['id'],
            ProductRelated.related_id == rel
        ).first()
        if not p:
            new_rel = ProductRelated(**{'product_id': item['id'], 'related_id': rel})
            session.add(new_rel)
    if item['previous_price']:
        db_special = ProductSpecial(**{'product_id': item['id'],
                                       'price': item['previous_price']})
        session.add(db_special)
    slug = Url_Alias(**{
        'query': 'product_id={}'.format(item['id']),
        'keyword': slugify(
            item['title'] + str(item['product_code']), to_lower=True
        )
    })
    session.add(slug)
    handle_categories(item['id'], item['categories'])
    ps = session.query(ProductToStore).get(item['id'])
    if not ps:
        product_store = ProductToStore(**{'product_id': item['id']})
        session.add(product_store)
    session.commit()
    added_items.add(item['id'])
    logger.info('[{}/{}] item {} has been added, cats — {}'.format(counter, overall, item['id'], item['categories']))


def handle_manufacturer(brand):
    manufactor = session.query(Manufacturer).filter(
        Manufacturer.name == brand).first()
    if not manufactor:
        manufactor = Manufacturer(**{'name': brand})
        session.add(manufactor)
        session.flush()
        manufactor_store_db = session.query(ManufacturerToStore).get(
            manufactor.manufacturer_id)
        if not manufactor_store_db:
            manufactor_store = ManufacturerToStore(**{
                'manufacturer_id': manufactor.manufacturer_id})
            session.add(manufactor_store)
    return manufactor.manufacturer_id


def handle_related(id, related):
    db_related = session.query(ProductRelated).filter(
        ProductRelated.product_id == id).all()
    for rel in db_related:
        if rel.related_id not in related:
            session.delete(rel)
        if rel.related_id in related:
            related.remove(rel.related_id)
    for rel in related:
        new_rel = ProductRelated(**{'product_id': id,
                                    'related_id': rel})
        session.add(new_rel)


def handle_sizes(sizes):
    size_ids = []
    for size in sizes:
        db_size = session.query(OptionValueDescription).filter(
            OptionValueDescription.name == size).first()
        if not db_size:
            option_value = OptionValue()
            session.add(option_value)
            session.flush()
            db_size = OptionValueDescription(**{
                'option_value_id': option_value.option_value_id,
                'name': size})
            session.add(db_size)
        size_ids.append(db_size.option_value_id)
    return size_ids


def handle_color(color):
    db_color = session.query(OptionValueDescription).filter(
        OptionValueDescription.name == color).first()
    if not db_color:
        opt_val = OptionValue(**{'option_id': 5})
        session.add(opt_val)
        session.flush()
        db_color = OptionValueDescription(**{
            'option_value_id': opt_val.option_value_id,
            'name': color, 'option_id': 5})
        session.add(db_color)
    return db_color.option_value_id


def handle_images(images):
    db_images = session.query(ProductImage).filter(
        ProductImage.product_id == item['id']).all()
    images = [i[1] for i in item['images']]
    for image in db_images:
        if image.image not in images:
            session.delete(image)
        if image.image in images:
            images.remove(image.image)
    if images:
        for image in images:
            new_image = ProductImage(**{'product_id': item['id'],
                                        'image': image})
            session.add(new_image)


def handle_categories(id, cats):
    # Remove extra categories first:
    cats_to_delete = session.query(ProductToCategory).filter(
        ProductToCategory.product_id == id,
        ProductToCategory.category_id.notin_(cats)
    )
    cats_to_delete.delete(synchronize_session=False)
    raw_cats = session.query(ProductToCategory).filter(
        ProductToCategory.product_id == id).values('category_id')
    db_cats = {v for (v,) in raw_cats}
    cats = set(cats) - db_cats
    # db_cats = session.query(ProductToCategory).filter(
    #     ProductToCategory.product_id == id).all()
    # for cat in db_cats:
    #     if cat.category_id not in cats:
    #         session.delete(cat)
    #     if cat.category_id in cats:
    #         cats.remove(cat.category_id)
    # if cats:
    for cat in cats:
        new_cat = ProductToCategory(**{
            'product_id': id,
            'category_id': cat
        })
        session.add(new_cat)


def write_item_to_db(item):
    global counter
    counter += 1
    manufactor = handle_manufacturer(item['brand'])
    sizes = handle_sizes(item['sizes'])
    color = handle_color(item['color'])
    db_item = session.query(ProductItem).get(item['id'])
    if db_item:
        handle_related(item['id'], item['related'])
        db_item.price = item['current_price']
        session.add(db_item)
        db_special = session.query(ProductSpecial).filter(
            ProductSpecial.product_id == item['id']).first()
        if db_special:
            if item['previous_price']:
                db_special.price = item['previous_price']
                session.add(db_special)
            else:
                session.delete(db_special)
        else:
            if item['previous_price']:
                db_special = ProductSpecial(**{
                    'product_id': item['id'],
                    'price': item['previous_price']
                })
                session.add(db_special)
        handle_categories(item['id'], item['categories'])
        try:
            product_options = session.query(ProductOptionValue).filter(
                ProductOptionValue.product_id == item['id'],
                ProductOptionValue.option_id == 11).all()
            for option in product_options:
                if option.option_value_id not in sizes:
                    session.delete(option)
                if option.option_value_id in sizes:
                    sizes.remove(option.option_value_id)
            product_option = session.query(ProductOption).filter(
                ProductOption.product_id == item['id'],
                ProductOption.option_id == 11).first()
            for size in sizes:
                new_option_desc = ProductOptionValue(**{
                    'product_option_id': product_option.product_option_id,
                    'product_id': item['id'],
                    'option_id': 11,
                    'option_value_id': size})
                session.add(new_option_desc)
            product_color = session.query(ProductOptionValue).filter(
                ProductOptionValue.product_id == item['id'],
                ProductOptionValue.option_id == 5).first()
            if product_color:
                if product_color.option_value_id != color:
                    product_color.option_value_id = color
                    session.add(product_color)
            else:
                color_prod_option = session.query(ProductOption).filter(
                    ProductOption.product_id == item['id'],
                    ProductOption.option_id == 5).first()
                new_prod_color = ProductOptionValue(**{
                    'product_option_id': color_prod_option.product_option_id,
                    'product_id': item['id'],
                    'option_id': 5,
                    'option_value_id': color})
                session.add(new_prod_color)
        except AttributeError:
            logger.info('Delete item {} without options'.format(item['id']))
            delete_item(session, item['id'])
            create_item(item, manufactor, sizes, color)
        session.commit()
        logger.info('[{}/{}] item {} has been updated'.format(counter, overall, item['id']))
    else:
        try:
            create_item(item, manufactor, sizes, color)
        except OperationalError:
            session.rollback()
            delete_item(session, item['id'])
            session.commit()
        except IntegrityError:
            session.rollback()
            delete_item(session, item['id'])
            session.commit()


if __name__ == '__main__':
    added_items = set()
    session = get_session()
    counter = 0
    file = sys.argv[1]
    with open(file) as f:
        json_data = json.load(f)
    overall = len(json_data)
    logger.info('Fill {}, rows count — {}'.format(file, overall))
    q = Queue()
    [q.put(item) for item in json_data]
    for i in range(10):
        t = Thread(target=scraper_worker, args=(q,))
        t.start()
    q.join()
    session.commit()
    logger.info('Done {}'.format(file))
    with open('data/added_items.txt', 'a') as file:
        file.write('\n'.join([str(id) for id in added_items]) + '\n')
