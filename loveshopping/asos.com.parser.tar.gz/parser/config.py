IMAGE_DIR = '/var/www/html/image'
IMAGE_PATH = 'catalog/{}/{}.jpeg'
LOG_FILENAME = 'log/asos_parser.log'
DB_URI = 'mysql+mysqldb://root:o2GLB58MqvLYbrem@localhost/lovesh_db?charset=utf8'
SQLITE_URI = 'sqlite:///data/products.db'
LOG_EXC = False