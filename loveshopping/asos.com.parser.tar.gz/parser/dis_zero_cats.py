import json
from models import *
s = get_session()

with open('data/products_to_category.json') as f:
    products_to_category = json.load(f)
with open('data/parsed_ids.json') as f:
    parsed_ids = json.load(f)

for category in products_to_category:
    for id in products_to_category[category]:
        if id in parsed_ids:
            product = s.query(ProductToCategory).filter(
                ProductToCategory.product_id == id,
                ProductToCategory.category_id == category).first()
            if not product:
                new = ProductToCategory(**{'product_id': id,
                                           'category_id': category})
                s.add(new)
s.commit()

all_cats = s.query(Category).all()
for cat in all_cats:
    cat_with_prod = s.query(ProductToCategory).filter(
        ProductToCategory.category_id == cat.category_id).first()
    is_parent = s.query(Category).filter(
        Category.parent_id == cat.category_id).first()
    if cat_with_prod:
        cat.status = 1
    elif is_parent:
        cat.status = 1
    else:
        cat.status = 0
    s.add(cat)
s.commit()
