import json
import config
import logging
import requests
from time import sleep
from models import get_session, CategoryDescription


n = 'navigation'
parsed_ids = []

logging.basicConfig(
    format='%(asctime)s %(name)s [%(levelname)s]: %(message)s',
    datefmt='%b %d %H:%M:%S',
    level=logging.INFO,
    filename=config.LOG_FILENAME)
logger = logging.getLogger('asos_parser')

user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36'
requests_session = requests.Session()
headers = {
    'User-Agent': user_agent,
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
    'Accept-Encoding': 'gzip, deflate, br',
    'Accept-Language': 'en-US,en;q=0.9,ru;q=0.8,uk;q=0.7,de;q=0.6',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    'Cache-Control': 'max-age=0',
}
requests_session.headers.update(headers)


def get_with_errors(url, attempts=3, cookies=None):
    while attempts:
        try:
            return requests_session.get(url, timeout=4)
        except (requests.ConnectionError, requests.RequestException):
            attempts -= 1
            logger.info(
                'Got exception. {} with {} attempts'.format(
                    url, attempts), exc_info=config.LOG_EXC
            )
            sleep(3)
            continue


def get_ids(search_id):
    item_ids = []
    offset = 0
    errors = 0
    while True:
        logger.info('Id count is {}'.format(len(item_ids)))
        r = get_with_errors(
            config.SEARCH_LINK.format(search_id, offset))
        offset += 204
        try:
            r = r.json()
            new_ids = [item['id'] for item in r['products']]
        except Exception:
            errors += 1
            logger.info('get_ids exception. offset is: {}, len ids: {}'.format(
                offset, len(item_ids)), exc_info=config.LOG_EXC)
            logger.info('get_ids exception. errors: {}'.format(errors))
            new_ids = []
            if errors > 5:
                break
        item_ids.extend(new_ids)
        try:
            if offset > r['itemCount']:
                break
        except Exception:
            logger.info('response itemcount exception', exc_info=config.LOG_EXC)
            errors += 1
            if errors > 5:
                break
    return set(item_ids)


if __name__ == '__main__':
    logging.getLogger('requests').setLevel(logging.CRITICAL)
    products_to_category = {}
    with open('data/product_categories.json') as f:
        product_categories = json.load(f)
    with open('data/full_product_categories.json') as f:
        full_product_categories = json.load(f)
    session = get_session()
    cats = session.query(CategoryDescription).all()
    logger.info('Got all categories. Parsing started')
    for cat in full_product_categories:
        logger_counter = 0
        logger.info('Parse category: {} with id — {}'.format(
            cat['name'], cat['id'])
        )
        all_ids = get_ids(cat['id'])
        if cat['id'] in product_categories:
            products_to_category[cat['id']] = list(all_ids)
        logger.info('Overall ids in {} is {}'.format(cat['name'], len(all_ids)))
        ids = [id for id in all_ids if id not in parsed_ids]
        logger.info('Overall unique ids — {} removed ids count — {}'.format(
            len(ids), len(all_ids) - len(ids)))
        cat_items = []
    logger.info('Parsing done. Parsed ids count — {}'.format(len(parsed_ids)))
    with open('data/parsed_ids.json', 'w') as f:
        f.write(json.dumps(parsed_ids))
    with open('data/products_to_category.json', 'w') as f:
        f.write(json.dumps(products_to_category))
