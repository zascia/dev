#!/bin/bash

parser_dir="/root/i-pr_asos_parser/parser"
exec &>> $parser_dir/log/parser.log
today=`date +%F_%H_%M`
echo "`date` Parsing start"
python=`which python3`
cd $parser_dir
echo "`date` Start download image, fill db"
touch jsons_to_delete.txt
for file in result/*.json; do
    [ -f "$file" ] || continue
    echo `date` $file
    $python save_images.py $file
    echo "`date` save_images $file: $?"
    $python fill_db.py $file
    echo "`date` filling_db  $file: $?"
    echo "$file" >> jsons_to_delete.txt
    echo " " >> jsons_to_delete.txt
done
echo "`date` Done with filled db, download images"
echo "`date` Stoping, all done"
echo "`date` Done!"
