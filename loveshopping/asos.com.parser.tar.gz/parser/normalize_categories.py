import sys
import json
from models import get_session, ProductToCategory


def handle_categories(id, cats):
    cats_to_delete = session.query(ProductToCategory).filter(
        ProductToCategory.product_id == id,
        ProductToCategory.category_id.notin_(cats)
    )
    cats_to_delete.delete(synchronize_session=False)
    raw_cats = session.query(ProductToCategory).filter(
        ProductToCategory.product_id == id).values('category_id')
    db_cats = {v for (v,) in raw_cats}
    cats = set(cats) - db_cats
    for cat in cats:
        new_cat = ProductToCategory(**{
            'product_id': id,
            'category_id': cat
        })
        session.add(new_cat)


if __name__ == '__main__':
    session = get_session()
    with open(sys.argv[1]) as file:
        items = json.load(file)
    for item in items:
        handle_categories(item['id'], item['categories'])
    session.commit()
