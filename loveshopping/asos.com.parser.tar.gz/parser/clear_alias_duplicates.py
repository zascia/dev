from collections import defaultdict
from models import get_session, Url_Alias


s = get_session()

aliases = s.query(Url_Alias).all()
aliases_dict = defaultdict(list)
for alias in aliases:
    aliases_dict[alias.query].append(alias)
duplicates = [value[1:] for key, value in aliases_dict.items() if len(value) > 1]
dups = [a for tup in duplicates for a in tup]
for a in dups:
    s.delete(a)
s.commit()

