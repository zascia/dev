import sys
import json
import config
import requests
from models import *
from slugify import slugify
from bs4 import BeautifulSoup
from parser import get_with_errors, logger
n = 'navigation'

user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.81 Safari/537.36'
requests_session = requests.Session()
requests_session.headers.update({'User-Agent': user_agent})


def get_description(soup):
    desc = soup.find('p', class_='copy')
    if desc:
        return desc.text
    desc = soup.find('div', class_='brand-logo-text')
    if desc:
        return desc.find('p').text
    desc = soup.find('div', class_='brand-text')
    if desc:
        return desc.find('span').text
    if not desc and 'sale' in cat['name']:
        desc = 'РАСПРОДАЖА'
        return desc
    return cat['name']


def get_cats(parent, level=0, ancestors=None):
    if not ancestors:
        ancestors = []
    level += 1
    ancestors.append(parent['actualId'])
    for item in parent[n]:
        while len(ancestors) > level:
            ancestors.pop()
        all_cats.append({'path': ancestors + [item['actualId']],
                         'id': item['actualId'],
                         'url': item['linkUrl'],
                         'name': item['name'],
                         'type': item['type']})
        if item[n]:
            get_cats(item, level=level, ancestors=ancestors)


def add_category(id, parent_id, name, description, top=False):
    new_cat = Category(**{'category_id': id, 'parent_id': parent_id})
    if top:
        new_cat.top = 1
    s.add(new_cat)
    new_cat_desc = CategoryDescription(**{
        'category_id': id, 'name': name,
        'meta_title': name, 'description': description})
    s.add(new_cat_desc)
    new_cat_store = CategoryToStore(**{'category_id': id})
    s.add(new_cat_store)
    new_layout = CategoryToLayout(**{'category_id': id})
    s.add(new_layout)
    new_slug = Url_Alias(**{'query': 'category_id={}'.format(id),
                            'keyword': '{}_{}'.format(
                                slugify(name, to_lower=True), id)})
    s.add(new_slug)


def add_cat_path(cats):
    id = cats[-1]
    for cat in cats:
        new_path = CategoryPath(**{
            'category_id': id,
            'path_id': cat,
            'level': cats.index(cat)})
        s.add(new_path)


if __name__ == '__main__':
    logger.info('Start category parser')
    s = get_session()
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as file:
            cat_json = json.load(file)
    else:
        cat_json = get_with_errors(config.ALL_CATS).json()
    women_cat = s.query(Category).get(1000)
    if not women_cat:
        add_category(1000, 0, 'ЖЕНСКОЕ', 'ЖЕНСКОЕ', top=True)
        woman_path = CategoryPath(**{
            'category_id': 1000, 'path_id': 1000, 'level': 0})
        s.add(woman_path)
    men_cat = s.query(Category).get(1001)
    if not men_cat:
        add_category(1001, 0, 'МУЖСКОЕ', 'МУЖСКОЕ', top=True)
        man_path = CategoryPath(**{
            'category_id': 1001, 'path_id': 1001, 'level': 0})
        s.add(man_path)
    s.commit()

    woman_cats = cat_json[n][n][0]
    man_cats = cat_json[n][n][1]
    all_cats = []
    get_cats(man_cats)
    get_cats(woman_cats)
    product_categories = []
    for cat in all_cats:
        if cat['type'] == 'ProductCategory':
            product_categories.append(cat['id'])
        c = s.query(Category).get(cat['id'])
        if not c:
            r = get_with_errors(cat['url'])
            soup = BeautifulSoup(r.text, 'lxml')
            desc = get_description(soup)
            logger.info('description: {}'.format(desc))
            add_category(cat['id'], cat['path'][-2], cat['name'], desc)
            add_cat_path(cat['path'])
    s.commit()
    with open('data/product_categories.json', 'w') as f:
        f.write(json.dumps(product_categories))
    logger.info('Parse category finish')
