#!/bin/bash

parser_dir="/root/i-pr_asos_parser/parser"
exec &>> $parser_dir/log/parser.log
today=`date +%F_%H_%M`
echo "`date` Parsing start"
python=`which python3`
echo > data/added_items.txt
cd $parser_dir
$python handle_cats.py data/raw_categories.json
$python parser.py
echo "`date` Parsing done"
echo "`date` Start save images"
for file in result/*.json; do
    $python save_images.py $file
done
echo "`date` Start save db items"
for file in result/*.json; do
    $python fill_db.py $file
done
sleep 10m
for file in result/*.json; do
    $python normalize_categories.py $file
done
echo "`date` Done with filled db, download images"
echo "`date` Start delete yesterdays items"
$python delete_items.py
echo "`date` Delete all items"
echo "`date` Disabling empty categories"
$python dis_zero_cats.py
echo "`date` Stoping, all done"
/bin/tar -cf archive/$today.tar.gz -I pigz result/
echo "Archive $today.tar.gz was created"
/bin/rm -fv result/*.json
echo "`date` Done!"

