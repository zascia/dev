from config import SQLITE_URI
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer, create_engine

Base = declarative_base()


class Product(Base):
    __tablename__ = 'products'
    id = Column(Integer, primary_key=True)
    md5 = Column(String(32))


def get_session():
    engine = create_engine(SQLITE_URI)
    Session = sessionmaker(engine)
    return Session()


if __name__ == '__main__':
    engine = create_engine(SQLITE_URI)
    Base.metadata.create_all(engine)
