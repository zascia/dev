import os
import sys
import json
import requests
from time import sleep
from queue import Queue
from threading import Thread
from config import IMAGE_DIR, PARAMS
from shutil import copyfileobj


def save_image(image, attempts=3):
    while attempts:
        try:
            r = requests.get('http://' + image[0] + PARAMS, stream=True)
        except (requests.ConnectionError, requests.RequestException):
            attempts -= 1
            sleep(3)
            continue
        with open(os.path.join(IMAGE_DIR, image[1]), 'wb') as f:
            copyfileobj(r.raw, f)
        break


def make_images_list(data):
    images = []
    for item in data:
        image_dir = os.path.dirname(
            os.path.join(IMAGE_DIR, item['images'][0][1]))
        if not os.path.exists(image_dir):
            os.makedirs(image_dir)
        for image in item['images']:
            if not os.path.exists(os.path.join(IMAGE_DIR, image[1])):
                images.append(image)
    return images


def scraper_worker(q):
    while not q.empty():
        image = q.get()
        save_image(image)
        q.task_done()


if __name__ == '__main__':
    file = sys.argv[1]
    with open(file, 'r') as f:
        data = json.load(f)
    images = make_images_list(data)
    q = Queue()
    [q.put(image) for image in images]
    for i in range(10):
        t = Thread(target=scraper_worker, args=(q,))
        t.start()
    q.join()
