var captureplus_api_key = 'HY94-HY76-FM99-YW99';
var postal_code_timer;
var postal_code_value = '';
var manual_address_entry = false;

var CapturePlusStart = null;
var CapturePlusCounter = 0;
var CapturePlusError = 0;

var manual_address = $('#manual-address-input').detach();
$('#address-finder-section').show();

$(document).ready(function() {
	postal_code_value = $('textarea[name=address_finder]').val();
});

$(document).on('keyup', 'input[name=postcode_finder]', function(event) {
	if ( ( event.keyCode === 10 || event.keyCode === 13 ) && $(this).val() != '' ) {
		event.preventDefault();
		event.stopPropagation();
		
		/*
		if ( typeof validation[ $(this).attr('name') ] !== 'undefined' ) {
                        var validation_response = validate_field($(this), validation);
                        if ( $(this).closest('.validation-display').hasClass('error') ) {
                        	update_element_valid_state($(this), validation_response, true, true);
			}
		}
		*/
	
		$('button[class*="search-for-address"]').click();
	}
});

$(document).on('keyup keypress', 'input[type=submit]', function(e) {
	if ( ( e.keyCode === 10 || e.keyCode === 13 ) && ! $('input[name=postcode_finder]').is(':focus') ) { 
		e.preventDefault();
		return false;
	}
});

$(document).on('keydown', 'textarea[name=address_finder]', function(event) {
	if ( event.keyCode === 9 ) {
		event.stopPropagation();
                $('.address_finder_dropdown').hide();
                $('input[name=address]').val( $('textarea[name=address_finder]').val() );
		return true;
	}
	else if ( event.keyCode === 10 || event.keyCode === 13 ) {
		event.preventDefault();
		return false;
	}
});

$(document).on('change input paste', 'textarea[name=address_finder]', function(event, fake_click) {

	if ( typeof fake_click === 'undefined' ) {
		fake_click = false;
	}

	if ( fake_click == true ) {
		return;
	}

	console.log('event.type: ' + event.type);

	var postal_code = $(this).val();
	if ( postal_code != '' && postal_code_value != postal_code ) {

		postal_code_value = postal_code;
		clearTimeout(postal_code_timer);
		var that = this;
	
		postal_code_timer = setTimeout(function() {
			console.log('Searching postal_code: ' + postal_code);
			CapturePlus_Interactive_Find_v2_10(postal_code, null);
		}, 200);
	
	}

	resizeForm();

});

$(document).on('click', '.search-for-address', function(event) {
	CapturePlusCounter = 0;
	CapturePlusError = 0;
	var postal_input = $('input[name="postcode_finder"]');
	var postal_code = $('input[name=postcode_finder]').val();
	
	//var postal_regex = /^(([gG][iI][rR] {0,}0[aA]{2})|((([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y]?[0-9][0-9]?)|(([a-pr-uwyzA-PR-UWYZ][0-9][a-hjkstuwA-HJKSTUW])|([a-pr-uwyzA-PR-UWYZ][a-hk-yA-HK-Y][0-9][abehmnprv-yABEHMNPRV-Y]))) {0,}[0-9][abd-hjlnp-uw-zABD-HJLNP-UW-Z]{2}))$/;
	var postal_regex = /^\s*([a-z][0-9][a-z]\s*[0-9][a-z][0-9])\s*/i;/* /^\s*([A-Z][A-Z]?[0-9][A-Z0-9]? *[0-9][ABDEFGHJLNPQRSTUWXYZ]{2})\s*$/i; */
	
	var postal_code_stripped = postal_code.replace(/[^a-z0-9]/ig, '').toUpperCase();
	
	postal_code_stripped = reprocess_canada_postal_code(postal_code_stripped);
	
	postal_code_stripped = [postal_code_stripped.slice(0, 3), ' ', postal_code_stripped.slice(3)].join('');
	
	var postal_match = postal_code_stripped.match(postal_regex);
	$('.address-picker-container').slideUp();
//console.log('matched postal: [' + postal_match[1] + ']');
	if ( postal_match != null && postal_code_stripped == postal_match[0] ) {
		postal_input
			.addClass('success')
			.removeClass('error')
			.val(postal_match[1])
			.parent()
			.removeClass('field-success-icon')
			.addClass('loading-spinner-postal');
		$('.error-postcode_finder').hide();
		CapturePlus_Interactive_Find_by_postal_code_v2_10(postal_match[1], null, postal_input.parent());
	}
	else {
		postal_input
			.removeClass('success')
			.addClass('error')
			.parent()
			.removeClass('field-success-icon')
			.removeClass('loading-spinner-postal');
		$('.error-postcode_finder').html('Please enter a valid postal code').show();
	}

});

$(document).on('change', 'select.address-picker-select', function(e) {
	var selected_row = $(this).find('option:selected');

	if ( selected_row.hasClass('address_finder_select_row') ) {
		var row_data = $(this).find('option:selected').data('row_data');
		console.log('Text of selected address: ' + row_data['Next']);

		if ( row_data['Next'] == 'Retrieve' ) {
			CapturePlus_Interactive_Retrieve_v2_10Begin(row_data['Id'], 'postal_code_finder_callback');
		}
	
	}
	else if ( selected_row.hasClass('address-not-found') ) {
		// Do manual address entry here
		var entered_postal_code = $('input[name=postcode_finder]').val();
		
		PostalIPLookup(entered_postal_code, function(postal_lookup_result) {
			var lookup_city = '';
			var lookup_province = '';
			if ( typeof postal_lookup_result['city'] !== 'undefined' ) {
				lookup_city = postal_lookup_result['city']
			}
			if ( typeof postal_lookup_result['province'] !== 'undefined' ) {
				lookup_province = postal_lookup_result['province']
			}
			
			show_manual_address_entry('', entered_postal_code, lookup_city, lookup_province);
		});
		//show_manual_address_entry('', entered_postal_code);
	}
});

function show_manual_address_entry(error_message, postal_code, city, province) {
	if ( error_message != '' ) {
		//something here about an explanation
	}
	
	$('.label-address-lookup').addClass('hidden');
	$('.label-postal-lookup').addClass('hidden');
	$('.label-manual-entry').removeClass('hidden');
	
	$('#address-finder-section').detach();
	$('input[type=hidden][name=address]').detach();
	$('input[type=hidden][name=postal_code]').detach();
	$('input[type=hidden][name=city]').detach();
	$('input[type=hidden][name=province]').detach();
	if ( $('.where-do-you-live').length ) {
		manual_address.appendTo('.where-do-you-live');
	}
	else {
		$('.btn.postcode-continue.disabled').removeClass('disabled');
		manual_address.appendTo('.address-input');
		jcf.replace( $('.address-input select') );
		$('html, body').scrollTop(0);
	}
	
	if ( postal_code !== '' ) {
		$('input[name=postal_code]').val(postal_code);
	}
	if ( city !== '' ) {
		$('input[name=city]').val(city);
	}
	if ( province !== '' ) {
		$('select[name=province]').val(province).trigger('change');
	}
}

$(document).on('click', '', function(event) {
	if ( $(event.target).closest('textarea[name=address_finder], .address_finder_dropdown').length == 0 ) {
		if ( ! $('input[name=address]').hasClass('address-finder-ignore') && $('.address_finder_dropdown').is(':visible') ) {
			$('.address_finder_dropdown').hide();
			$('input[name=address]').val( $('textarea[name=address_finder]').val() );
		}
	}
});

$(document).on('click', '.change_address', function() {
	var postal_code_field = $('textarea[name=address_finder]');
	CapturePlus_Interactive_Find_v2_10(postal_code_field.val(), null);
	//$('.address_display').hide();
	//$('textarea[name=address_finder]').show();
	postal_code_field.focus();
});

$(document).on('click', '.address_finder_my_address', function() {
	$('.address_finder_dropdown').hide();
	$('input[name=address]').val( $('textarea[name=address_finder]').val() );
	//$('.address_display').text( $('textarea[name=address_finder]').val() );
	//$('textarea[name=address_finder]').hide();
	//$('.address_display').show();
	//$('.change_address').show();
});

$(document).on('click', '.address_finder_error', function() {
	console.log('got to no usable address');
	show_manual_address_entry('', '', '', '');
	$('.address_finder_dropdown').hide();
	/*
	manual_address_entry = true;
	$('.address_finder_dropdown').hide();
	var $parent_div = $('#address_finder').closest('.error-outer-container');
	$('#address_finder')
		.removeClass('success')
		.find('.success-icon').hide();
	$parent_div
		.removeClass('field-success-icon')
		.find('.field-error-message')
		.removeClass('error-address_finder')
		.addClass('error-address');
	$('#address_finder').remove();
	$parent_div.prepend('<textarea id="address" name="address" placeholder="Address" autocomplete="off"></textarea>');
	$('input[name=address]').remove();
	*/
});

function fix_width() {

	var maxWidth = Math.max.apply( null, $('.address_finder_postal_text').map( function () {
		return $( this ).outerWidth( true );
	}).get() );

	$('.address_finder_postal_text').css('width', maxWidth);
}


function address_row_click(clicked_row) {

	clearTimeout(postal_code_timer);

	var row_data = clicked_row.data;

	$('.address_finder_dropdown .scroller').html(''); //<img src="/img/2.gif">

	console.log(clicked_row);

	if ( row_data['Next'] == 'Find' ) {
		$('textarea[name=address_finder]').val( row_data['Text'] );
		resizeForm();
		CapturePlus_Interactive_Find_v2_10(row_data['Text'], row_data['Id']);
		console.log('updating postal code to: ' + row_data['Text']);
	}
	else if ( row_data['Next'] == "Retrieve" ) {
		$('.address_finder_dropdown').hide();
		CapturePlus_Interactive_Retrieve_v2_10Begin(row_data['Id'])
	}
}

function update_address(address_result) {

	console.log(address_result);
	var address_values = [];
	var address_db = [];
	for ( var i = 1; i <= 5; i++ ) {
		if ( address_result[ 'Line' + i ] != '' ) {
			address_values.push(address_result[ 'Line' + i ]);
			address_db.push(address_result[ 'Line' + i ]);
		}
		else {
			break;
		}
	}
	
	if ( address_result['City'] != '' ) {
		address_values.push(address_result['City']);
	}
	if ( address_result['ProvinceName'] != '' ) {
		address_values.push(address_result['ProvinceName']);
	}
	address_values.push(address_result['PostalCode']);
	
	//$('.address_display').text( address_values.join(', ') );
	$('textarea[name=address_finder]').val( address_values.join(', ') );
	resizeForm();
	$('input[name=address]').val( address_db.join(', ') );
	$('input[name=city]').val( address_result['City'] );
	$('input[name=province]').val( address_result['ProvinceCode'] );
	//$('input[name=country]').val( address_result['CountryName'] );
	$('.address_display').addClass('adress_display_show');
	$('input[name=postal_code]').val( address_result['PostalCode'] );
	$('textarea[name=address_finder]').trigger('change', [true]);
	if ( window.update_element_valid_state ) {
		update_element_valid_state($('textarea[name=address_finder]'), {'success': true}, true, false);
	}
	//$('.change_address').show();
	//$('.address_display').show();
	//$('textarea[name=address_finder]').hide();
	
}

function update_address_postal_search(address_result) {

	console.log(address_result);
	var address_values = [];
	var address_db = [];
	for ( var i = 1; i <= 5; i++ ) {
		if ( address_result[ 'Line' + i ] != '' ) {
			address_values.push(address_result[ 'Line' + i ]);
			address_db.push(address_result[ 'Line' + i ]);
		}
		else {
			break;
		}
	}
	
	if ( address_result['City'] != '' ) {
		address_values.push(address_result['City']);
	}
	if ( address_result['ProvinceName'] != '' ) {
		address_values.push(address_result['ProvinceName']);
	}
	address_values.push(address_result['PostalCode']);
	
	//$('.address_display').text( address_values.join(', ') );
	$('.selected-address-text').html( address_values.join(', ') );
	$('.address-picker-container').slideUp(400, function() {
		$('.selected-address').slideDown();
	});
	$('input[name=address]').val( address_db.join(', ') );
console.log(address_db.join(', '));
	$('input[name=city]').val( address_result['City'] );
	$('input[name=province]').val( address_result['ProvinceCode'] );
	$('input[name=postal_code]').val( address_result['PostalCode'] );

	$('.btn.postcode-continue.disabled').removeClass('disabled');
	
}

var current_lines = 1;
var $addressFinder = $('textarea[name=address_finder]');
if($addressFinder[0]){
	var $desktopForm = $('.desktop-form');
	if(!$desktopForm.length) $desktopForm = $('form'); //Just take first form
	var $tyStep = $('.thank-you-next-step');
	var $resizeDiv = $('<div>')
		.hide()
		.css({
			width : $addressFinder[0].offsetWidth,
			paddingLeft : $addressFinder.css('padding-left'),
			paddingTop : $addressFinder.css('padding-top'),
			paddingRight : $addressFinder.css('padding-right'),
			paddingBottom : $addressFinder.css('padding-bottom'),
			fontSize : $addressFinder.css('font-size'),
			fontWeight : $addressFinder.css('font-weight'),
			letterSpacing : $addressFinder.css('letter-spacing'),
			wordSpacing : $addressFinder.css('word-spacing'),
			lineHeight : $addressFinder.css('line-height'),
			whiteSpace : $addressFinder.css('white-space'),
			border : '1px solid red',
			position : 'fixed',
			left : 100,
			top : 100,
			zIndex : 99999999999,
			background : 'yellow'
		})
		.appendTo(document.body);
}
function resizeForm(current_top) {
	if(!$desktopForm.hasClass('desktop-form')) {
		resizeFormNew();
		return;
	}
console.log('going old school');
	setTimeout(function() {
		if ( !$addressFinder[0] ) { return; }
		
		$resizeDiv.css('width', $addressFinder[0].offsetWidth);
		$resizeDiv.text($addressFinder.val())
		
		var addressHeight = $resizeDiv.height() - 16;
		
		if(addressHeight > 30){
			// resize address
			$addressFinder.height( addressHeight );
			// move form
			$desktopForm.css('top',  2 - ( addressHeight / 2) );
			$tyStep.css('top', addressHeight / 2 - 20 );			
		} else {
			// resize address
			$addressFinder.css('height', '');
			// move form
			$desktopForm.css('top',  -4 );
			$tyStep.css('top', 0 );
		}
		
	}, 20);
}

function resizeFormNew() {
	var initial_bottom = parseInt($desktopForm[0].style.bottom, 10);
	setTimeout(function() {
		if ( manual_address_entry ) { return; }
		if ( !$addressFinder[0] ) { return; }
		
		$resizeDiv.css('width', $addressFinder[0].offsetWidth);
		var text = $addressFinder.val();
		$resizeDiv.text(text)
		var addressHeight = $resizeDiv.height() + 4;
		
		if(addressHeight > 30){
			// resize address
			$addressFinder.height( addressHeight );
console.log('addressHeight: ' + addressHeight);
			$('label[for=address]').height( addressHeight + 22 );
			// move form
			//$desktopForm.css('top',  2 - ( addressHeight / 4) );
			if ( ! $desktopForm.hasClass('mobile_ppi') ) {
				$desktopForm.css('bottom',  initial_bottom - ( addressHeight / 2) );
			}
			//$tyStep.css('top', addressHeight / 2 - 20 );			
		} else {
			// resize address
			$addressFinder.css('height', '');
			$('label[for=address]').height( 43 );
			// move form
			if ( ! $desktopForm.hasClass('mobile_ppi') ) {
				$desktopForm.css('bottom',  67);
			}
			//$tyStep.css('top', 0 );
		}
		
	}, 20);
}

function submit_postal_code_error(postal_code, data, attempts, result) {
	var data = {
		'search_term': postal_code,
		'response': JSON.stringify(data)
	};
	if (typeof attempts !== 'undefined') {
		data['attempts'] = attempts;
	}
	if (typeof result !== 'undefined') {
		data['result'] = result;
	}
	
	$.ajax({
		url: '/address_errors.php',
		type: 'POST',
		data: data
	});
}

function CapturePlus_Interactive_Find_by_postal_code_v2_10(postal_code, LastId, success_container) {
	if ( CapturePlusStart === null ) {
		CapturePlusStart = Date.now();
	}
	
	CapturePlusCounter += 1;
	
	$.getJSON("http://services.postcodeanywhere.co.uk/CapturePlus/Interactive/Find/v2.10/json3.ws?callback=?",
	{
		Key: captureplus_api_key,
		SearchTerm: postal_code,
		LastId: LastId,
		MaxResults: 300,
		Country: 'CAN',
		Filter: 'Address'
	},
	(function(postal_success_container, entered_postal_code, last_id) {
		return function (data) {
			var postal_code_stripped = entered_postal_code.replace(/[^a-z0-9]/ig, '').toUpperCase();
			
			postal_code_stripped = reprocess_canada_postal_code(postal_code_stripped);
			
			postal_code_stripped = [postal_code_stripped.slice(0, 3), ' ', postal_code_stripped.slice(3)].join('');
			
			var single_match = false;
			if ( data['Items'].length == 1 && typeof data['Items'][0]['Next'] !== 'undefined' && data['Items'][0]['Next'] == 'Retrieve' ) {
				if ( data['Items'][0]['Description'].indexOf(postal_code_stripped) !== -1 ) {
					single_match = true;
				}
			}

			if ( last_id === null && 'Items' in data && single_match === false ) { //&& data['Items'][0]['Next'] == 'Find' ) {
				var bail_early = false;
				$.each(data['Items'], function(index, item) {
					if ( item['Text'] == postal_code_stripped ) {
						re_search_postal_code = true;
						CapturePlus_Interactive_Find_by_postal_code_v2_10(entered_postal_code, item['Id'], postal_success_container);
						console.log('need to refind data');
						bail_early = true;
						return false;
					}
				});

				if ( bail_early ) {
					return false;
				}
				
			}



			console.log(data);
			console.log(postal_success_container);
			var address_finder = $('.address-picker-container');
			var address_finder_select = address_finder.find('select.address-picker-select');
			address_finder_select.find('option').remove();
			$('<option value="">-- Please Select --</option>').appendTo(address_finder_select);

			console.log(data);
			console.log(data['Items']);
			
			if ( (last_id === null || typeof(data.Items[0].Error) != "undefined") && ((Date.now() - 3000) < CapturePlusStart) && single_match === false ) {
				CapturePlusError = 1;
				submit_postal_code_error(entered_postal_code, data, CapturePlusCounter, 0);
				
				CapturePlus_Interactive_Find_by_postal_code_v2_10(postal_code_stripped, last_id, postal_success_container);

				return false;
			}
			CapturePlusStart = null;
			console.log('after 3 seconds?');

			// Test for an error
			if ( (last_id === null || (data.Items.length == 1 && typeof(data.Items[0].Error) != "undefined")) && single_match === false ) {
				// Show the error message
				//alert(data.Items[0].Description);
				/*
				address_finder_select.find('option').remove();
				$('<option>We were unable to look up an address.</option>').appendTo(address_finder_select);
				address_finder.show();
				*/
				
				PostalIPLookup(postal_code_stripped, function(postal_lookup_result) {
					var lookup_city = '';
					var lookup_province = '';
					if ( typeof postal_lookup_result['city'] !== 'undefined' ) {
						lookup_city = postal_lookup_result['city']
					}
					if ( typeof postal_lookup_result['province'] !== 'undefined' ) {
						lookup_province = postal_lookup_result['province']
					}
					
					postal_success_container.removeClass('loading-spinner-postal');
					show_manual_address_entry('We were unable to look up an address. Please enter it here:', postal_code_stripped, lookup_city, lookup_province);
				});
				
				CapturePlusError = 1;
				submit_postal_code_error(entered_postal_code, data, CapturePlusCounter, 0);
				
				return false;
			}
			else {
				// Check if there were any items found
				if (data.Items.length == 0) {
					submit_postal_code_error(entered_postal_code, data, CapturePlusCounter, 0);
				}
				else {
					$.each(data.Items, function(index, row) {
						var address_row = $('<option></option>');
						address_row.addClass('address_finder_select_row');
						address_row.data('address_id', row.Id);
						address_row.data('row_data', row);
						
						address_row.text(row.Text.substring(row.Text.indexOf(',') + 1));
						address_row.val(row.Text);
						address_row.attr('title', row.Text);
						address_row.appendTo(address_finder_select);
					});
				
					if ( CapturePlusError === 1 ) {
						
						submit_postal_code_error(entered_postal_code, data, CapturePlusCounter, 1);
					}
				}
				
				postal_success_container.removeClass('loading-spinner-postal').addClass('field-success-icon');

			}

			$('<option class="address-not-found">I don\'t see my address. Let me type it in.</option>').appendTo(address_finder_select);
			jcf.refresh( address_finder_select );
			address_finder_select.removeClass('validate-ignore');

			if ( $('span[class*="selected-address-text"]').html() != '' ) {
				$('div[class*="selected-address"]').slideUp(400, function() {
					address_finder.find('.jcf-select').slideDown(400);
					address_finder.slideDown();
				});
			}
			else {
				address_finder.slideDown();
			}

			
		};
	}(success_container, postal_code, LastId)));
}


function CapturePlus_Interactive_Find_v2_10(postal_code, LastId) {
	$.getJSON("http://services.postcodeanywhere.co.uk/CapturePlus/Interactive/Find/v2.10/json3.ws?callback=?",
	{
		Key: captureplus_api_key,
		SearchTerm: postal_code,
		LastId: LastId,
		MaxResults: 100,
		Country: 'CAN',
	},
	function (data) {

		var address_finder_dropdown = $('.address_finder_dropdown');
		var address_finder_dropdown_scroller = $('.address_finder_dropdown .scroller');
		var address_finder_not_found = $('<div class="address_finder_error">I don\'t see my address, Let me type it in.</div>');

		// Test for an error
		if (data.Items.length == 1 && typeof(data.Items[0].Error) != "undefined") {
			// Show the error message
			//alert(data.Items[0].Description);
			address_finder_dropdown_scroller.html('');
			$('<div>We were unable to look up an address.</div>').appendTo(address_finder_dropdown_scroller);
			address_finder_dropdown.show();
			console.log('you are here');

			submit_postal_code_error(postal_code, data);

		}
		else {
			// Check if there were any items found
			if (data.Items.length == 0) {
				
				address_finder_dropdown_scroller.html('');
			}
			else {
				// PUT YOUR CODE HERE
				// http://www.pcapredict.com/support/webservice/captureplus/interactive/find/2.1/

				address_finder_dropdown_scroller.html('');
				
				$('<div>Keep typing to display more results...</div>').addClass('address_finder_keep_typing').appendTo(address_finder_dropdown_scroller);
				$.each(data.Items, function(index, row) {
					var address_row = $('<div></div>');
					address_row.addClass('address_finder_row');
					address_row.data('address_id', row.Id);
					address_row.data('row_data', row);
					address_row.appendTo(address_finder_dropdown_scroller);
					var blue_text = row.Text;
					var grey_text = row.Description;
					if ( row.Next == 'Retrieve' ) {
						text = row.Text.split(',');
						blue_text = text.shift();
						//grey_text = text.join();
						address_row.addClass('checkmark');
					}
					address_row.html('<span class="address_finder_postal_text">' + blue_text + '</span> ' + grey_text);
					address_row.bind('click', row, address_row_click);
				});
				
			}
			address_finder_dropdown.show();
		}
	});
}

function CapturePlus_Interactive_Retrieve_v2_10Begin(Id, callback) {

	if ( (typeof callback === 'undefined' ) ) {
		callback = 'CapturePlus_Interactive_Retrieve_v2_10End';
	}

	var script = document.createElement("script"),
		head = document.getElementsByTagName("head")[0],
		url = "http://services.postcodeanywhere.co.uk/CapturePlus/Interactive/Retrieve/v2.10/json3.ws?";

	// Build the query string
	url += "&Key=" + encodeURIComponent(captureplus_api_key);
	url += "&Id=" + encodeURIComponent(Id);
	url += "&callback=" + callback;

	script.src = url;

	// Make the request
	script.onload = script.onreadystatechange = function () {
		if (!this.readyState || this.readyState === "loaded" || this.readyState === "complete") {
			script.onload = script.onreadystatechange = null;
			if (head && script.parentNode)
				head.removeChild(script);
		}
	}

	head.insertBefore(script, head.firstChild);
}

function postal_code_finder_callback(response) {

	// Test for an error
	if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
		// Show the error message
		//alert(response.Items[0].Description);
		
		submit_postal_code_error('', response);
	}
	else {
		// Check if there were any items found
		if (response.Items.length == 0)
			$('.address_finder_dropdown').text("Sorry, there were no results");
		else {
			// PUT YOUR CODE HERE
			// http://www.pcapredict.com/support/webservice/captureplus/interactive/retrieve/2.1/
			//FYI: The output is an array of key value pairs (e.g. response.Items[0].Id), the keys being:

			update_address_postal_search(response.Items[0]);
		}
	}
}

function CapturePlus_Interactive_Retrieve_v2_10End(response) {
	// Test for an error
	if (response.Items.length == 1 && typeof(response.Items[0].Error) != "undefined") {
		// Show the error message
		//alert(response.Items[0].Description);
		submit_postal_code_error('', response);

	}
	else {
		// Check if there were any items found
		if (response.Items.length == 0)
			$('.address_finder_dropdown').text("Sorry, there were no results");



		else {
			// PUT YOUR CODE HERE
			// http://www.pcapredict.com/support/webservice/captureplus/interactive/retrieve/2.1/
			//FYI: The output is an array of key value pairs (e.g. response.Items[0].Id), the keys being:

			update_address(response.Items[0]);
			//Id
			//DomesticId
			//Language
			//LanguageAlternatives
			//Department
			//Company
			//SubBuilding
			//BuildingNumber
			//BuildingName
			//SecondaryStreet
			//Street
			//Block
			//Neighbourhood
			//District
			//City
			//Line1
			//Line2
			//Line3
			//Line4
			//Line5
			//AdminAreaName
			//AdminAreaCode
			//Province
			//ProvinceName
			//ProvinceCode
			//PostalCode
			//CountryName
			//CountryIso2
			//CountryIso3
			//CountryIsoNumber
			//SortingNumber1
			//SortingNumber2
			//Barcode
			//POBoxNumber
			//Label
			//Type
			//DataLevel
		}
	}
}

function getTextWidthDOM(text, font) {
  var f = font || '12px arial',
      o = $('<span>' + text + '</span>')
            .css({'font': f, 'float': 'left', 'white-space': 'nowrap'})
            .css({'visibility': 'hidden'})
            .appendTo($('body')),
      w = o.width();

  o.remove();

  return w;
}

function PostalIPLookup(postal_code, callback) {
	var data = {
		'postal_code': postal_code
	};
	
	$.ajax({
		'url': '/province_city_lookup.php',
		'type': 'POST',
		'data': data,
		'success': function(return_data) {
			callback(return_data);
		}
	});
}