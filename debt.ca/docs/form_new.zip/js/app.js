var sliderMouseDown = function (e) { // disable clicks on track
    var sliderHandle = $('.slider-wrap.money').find('.ui-slider-handle');
    if (e.target != sliderHandle[0]) {
        e.stopImmediatePropagation();
    }
};

if ( typeof override_data8_validate_both_numbers === 'undefined' ) {
	var override_data8_validate_both_numbers = false;
}

var preloaded_images = [];
;(function($) {

	$(document).ready(function() {
		
		var state_obj = {step: '1 - Unsecured Debt'};
		history.pushState(state_obj, '', window.location.href);

		var pre_load_images_hires = [
			''
		];
		var pre_load_images_lores = [
			''
		];

		var images_to_preload;

		if ( window.devicePixelRatio >= 1.5 ) {
			images_to_preload = pre_load_images_hires;
		}
		else {
			images_to_preload = pre_load_images_lores;
		}

		$.each(images_to_preload, function(index, image) {
			setTimeout(function() {
				preloaded_images[index] = new Image();
				preloaded_images[index].src = image;
			}, 0);
		});

		$('.box-slider-container').each(function(index, element) {
			FastClick.attach(element);
		});

	});

	$(window).on('load', function() {

		function is_touch_device() {
			return 'ontouchstart' in window || 'onmsgesturechange' in window;
		};

		if( is_touch_device() ) {
			$('body').addClass('touch')
		}

		$(".pop-up-text").fancybox({
			maxWidth	: 800,
			maxHeight	: 600,
			fitToView	: false,
			width		: '70%',
			height		: '70%',
			autoSize	: false,
			closeClick	: false,
			openEffect	: 'none',
			closeEffect	: 'none'
		});

		jcf.setOptions('Select', {
			wrapNative: false
		});
		
		jcf.replaceAll();


		// slider
		var slide_val_unsecured_debt = $('.slider-wrap.unsecured_debt input'),
			slider_unsecured_debt = $('.slider-wrap.unsecured_debt .slider'),
			slider_number_of_debts = $('.slider-wrap.number_of_debts .slider'),
			slide_val_number_of_debts = $('.slider-wrap.number_of_debts input'),
			slider_student_loan_debt = $('.slider-wrap.student_loan_debt .slider'),
			slide_val_student_loan_debt = $('.slider-wrap.student_loan_debt input'),
			slider_last_attended_class = $('.slider-wrap.last_attended_class .slider'),
			slide_val_last_attended_class = $('.slider-wrap.last_attended_class input');

		var slider_unsecured_debt_max = slide_val_unsecured_debt.data('max');
		var slider_unsecured_debt_start = slide_val_unsecured_debt.data('start');
		slider_unsecured_debt.slider({
			range: "min",
			value: slider_unsecured_debt_start,
			min: 5000,
			max: slider_unsecured_debt_max,
			step: 1000,
			slide: function(event, ui) {
				if ( ui.value == slider_unsecured_debt_max ) {
					$('.slider-wrap.unsecured_debt .ui-slider-handle').text('$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+")
					slide_val_unsecured_debt.val( '$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+" );
				}
				else {
					$('.slider-wrap.unsecured_debt .ui-slider-handle').text('$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
					slide_val_unsecured_debt.val( '$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );
				}				
			}
		});

		slide_val_unsecured_debt.val( '$' + slider_unsecured_debt.slider( "value" ).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );

		slider_number_of_debts.slider({
			range: "min",
			value: 3,
			min: 1,
			max: 10,
			step: 1,
			slide: function(event, ui) {
				if ( ui.value == 10 ) {
					$('.slider-wrap.number_of_debts .ui-slider-handle').text(ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+")
					slide_val_number_of_debts.val( ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+" );
				}
				else {
					$('.slider-wrap.number_of_debts .ui-slider-handle').text(ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ","))
					slide_val_number_of_debts.val( ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );
				}				
			}
		});

		slide_val_number_of_debts.val( slider_number_of_debts.slider( "value" ).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );

		slider_student_loan_debt.slider({
			range: "min",
			value: 10000,
			min: 1000,
			max: 50000,
			step: 1000,
			slide: function(event, ui) {
				if ( ui.value == 50000 ) {
					slide_val_student_loan_debt.val( '$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+" );
				}
				else {
					slide_val_student_loan_debt.val( '$' + ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );
				}				
			}
		});

		slide_val_student_loan_debt.val( '$' + slider_student_loan_debt.slider( "value" ).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") );

		slider_last_attended_class.slider({
			range: "min",
			value: 7,
			min: 1,
			max: 10,
			step: 1,
			slide: function(event, ui) {
				if ( ui.value == 10 ) {
					slide_val_last_attended_class.val( ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + "+ years" );
				}
				else {
					slide_val_last_attended_class.val( ui.value.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " years" );
				}				
			}
		});

		slide_val_last_attended_class.val( slider_last_attended_class.slider( "value" ).toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",") + " years" );

		var currentFields = $('#lp-3-form .field-form');
		var number_of_steps = currentFields.length;

		$('.progress-bar div').animate({ width: ( $('.progress-bar').width() / number_of_steps ) }, 500);
		
		var filled_val = 0;
		var filled_alt_val = 1;
		var spinner_continue_reached = false;
		$.each(currentFields, function(field_index, currentField) {
			var nextField = $(currentField).closest('.field-form').next();
			$(currentField).find('.btn').on('click', function() {
				validate_current_section(true, true, function(section_validate_error) {
					console.log(section_validate_error);
					//section_validate_error = false; // disable validation
					if ( typeof $(currentField).data('extra_validation') !== 'undefined' ) {
						
						if ( $(currentField).data('extra_validation') == 'home_owner' ) {
							var skip_optional = false;
							var home_owner_check = true;
							
							if ( $('input[name=home_owner]:checked').val() == 'No' ) {
								skip_optional = true;
								home_owner_check = false;
							}
						}
						
						if ( $(currentField).data('extra_validation') == 'student_loan' ) {
							var skip_optional = true;
							var student_loan_check = false;
							
							if ( $('input[name="types_of_debt[]"][value="Student Loans"]').prop('checked') ) {
								skip_optional = false;
								student_loan_check = true;
							}
						}
					}
					
					if ( !section_validate_error ) {
						
						if ( typeof $(currentField).data('extra_actions') !== 'undefined' ) {
							if ( $(currentField).data('extra_actions') == 'Searching Spinner' ) {
								// if ( $('input[name=city]').val() == '' || $('input[name=province]').val() == '' ) {
								// 	PostalIPLookup($('input[name=postal_code]').val(), function(lookup_result) {
								// 		if ( lookup_result['success'] ) {
								// 			$('input[name=city]').val( lookup_result['city'] );
								// 			$('input[name=province]').val( lookup_result['province'] );
								// 		}
										
										
								// 		PostalValidLookup($('input[name=postal_code]').val(), function(postal_lookup_result) {
								// 			HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, postal_lookup_result['available']);
								// 		});
										
								// 		HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, true);
								// 	});
								// }
								// else {
									/*
									PostalValidLookup($('input[name=postal_code]').val(), function(postal_lookup_result) {
										HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, postal_lookup_result['available']);
									});
									*/
								// 	HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, true);
								// }
									HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, true);

								
							}
						}
						else {
							
							if ( typeof employed_check !== 'undefined' && employed_check == false ) {								
								var step_track = $(nextField).next().data('step');
								
								SlideSection(currentFields[(field_index + 2)], number_of_steps, 'forward', (field_index + 2), step_track, false);
							}
							else if ( (typeof home_owner_check !== 'undefined' && home_owner_check == false) || (typeof student_loan_check !== 'undefined' && student_loan_check == false) ) {								
								var step_track = $(nextField).next().next().data('step');
								
								SlideSection(currentFields[(field_index + 3)], number_of_steps, 'forward', (field_index + 3), step_track, false);
							}
							else {
								var step_track = $(nextField).data('step');
								
								if ( $(currentField).find('input[type=email]').length ) {
									SlideSection(currentFields[(field_index + 1)], number_of_steps, 'forward', (field_index + 1), step_track, currentField);
								}
								else {
									SlideSection(currentFields[(field_index + 1)], number_of_steps, 'forward', (field_index + 1), step_track, false);
								}
							}
							
						}
							
						
						if ( typeof $(currentField).data('state_actions') !== 'undefined' ) {
						console.log($(currentField).data('state_actions'));
						console.log(skip_optional);
							if ( $(currentField).data('state_actions') == 'skip next' ) {
								console.log('skipping state push');
							}
							else if ( $(currentField).data('state_actions') == 'skip next optional' && skip_optional == true ) {
								var state_obj = {step: $(currentField).next().next().data('step')};
								history.pushState(state_obj, '', window.location.href);
							}
							else if ( $(currentField).data('state_actions') == 'skip next optional' && skip_optional == false ) {
								var state_obj = {step: $(currentField).next().data('step')};
								history.pushState(state_obj, '', window.location.href);
							}
							else if ( $(currentField).data('state_actions') == 'skip next 2 optional' && skip_optional == true ) {
								var state_obj = {step: $(currentField).next().next().next().data('step')};
								history.pushState(state_obj, '', window.location.href);
							}
							else if ( $(currentField).data('state_actions') == 'skip next 2 optional' && skip_optional == false ) {
								var state_obj = {step: $(currentField).next().data('step')};
								history.pushState(state_obj, '', window.location.href);
							}
						}
						else {
							var state_obj = {step: $(currentField).next().data('step')};
							history.pushState(state_obj, '', window.location.href);
						}

						/*
						if ( $.inArray(field_index, [2,4,6, 8, 10]) != -1 ) {
							filled_val += 1;
							filled_alt_val += 1;
						}
						
						if ( field_index % 2 == 0 && field_index != 10 ) {
							$('.step-list li').eq(filled_val).addClass('filled');
							$('.step-list li').eq(filled_alt_val).addClass('active-half');
						}
						else if ( field_index % 2 != 0 && field_index != 10 ) {
							$('.step-list li').eq(filled_val).addClass('filled');
							$('.step-list li').eq(filled_alt_val).addClass('active');
						}
						else {
							$('.step-list li').eq(filled_val).addClass('filled');
						}
						*/
					}
				});
			});
				$(currentField).find('input[type=text], input[type=email], input[type=tel]').on('keypress', function(e) {
						if (e.keyCode == '13') {
							e.preventDefault();
							e.stopPropagation();
							if ( $(currentField).find('.btn').length ) {
								$(currentField).find('.btn').trigger('click');
								
							}
							else {
								$(currentField).find('input[type=submit]').trigger('click');
							}
						}


					});
			// $(currentField).find('input[type=text], input[type=email], input[type=tel]').on('keypress', function(e) {
			// 	if ( e.keyCode == 13 && $(this).attr('name') != 'postcode_finder' ) {
			// 		e.preventDefault();
			// 		e.stopPropagation();
			// 		if ( $(currentField).find('.btn').length ) {
			// 			$(currentField).find('.btn').trigger('click');
						
			// 		}
			// 		else {
			// 			$(currentField).find('input[type=submit]').trigger('click');
			// 		}
			// 	}
			// });

		})

		currentFields.not(':first').css('right', '-1000px');


	});
	
	function HandleSpinnerStep(currentFields, number_of_steps, currentField, nextField, field_index, is_available) {
		var available_header = "Congratulations";
		var available_text = "You qualify for debt relief! Next, secure your free phone consultation with a debt advisor.";
		if ( $('body').hasClass('mobile-page') ) {
			available_text = "You qualify for debt relief! Next Step: secure your free phone consultation.";
		}
		
		if ( ! is_available ) {
			var available_header = "We're sorry";
			var available_text = "We couldnâ€™t find any lenders in your area.";
		}
		
		$('span.available_header').html(available_header);
		$('span.available_text').html(available_text);
		
		var city_name = toTitleCase($('input[name=city]').val());
		var province = $('input[name=province]');
		var province_name = '';
		if ( ! province.length ) {
			province = $('select[name=province] option:selected');
		}
		province_name = province.val();
		$('#spinner_location').html(city_name + ", " + province_name);
		
		$('#spinner_searching_program').removeClass('hidden');
		$('.cover-spinner-cog').removeClass('hidden');
		$('#spinner_location').removeClass('hidden');
		
		var step_track = $(nextField).data('step');
		
		SlideSection(currentFields[(field_index + 1)], number_of_steps, 'forward', (field_index + 1), step_track, false);
		
		var spinner_step_time = 3000;
		
		setTimeout(function(){
			$('#spinner_searching_program').addClass('hidden');
			$('#spinner_searching_evaluating').removeClass('hidden');
			$('#spinner_location').addClass('hidden');
			
			setTimeout(function() {
				$('#spinner_searching_evaluating').addClass('hidden');
				$('#spinner_location').addClass('hidden');
				$('#spinner_searching_location').removeClass('hidden');
				
				GetTrusteeRedirect(function(trustee_response) {
					if ( trustee_response['redirect_page'] == '' ) {
						setTimeout(function() {
							$('#spinner_searching_program').addClass('hidden');
							$('.cover-spinner-cog').addClass('hidden');
							$('#spinner_location').addClass('hidden');
							$('.cover-spinner-background').removeClass('hidden');
							$('.cover-spinner-message-box').addClass('hidden');
							$('.cover-spinner-final-box').removeClass('hidden');
							$('#spinner_searching_location').addClass('hidden');
							
							if ( is_available ) {
								$('.cover-spinner-final-checkmark').removeClass('not-available');
							}
							else {
								$('.cover-spinner-final-checkmark').addClass('not-available');
							}
							
							spinner_continue_reached = true;
							$('.cover-spinner-background span.btn').on('click', function() {
								$('.cover-spinner-background').addClass('hidden');
								$('.cover-spinner-message-box').removeClass('hidden');
								$('.cover-spinner-final-box').addClass('hidden');
								setTimeout(function() {
									if ( is_available) {
										$(currentField).next().find('.btn').trigger('click');
									}
									else {
										var first_step = $('.lp-3-form .field-form.first-step');
										SlideSection(first_step, number_of_steps, 'backward', 0, first_step.data('step'), false);
									}
								}, 10);
							});
						}, spinner_step_time);
					}
					else {
							alert(trustee_response['redirect_page']);
						// setTimeout(function() {
						// 	window.location = trustee_response['redirect_page'];
						// }, spinner_step_time);
					}
				});
			}, spinner_step_time);
		}, spinner_step_time);
	};
	
	window.onpopstate = function(event) {
		console.log(event.state);
		
		if ( ! $('.cover-spinner-background').hasClass('hidden') ) {
			$('.cover-spinner-background').addClass('hidden');
		}
		
		var currentFields = $('#lp-3-form .field-form');
		var number_of_steps = currentFields.length;
		var fields_data_map = {};
		var last_active_step = 0;
		
		$.each(currentFields, function(field_index, field_object) {
			fields_data_map[ $(field_object).data('step') ] = {
				'step_index': field_index,
				'step_object': field_object
			};
			
			if ( $(field_object).closest('.field-form').hasClass('active') ) {
				last_active_step = field_index;
			}
		});
		
		if ( event.state['step'] == 'Completed' ) {
			var currentField = fields_data_map['1 - Vehicle Type']['step_object'];
			var step_index = 0;
		}
		else {
			var currentField = fields_data_map[ event.state['step'] ]['step_object'];
			var step_index = fields_data_map[ event.state['step'] ]['step_index'];
		}
		
		var step_direction = 'forward'
		if ( step_index < last_active_step ) {
			var step_direction = 'backward';
		}
		
		SlideSection(currentField, number_of_steps, step_direction, step_index, event.state['step'], false);
	};

	$(window).on('load', function() {

		var footer_bottom = function() {
			var height = $('body').hasClass('lp-3-page') ? '200' : $('.footer').height();
			
			if ( ! $('body').hasClass('lp-3-page') ) {
				$('.wrapper-content').css('padding-bottom', $('.footer').height());
				// use this line if header fixed
				//$('.wrapper-holder').css('padding-top', $('#header').height());
				$('.footer').css('margin-top', '-' + height + 'px');
			}
			else {
				if ( $(window).width() <= 479 ) {
					var footer_margin_top = $(window).height() - 498;
					footer_margin_top = (footer_margin_top < 100 ? 100 : footer_margin_top);
					$('.footer').css('margin-top', footer_margin_top + 'px');
				}
			}
		}
		
		footer_bottom();

	});
	
	$(document).on('click', '.slider-value', function() {
		var $this = $(this);
		var slider_control = $this.closest('.slider-wrap').find('.ui-slider-handle');
		
		if ( slider_control.length == 0 ) {
			slider_control = $this.closest('.box-slider-item').find('.box-slider-adjustor');
		}
		
		slider_control.addClass('wobble');
		setTimeout(function() {
			slider_control.removeClass('wobble');
		}, 500);
		
		/*
		setTimeout(function() {
			$this.addClass('wobble-left');
			setTimeout(function() {
				$this.removeClass('wobble-left');
				$this.addClass('wobble-right');
				setTimeout(function() {
					$this.removeClass('wobble-right');
				}, 100);
			}, 100);
		}, 100);
		*/
	});

	$(document).on('focus', '.slider-value', function() {
		this.blur();
	});
	
	$(document).on('click', '.slider-work-duration .box-slider-adjustor', function() {
		setTimeout(function() {
			var work_years = parseInt($('input[name=work_duration_years]').val());
			var work_months = parseInt($('input[name=work_duration_months]').val());
			
			check_time_minimum(work_years, work_months, 3, function(work_duration_validation_response) {
				if ( work_duration_validation_response ) {
					$('.error-work_duration_disqualified').html('').hide();
				}
			});
		}, 10);
	})
	
	$(document).on('blur', 'input[type="text"], input[type="email"], textarea', function(e) {
		if ( typeof validation[ $(this).attr('name') ] !== 'undefined' && $(this).attr('name') != 'postcode_finder' ) {
			//console.log('validating on ' + $(this).attr('name'));
			var validation_response = validate_field($(this), validation);
			if ( $(this).closest('.validation-display').hasClass('error') || (( $(this).attr('name') == 'first_name' || $(this).attr('name') == 'last_name' ) && $(this).hasClass('error') ) ) {
				update_element_valid_state($(this), validation_response, true, true);
			}
			else {
				update_element_valid_state($(this), validation_response, true, false);
			}
		}
	});
		
	$(document).on('blur', 'input[type="tel"]', function() {
		//console.log('validating on ' + $(this).attr('name'));
		
		var parent_container = $(this).closest('.validation-display');
		var phone_inputs = parent_container.find('input[type="tel"]');
		if ( $(this).hasClass('error') ) {
			var phone_valid = validate_phone_fields(phone_inputs, true, true);
		}
		else {
			var phone_valid = validate_phone_fields(phone_inputs, true, false);
		}
	});

	$(document).on('change', 'select', function() {
		//console.log('validating on ' + $(this).attr('name'));
		if ( ! $(this).hasClass('validate-ignore') ) {
			var validation_response = validate_field($(this), validation);
			update_element_valid_state($(this), validation_response, true, false);
		}
	});

	$(document).on('change', 'input[type="radio"]', function() {
		//console.log('validating on ' + $(this).attr('name'));
		var validation_response = validate_field($(this), validation);
		update_element_valid_state($(this), validation_response, true, false);
	});

	$(document).on('change', 'input[type="checkbox"]', function() {
		//console.log('validating on ' + $(this).attr('name'));
		var validation_response = validate_field($(this), validation);
		update_element_valid_state($(this), validation_response, true, false);
	});

	$(document).on('change', 'input[name="rent_or_own"]', function() {
		console.log('changed the radio: ' + $('input[name="rent_or_own"]').val() );
		if ( $('input[name="rent_or_own"]:checked').val() == 'Rent' ) {
			$('.rent-or-own-question').html('rental');
		}
		else {
			$('.rent-or-own-question').html('mortgage');
		}
	});
	
	$(document).on('click', '#FormLastSubmitButton', function(e) {
		var termCheckboxLength =  $('#termsCheckbox:checkbox:checked').length > 0;
		// alert(termCheckboxLength);
		if (!$("#comments").val()) {
    			// alert('kuchh to gadbar hai');
				e.preventDefault();
			}else{

                var data = {
		'action': 'lookup_trustee'
	};
	
	data['Unsecured_Debt'] = $('input[name=unsecured_debt]').val();
	data['Behind_On_Bills'] = $('input[name=behind_on_bills]:checked').val();
	
	if ( $('input[name="types_of_debt[]"][value="Student Loans"]').prop('checked') ) {
		data['Student_Loan'] = 'Yes';
		data['Student_Loan_Debt'] = $('input[name=student_loan_debt]').val();
		data['Student_Loan_Years'] = $('input[name=last_attended_class]').val();
	}
	else {
		data['Student_Loan'] = 'No';
	}
	
	data['Credit_Rating'] = $('input[name=credit_rating]:checked').val();
	data['Employment_Status'] = $('input[name=employment_status]:checked').val();
	data['Home_Owner'] = $('input[name=home_owner]:checked').val();
	data['Property_Value'] = $('select[name=property_value] option:selected').val();
	data['Mortgage_Balance'] = $('select[name=mortgage_balance] option:selected').val();
	data['postal_code'] = $('input[name=postal_code]').val();
	// data['city'] = $('input[name=city]').val();
	// data['province'] = $('input[name=province]').val();
	// data['address'] = $('input[name=address]').val();
	// data['landing_page'] = $('input[name=lp]').val();
	data['number_of_debts'] = $('input[name=number_of_debts]').val();

	var types_of_debt = [];
	$('input[name="types_of_debt[]"]:checked').each(function() {
		types_of_debt.push($(this).val());
	});
	data['types_of_debt'] = types_of_debt.join(', ');
	// data['phone_input'] = $('#phone').val();
	// data['mobile_input'] = $('#mobile').val();
	// data['email'] = $('input[type="email"]').val();
	// data['first_name'] = $('#first_name').val();
	// data['first_name'] = '';
	// data['last_name'] = $('#last_name').val();
	// data['last_name'] = '';
	// data['comments'] = $('#comments').val();

	// console.log(data);
	// alert(data);

			  var base_url = window.location.hostname;
			  		$.ajax({
                    url: '/insertdata',
                    type:'POST',
                    data:data,
                    success:function(formResult){
                        // $("#response").text(result);
                        // alert(formResult);
                        var ResultFromInsert = formResult;
                        // alert(base_url);
						// window.location = "http://www.yoururl.com";
			  			window.location = "https://debtsolution.cdebt.ca/result/"+formResult;
                    }

            });
			  		// if (ResultFromInsert!=0) 
			  		// {
			  		// }
			  		// else{
			  		// 	alert('sss');
			  		// }
						
						$('#lp-3-form').submit(false);	
	// e.stopPropagation();
	// e.preventDefault();
	// 	var current_section = $('#lp-3-form .field-form.active');
	// 	var $this = $(this);
		
	// 	if ( current_section.length > 0  && ! $('.field-form').last().hasClass('active') ) { //$(this).closest('.field-form') != $(current_section) ) {
	// 		return false;
	// 	}
		// else if ( ! $('input[name=postcode_finder]').is(':focus') ) {
		// 	e.stopPropagation();
		// 	e.preventDefault();
		// 	$('input[type="submit"], .submit-button-text').prop('disabled', true).hide();
		// 	$('.loading-spinner-arrows').removeClass('hidden');
			
		// 	validate_current_section(true, true, function(section_validate_error) {
		// 		if ( ! section_validate_error ) {
					
		// 			var phone_input = $('input[type="tel"][name="phone"]');
		// 			var mobile_input = $('input[type="tel"][name="mobile"]');
					
		// 			check_data8(phone_input.val(), mobile_input.val(), function(data8_result) {
		// 				if ( data8_result['success'] ) {
		// 					var state_obj = {step: 'Completed'};
		// 					history.pushState(state_obj, '', window.location.href);
							
		// 					$(document).find('form').submit();
		// 					/*
		// 					process_comments(function(comments_result) {
		// 						$('#main_form').submit();
		// 					});
		// 					*/
		// 				}
		// 				else {
		// 					var error_message = data8_result['error_message'];
		// 					//console_log('submit phones fail. error: ' + error_message);
		// 					if ( data8_result['error_count'] == 2 ) {
		// 						var phone_inputs = $('input[type="tel"]');
								
		// 						jQuery.each(phone_inputs, function(index, phone_input) {
		// 							update_element_valid_state($(phone_input), {'success': false, 'error': error_message}, true, true);
		// 						});
		// 					}
		// 					else {
		// 						if ( ! data8_result['phone_response'] ) {
		// 							update_element_valid_state(phone_input, {'success': false, 'error': error_message}, true, true);
		// 						}
		// 						else if ( ! data8_result['mobile_response'] ) {
		// 							update_element_valid_state(mobile_input, {'success': false, 'error': error_message}, true, true);
		// 						}
		// 					}

		// 					if ( $('body').hasClass('lp-1-page') || $('body').hasClass('lp-2-page') ) {
		// 						var scrolltop = $(window).scrollTop();
		// 						var element_scrolltop = $('.error').first().closest('.field-form').find('.title-label').offset().top - 10;
		// 						if ( element_scrolltop < scrolltop ) {
		// 							$('html, body').animate({ scrollTop: $('.error').first().closest('.field-form').find('.title-label').offset().top - 10 });
		// 						}
		// 					}
		// 					$('.loading-spinner-arrows').addClass('hidden');
		// 					$('input[type="submit"], .submit-button-text').prop('disabled', false).show();
							
		// 					/*
		// 					var currentFields = $('#lp-3-form .field-form');
		// 					var number_of_steps = currentFields.length;
		// 					var currentField = $this.closest('.field-form');
		// 					var current_index = currentFields.index(currentField);
		// 					var nextField = $(currentField).prev();
		// 					SlideSection(nextField, number_of_steps, 'backward', (current_index - 1), nextField.data('step'), false);
		// 					*/
		// 					history.go(-1);
		// 				}
		// 			});
		// 			//proceed to submit
		// 		}
		// 		else {
		// 			if ( $('body').hasClass('lp-1-page') || $('body').hasClass('lp-2-page') ) {
		// 				var scrolltop = $(window).scrollTop();
						
		// 				if ( $('.error').first().closest('.field-form').length > 0 ) {
		// 					var element_scrolltop = $('.error').first().closest('.field-form').find('.title-label').offset().top - 10;
		// 				}
		// 				else {
		// 					var element_scrolltop = $('.error').first().closest('.wrap-checkbox').offset().top - 10;
		// 				}
						
		// 				if ( element_scrolltop < scrolltop ) {
		// 					$('html, body').animate({ scrollTop: $('.error').first().closest('.field-form').find('.title-label').offset().top - 10 });
		// 				}
		// 			}
		// 			$('.loading-spinner-arrows').addClass('hidden');
		// 			$('input[type="submit"], .submit-button-text').prop('disabled', false).show();
		// 		}
		// 	});
		// }
		// else {
		// 	return false;
		// }
	}
	});
	
	function validate_current_section(show_errors, show_checks, callback) {
		var error_count = 0;
		var error = true;
		var current_section = $('.field-form.active');
		
		if ( current_section.length == 0 ) {
			var current_section = $(document).find('form');
		}
		
		var current_inputs = current_section.find('input,select,textarea').not('[type=hidden]');
		
		console.log(current_inputs);

		if ( $('input[name=postcode_finder]').is(':visible') ) {
			current_inputs = current_section.find('input,select,textarea').not('[type=hidden]').add('input[name=address]');
		}

		// Yogesh code for postal check 

		if ( $('#postalCodeStep').is(':visible') ) {
			var postalCodeValue = $('#postal_code').val();
			var postalCodeValueFrstLtr = postalCodeValue.substring(0, 3);
			var checkPostalCode = false;
			var CurruntBaseUrl = window.location.hostname;
			  $.ajax({
                url: "https://cdebt.ca/index.php/Homepage/checkPostalCode",
                dataType: 'text',
                async: false,
        		cache: false,
                data: {postalCodeValue: postalCodeValueFrstLtr},
                type: "POST",
                success: function (result) {
                  // location.reload();
                  // alert(result);
                  if (result==1) 
                  {
                  	checkPostalCode = true;
                  }
                  
                }
            });

			if (checkPostalCode==false && postalCodeValue!='') {
				$(".error-postal_code").html('This is Not Valid Canadian Postal Code');
				$('#postal_code').parent().removeClass('field-success-icon');
				$("#postal_code").addClass('error');
				$(".error-postal_code").show();
				return false;
			}
		}

		// End Yogesh code

		var processed_inputs = {};
		var phone_errors = 0;
		$.each(current_inputs, function(index,row) {
			if ( (typeof processed_inputs[ row.name ] === 'undefined') && ( (typeof validation[ row.name ] !== 'undefined') ) ) {
				console.log(row);
				if ( row.type == 'radio' || row.type == 'checkbox' ) {
					var input_item = $('input[name="' + row.name + '"]:checked');
					
					if ( input_item.length == 0 ) {
						var input_item = $('input[name="' + row.name + '"]')[0];
					}
				}
				else {
					var input_item = row;
				}
				var validate_result = validate_field(input_item, validation);
				
				if ( ! validate_result['success'] ) {
					error_count += 1;
					
					if ( row.name == 'phone' || row.name == 'mobile' ) {
						phone_errors += 1;
					}
				}
				
				processed_inputs[ row.name ] = validate_result;
			}
		});
		
		if ( typeof processed_inputs['phone'] !== 'undefined' && error_count - phone_errors == 0 ) {
			console.log('got into submit phone processing');
			var phone_ok = 0;
			var phone_empty = 0;
			
			if ( processed_inputs['phone']['success'] ) {
				phone_ok += 1;
			}
			else if ( processed_inputs['phone']['empty_phone'] ) {
				phone_empty += 1;
			}
			
			if ( processed_inputs['mobile']['success'] ) {
				phone_ok += 1;
			}
			else if ( processed_inputs['mobile']['empty_phone'] ) {
				phone_empty += 1;
			}
			
			if ( phone_ok == 2 || ( phone_ok == 1 && phone_empty == 1 ) ) {
				error = false;
			}
		}
		else if ( error_count == 0 ) {
			error = false;
		}
		
		/*
		if ( error_count == 0 || 
			( typeof processed_inputs['phone'] !== 'undefined' &&
			( processed_inputs['phone']['success'] || processed_inputs['mobile']['success']  )
			&& ( error_count < 2 && ( processed_inputs['phone']['success'] == false || processed_inputs['mobile']['success'] == false) ) ) ) {
			
			error = false;
		}
		*/
		
		if ( error && show_errors ) {
			$.each(processed_inputs, function(index,row) {
				
				if ( ! row['success'] ) {
					if ( index == 'phone' && processed_inputs['mobile']['success'] && processed_inputs['phone']['empty_phone'] ) {
						return;
					}
					else if ( index == 'mobile' && processed_inputs['phone']['success'] && processed_inputs['mobile']['empty_phone'] ) {
						return;
					}
					else if ( validation_select_fields.indexOf(index) !== -1 ) {
						update_element_valid_state($('select[name ="' + index + '"]'), row, false, true);
						/*
						$(document).find('.jcf-select-' + index).addClass('error');
						$(document).find('.error-' + index).html(row['error']).show();
						*/
					}
					else if ( ['contact_ok', 'terms'].indexOf(index) !== -1 ) {
						update_element_valid_state($('[name ="' + index + '"]'), row, false, true);
						/*
						$(document).find('[name="' + index + '"]').closest('.jcf-checkbox').addClass('error');
						$(document).find('.error-' + index).html(row['error']).show();
						*/
					}
					else if ( $('input[name=postcode_finder]').is(':visible') && (! $('.jcf-select-address-picker-select').is(':visible')) && processed_inputs['postcode_finder']['success'] && index == 'address' ) {
						$('input[name=postcode_finder]').addClass('error');
						$('.error-postcode_finder').html('Please click Find My Address').show();		
					}
					else if ( $('textarea[name=address_finder]').is(':visible') ) {
						update_element_valid_state($('textarea[name="' + index + '"]'), row, true, true);
					}
					else if ( validation_input_fields.indexOf(index) !== -1 ) {
						update_element_valid_state($('input[name="' + index + '"]:not([type="hidden"])'), row, true, true);
						/*
						$(document).find('[name="' + index + '"]:not([type="hidden"])').addClass('error');
						$(document).find('.error-' + index).html(row['error']).show();
						*/
					}
					else {
						console.log('got here? - ' + index);
						console.log($('[name ="' + index + '"]').first());
						update_element_valid_state($('[name="' + index + '"]').first(), row, false, true);
						/*
						$(document).find('[name="' + index + '"]:not([type="hidden"])').closest('.validation-display').addClass('error');
						$(document).find('.error-' + index).html(row['error']).show();
						*/
					}
				}
				else {
					if ( validation_select_fields.indexOf(index) !== -1 ) {
						update_element_valid_state($('select[name="' + index + '"]'), row, false, true);
						/*
						$(document).find('.jcf-select-' + index).removeClass('error');
						$(document).find('.error-' + index).html('').hide();
						*/
					}
					else if ( ['contact_ok', 'terms'].indexOf(index) !== -1 ) {
						update_element_valid_state($('[name="' + index + '"]'), row, false, true);
						/*
						$(document).find('[name="' + index + '"]').closest('.jcf-checkbox').removeClass('error');
						$(document).find('.error-' + index).html('').hide();
						*/
					}
					else if ( validation_input_fields.indexOf(index) !== -1 ) {
						update_element_valid_state($('input[name="' + index + '"]:not([type="hidden"])'), row, true, true);
						/*
						$(document).find('[name="' + index + '"]:not([type="hidden"])').removeClass('error');
						$(document).find('.error-' + index).html('').hide();
						*/
					}
					else {
						update_element_valid_state($('[name="' + index + '"]'), row, false, true);
						/*
						$(document).find('[name="' + index + '"]:not([type="hidden"])').closest('.validation-display').removeClass('error');
						$(document).find('.error-' + index).html('').hide();
						*/
					}
				}
				
			});
		}
		else {
			console.log(processed_inputs);
			$.each(processed_inputs, function(index,row) {
				if ( index == 'phone' && processed_inputs['mobile']['success'] && processed_inputs['phone']['empty_phone'] ) {
					return;
				}
				else if ( index == 'mobile' && processed_inputs['phone']['success'] && processed_inputs['mobile']['empty_phone'] ) {
					return;
				}
				else if ( validation_select_fields.indexOf(index) !== -1 ) {
					update_element_valid_state($('select[name="' + index + '"]'), row, false, true);
				}
				else if ( ['contact_ok', 'terms'].indexOf(index) !== -1 ) {
					update_element_valid_state($('[name="' + index + '"]'), row, false, true);
				}
				else if ( validation_input_fields.indexOf(index) !== -1 ) {
					update_element_valid_state($('input[name="' + index + '"]:not([type="hidden"])'), row, true, true);
				}
				else {
					update_element_valid_state($('[name="' + index + '"]'), row, false, true);
				}
				/*
				$(document).find('[name="' + index + '"]:not([type="hidden"])').closest('.validation-display').removeClass('error');
				$(document).find('.error-' + index).html('').hide();
				*/
			});
		}
		
		callback( error );
	}

})(jQuery)

var is_mobile = false;
$(document).on('click', '.show-terms-popup', function(e) {
        e.stopPropagation();
	e.preventDefault();
        if ( $(this).closest('form').hasClass('mobile_ppi') ) {
                is_mobile = true;
        }
        TogglePopup($('#TermsPopup'), true, is_mobile);
});
$(document).on('click', '.show-privacy-popup', function(e) {
        e.stopPropagation();
	e.preventDefault();
        if ( $(this).closest('form').hasClass('mobile_ppi') ) {
                is_mobile = true;
        }
        TogglePopup($('#PrivacyPopup'), true, is_mobile);
});

function SlideSection(sectionContainer, total_steps, direction, new_step_index, new_step_name, emailSectionContainer) {
	
	if ( direction == 'forward' ) {
		$(sectionContainer).css( "right", -1000 );
	}
	else {
		$(sectionContainer).css( "right", 1000 );
	}
	
	$('#lp-3-form .field-form').removeClass('active').hide();

	$('html, body').scrollTop(0);
	$(sectionContainer).closest('.field-form').addClass('active').show().animate({
		right: 0
	}, 250, function() {
		
		PostClickTracking(new_step_name);
		
		if ( emailSectionContainer !== false ) {
			PostPreLead(emailSectionContainer);
		}

	});
	
	$('.progress-bar div').animate({ width: ($('.progress-bar').width() / total_steps) * (new_step_index + 1) }, 500);
	
}

function PostPreLead(emailSectionContainer) {
	// $.ajax({
	// 	'url': '/ajax_form.php',
	// 	'type': 'POST',
	// 	'data': $(emailSectionContainer).closest('form').serialize() + '&action=store_prelead'
	// });
}

function PostClickTracking(step_name) {
	// alert(step_name);
	// $.ajax({
	// 	'url': '/ajax_form.php',
	// 	'type': 'POST',
	// 	'data': {
	// 		'action': 'click',
	// 		'script_name': (window.location.pathname == '/' ? '/index.php' : window.location.pathname),
	// 		'click_tracking_append': step_name
	// 	}
	// });
}

function GetTrusteeRedirect(callback) {
	var data = {
		'action': 'lookup_trustee'
	};
	
	data['Unsecured_Debt'] = $('input[name=unsecured_debt]').val();
	data['Behind_On_Bills'] = $('input[name=behind_on_bills]:checked').val();
	
	if ( $('input[name="types_of_debt[]"][value="Student Loans"]').prop('checked') ) {
		data['Student_Loan'] = 'Yes';
		data['Student_Loan_Debt'] = $('input[name=student_loan_debt]').val();
		data['Student_Loan_Years'] = $('input[name=last_attended_class]').val();
	}
	else {
		data['Student_Loan'] = 'No';
	}
	
	data['Credit_Rating'] = $('input[name=credit_rating]:checked').val();
	data['Employment_Status'] = $('input[name=employment_status]:checked').val();
	data['Home_Owner'] = $('input[name=home_owner]:checked').val();
	data['Property_Value'] = $('select[name=property_value] option:selected').val();
	data['Mortgage_Balance'] = $('select[name=mortgage_balance] option:selected').val();
	data['postal_code'] = $('input[name=postal_code]').val();
	data['city'] = $('input[name=city]').val();
	data['province'] = $('input[name=province]').val();
	data['address'] = $('input[name=address]').val();
	data['landing_page'] = $('input[name=lp]').val();
	data['number_of_debts'] = $('input[name=number_of_debts]').val();

	var types_of_debt = [];
	$('input[name="types_of_debt[]"]:checked').each(function() {
		types_of_debt.push($(this).val());
	});
	data['types_of_debt'] = types_of_debt.join(', ');
	// alert(data['types_of_debt']);
	// $.ajax({
	// 	'url': '/ajax_form.php',
	// 	'type': 'POST',
	// 	'data': data,
	// 	'success': function(return_data) {
	// 	}
	// });
			// var retunVar = {"success":true};
			// console.log(retunVar);
			// callback(retunVar);
}

function toTitleCase(str) {
	str = str.replace(/_/g, ' ');
	return str.replace(/\w\S*/g, function(txt){ return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();});
}

function TogglePopup(htmlPopup, isVisible, is_mobile){
        //$('#TermsPopup').find('table').css('width', '300px');
        //$('#PrivacyPopup').find('table').css('width', '300px');
        //$('.popup-box').css('width', '94%').css('margin-left', '0px');
        $(htmlPopup).find('table').css('width', '');
        if(isVisible) {
                $('body').unbind('click', clickOutsideClose);
                $(htmlPopup).unbind('click', clickInsideStop);

                $(htmlPopup).add('.popup-overlay').toggle(isVisible);
                currentlyOpenPopup = htmlPopup;
                setTimeout(function() {
                        $('body').bind('click', clickOutsideClose);
                        $(htmlPopup).bind('click', clickInsideStop);
                }, 250);
        } else {
                $(htmlPopup).add('.popup-overlay').toggle(isVisible);
                $('body').unbind('click', clickOutsideClose);
                $(htmlPopup).unbind('click', clickInsideStop);
        }
}
// Popup for privacy links & terms
function PrivacyPopup(isVisible){
        $('.privacy-popup').toggle(isVisible);
}
var currentlyOpenPopup;
var clickOutsideClose = function() {
        // console.log('closing from outside');
        $(currentlyOpenPopup).add('.popup-overlay').toggle(false);
};
var clickInsideStop = function(e) {
        e.stopPropagation();
};

function PostalValidLookup(postal_code, callback) {
	var data = {
		'postal_code': postal_code
	};
	
	$.ajax({
		'url': '/postal_code_check.php',
		'type': 'POST',
		'data': data,
		'success': function(return_data) {
			console.log(return_data);
			callback(return_data);
		},
		'error': function (return_data) {
			callback({"available":true});
		},
		'timeout': 3000
	});
}