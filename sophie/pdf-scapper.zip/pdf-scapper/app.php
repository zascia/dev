<?php

// Include Composer autoloader if not already done.
require_once 'vendor/autoload.php';
require_once 'src/Proxy.php';
require_once 'src/Epcreg.php';

use Smalot\PdfParser\Parser;
use src\Epcreg;

set_time_limit(0);
ini_set('memory_limit', '512M');

function getSqm($zip, $number, $flat, $street)
{
    $epcreg = Epcreg::instance();

    $address = sprintf('%s, %s, %s', $flat, $number, $street);
    printf("*** ZIP: %s, ADDRESS: %s\r\n", $zip, $address);

    $link = $epcreg->search($zip, $address);
    printf("- link to reports: %s\r\n", $link ? $link : 'Failed');

    if ($link) {
        $pdfLink = $epcreg->report($link);
        printf("- link to PDF: %s\r\n", $pdfLink ? $pdfLink : 'Failed');

        if ($pdfLink) {
            $pdfFile = $epcreg->download($pdfLink);
            printf("- download PDF file: %s\r\n", $pdfFile ? $pdfFile : 'Failed');

            if ($pdfFile) {
                $pdfInfo = pathinfo($pdfFile);
                $fixedPdf = $pdfInfo['dirname'] . '/' . $pdfInfo['filename'] . '_fixed.pdf';

                $qpdf = sprintf('%s/vendor/qpdf/bin/qpdf.exe --decrypt %s %s', __DIR__, $pdfFile, $fixedPdf);
                printf("- unlock PDF: %s\r\n", $fixedPdf);
                exec($qpdf);
                //unlink($qpdf);

                $parser = new Parser();
                $pdf = $parser->parseFile($fixedPdf);

                $text = $pdf->getText();

                if (preg_match('/Total floor area:(\d+)/i', $text, $match)) {
                    $sqm = intval($match[1]);
                    printf("- parse SQM: %d\r\n", $sqm);

                    return $sqm;
                } else {
                    printf("- SQM value not found\r\n");
                }
            }
        }
    }
    printf("=== done\r\n");

    return false;
}

$inputDir = __DIR__ . '/input/';
$outputDir = __DIR__ . '/output/' ;

if ($handle = opendir($inputDir)) {
    while (false !== ($csvFile = readdir($handle))) {
        if ($csvFile != "." && $csvFile != "..") {
            $inputCsvFile = $inputDir . $csvFile;
            $outputCsvFile = $outputDir . $csvFile;

            $inputCsv = fopen($inputCsvFile, 'r');
            $outputCsv = fopen($outputCsvFile, 'w');

            $header = fgetcsv($inputCsv);
            fputcsv($outputCsv, $header);

            while ($row = fgetcsv($inputCsv)) {
                $zip = $row[2];
                $number = $row[6];
                $flat = $row[7];
                $street = $row[8];

                $sqm = getSqm($zip, $number, $flat, $street);

                if ($sqm) {
                    $row[3] = $sqm;
                    fputcsv($outputCsv, $row);
                }
            }

            fclose($inputCsv);
            fclose($outputCsv);
            unlink($inputCsvFile);
        }
    }
    closedir($handle);
}
exit();