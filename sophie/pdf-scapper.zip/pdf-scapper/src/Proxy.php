<?php

namespace src;

class Proxy
{
    const LIST_URL = 'https://free-proxy-list.net';

    private $loaded;
    private $file;

    public function __construct()
    {
        $this->file = __DIR__ . '../run/proxy/dynamic.txt';
    }

    public function loadFile()
    {
        if (!$this->loaded) {

            if (!file_exists($this->file)) {
                $this->loadUrl();
            } else {
                $this->loaded = explode("\n", file_get_contents($this->file));
            }
        }

        return $this->loaded;
    }

    private function loadUrl()
    {
        $url = sprintf(self::LIST_URL, $this->type);

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10 );

        $res = curl_exec($ch);

        if (empty($res)) {
            $error = curl_error($ch);
            throw new Exception($error);
        } else {
            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($res);
            libxml_clear_errors();

            $xpath = new \DOMXPath($dom);
            $nodes = $xpath->query('//table[@id="proxylisttable"]//tr[position()>1]');

            if ($nodes->length > 0) {
                $this->loaded = [];
                /** @var \DOMNode $node */
                foreach ($nodes as $node) {
                    $td = $node->childNodes;
                    $ip = $td[0]->nodeValue;
                    $port = $td[1]->nodeValue;
                    $proto = (strtolower($td[6]->nodeValue) === 'yes' ? 'https' : 'http');
                    // filter by code
                    if ($td[2]->nodeValue === 'US') {
                        $this->loaded[] = $proto . '/' . $ip . ':' . $port;
                    }
                }
            }
            $this->save();
        }

        curl_close($ch);
    }

    public function save()
    {
        if (!empty($this->loaded)) {
            file_put_contents($this->file, implode("\n", $this->loaded));
        } else {
            @unlink($this->file);
        }
    }

    public function findNext($remove = false)
    {
        if ($remove) {
            array_shift($this->loaded);
            $this->save();
        }

        $this->loadFile();

        if (empty($this->loaded)) {
            throw new \Exception('No proxy server found.');
        }

        $parts = explode('/', $this->loaded[0]);

        return [
            'addr' => $parts[1],
            'type' => strtolower($parts[0]) === 'http' ? CURLPROXY_HTTP : CURLPROXY_HTTPS
        ];
    }
}