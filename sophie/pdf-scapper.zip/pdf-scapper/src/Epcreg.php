<?php

namespace src;

use src\Proxy;

class Epcreg
{
    const SITE_URL = 'https://www.epcregister.com';
    const MAX_ATTEMPTS = 10;

    private static $inst;

    private $cookieFile;
    private $cookiePath;

    private $pdfPath;
    /**
     * @var Proxy
     */
    private $proxy;

    private $isBadProxy;

    private $attempts;

    protected function __construct()
    {
        $this->cookieFile = 'cookie.txt';
        $this->cookiePath = __DIR__ . '/../run/';

        if (!file_exists($this->cookiePath)) {
            @mkdir($this->cookiePath, 0777, true);
        }

        if (!file_exists($this->cookiePath . $this->cookieFile)) {
            file_put_contents($this->cookiePath . $this->cookieFile, '');
        }

        $this->pdfPath = __DIR__ . '/../run/pdfs/';

        $this->proxy = new Proxy();
        $this->isBadProxy = false;
        $this->attempts = 0;
    }

    public static function instance()
    {
        if (!self::$inst) {
            self::$inst = new self();
        }

        return self::$inst;
    }

    private function isAuth($html)
    {
        return (stripos($html, 'action="reportSearchAddressTerms.html"') !== false);
    }

    private function isBlocked($html)
    {
        $proxyFlag = !$html;

        if ($proxyFlag) {
            $this->isBadProxy = true;
            $this->attempts ++;

            if ($this->attempts > self::MAX_ATTEMPTS) {
                throw new \Exception('Max attempts to unlock EPC Register has been reached. Try again.');
            }
        } else {
            $this->isBadProxy = false;
            $this->attempts = 0;
        }

        return $proxyFlag;
    }

    public function auth()
    {
        $url = self::SITE_URL . '/reportSearchAddressTerms.html';

        $html = $this->curl($url, [
            //'proxy' => $this->proxy->findNext($this->isBadProxy),
            'post' => [
                'redirectPage' => 'reportSearchAddressByPostcode',
                'accept' => 'Accept Terms'
            ],
            'headers' => [
                'Content-Type: application/x-www-form-urlencoded'
            ],
            'referer' => self::SITE_URL . '/reportSearchAddressTerms.html'
        ]);

        // if bad proxy or blocked
        /*if ($this->isBlocked($html)) {

            return $this->auth();
        }*/

        return $html;
    }

    public function search($zip, $address)
    {
        $url = self::SITE_URL . '/reportSearchAddressByPostcode.html';
        $address = str_replace(',', '', $address);

        $html = $this->curl($url, [
            //'proxy' => $this->proxy->findNext($this->isBadProxy)
        ]);

        // if auth required
        if ($this->isAuth($html)) {

            $html = $this->auth();
        }

        if ($html) {

            $postHtml = $this->curl($url, [
                //'proxy' => $this->proxy->findNext($this->isBadProxy),
                'post' => [
                    'postcode' => $zip
                ],
                'headers' => [
                    'Content-Type: application/x-www-form-urlencoded'
                ],
                'referer' => self::SITE_URL . '/reportSearchAddressByPostcode.html'
            ]);

            /*if ($this->isBlocked($postHtml)) {

                return $this->search($zip, $address);
            }*/

            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($postHtml);
            libxml_clear_errors();

            $xpath = new \DOMXPath($dom);

            $nodes = $xpath->query('//*[@id="maincontent"]/table//a');

            if ($nodes->length) {
                /** @var \DOMNode $node */
                foreach ($nodes as $node) {

                    $linkAddr = str_replace(',', '', $node->nodeValue);

                    if (stripos($linkAddr, $address) !== false) {

                        return $node->attributes->getNamedItem('href')->nodeValue;
                    }
                }
            }
        }

        return false;
    }

    public function report($link)
    {
        $html = $this->curl(self::SITE_URL . '/' . $link, [
            //'proxy' => $this->proxy->findNext($this->isBadProxy),
            'referer' => self::SITE_URL . '/reportSearchAddressByPostcode.html'
        ]);

        if ($html) {
            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($html);
            libxml_clear_errors();

            $xpath = new \DOMXPath($dom);

            $post = [
                'honeypot' => '',
            ];
            // address
            $node = $xpath->query('//*[@id="address"]')->item(0);

            if ($node) {
                $post['address'] = $node->attributes->getNamedItem('value')->nodeValue;
            }
            // id
            $node = $xpath->query('//*[@id="id"]')->item(0);

            if ($node) {
                $post['id'] = $node->attributes->getNamedItem('value')->nodeValue;
            }

            $postUrl = self::SITE_URL . '/reportSearchAddressSelectAddress.html';

            $postHtml = $this->curl($postUrl, [
                //'proxy' => $this->proxy->findNext($this->isBadProxy),
                'post' => $post,
                'referer' => $link
            ]);

            if ($postHtml) {
                $dom = new \DOMDocument();
                libxml_use_internal_errors(true);
                $dom->loadHTML($postHtml);
                libxml_clear_errors();

                $xpath = new \DOMXPath($dom);

                $node = $xpath->query('//*[@id="maincontent"]//tr[2]/td/p[1]/a')->item(0);

                return $node->attributes->getNamedItem('href')->nodeValue;
            }
        }

        return false;
    }

    public function download($link)
    {
        $url = self::SITE_URL . '/' . $link;
        $pdfFile = $this->pdfPath . 'report-' . time() . '.pdf';

        $pdf = $this->curl($url, []);

        if ($pdf) {
            file_put_contents($pdfFile, $pdf);

            return $pdfFile;
        }

        return false;
    }

    private function curl($url, $params = [])
    {
        $referer = isset($params['referer']) ? $params['referer'] : null;
        $proxy = isset($params['proxy']) ? $params['proxy'] : null;
        $extHeaders = isset($params['headers']) ? $params['headers'] : [];

        $headers = array_merge([
            'Host: www.epcregister.com',
            'Origin: https://www.epcregister.com',
            'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/78.0.3904.108 Safari/537.36',
            'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3',
            'Accept-Language: en-US,en;q=0.9,uk;q=0.8,ru;q=0.7',
            'Accept-Encoding: gzip, deflate, br',
            'Connection: keep-alive',
            'Cache-Control: no-cache',
            'Pragma: no-cache',
            'Upgrade-Insecure-Requests: 1'
        ], $extHeaders);

        if ($referer) {
            $headers[] = 'Referer: ' . $referer;
        }

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        //curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 90);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10 );

        // cookies storage / here the changes have been made
        curl_setopt($ch, CURLOPT_COOKIEJAR, $this->cookiePath . $this->cookieFile);
        curl_setopt($ch, CURLOPT_COOKIEFILE, $this->cookiePath . $this->cookieFile);

        if ($proxy) {
            curl_setopt($ch, CURLOPT_PROXY, $proxy['addr']);
            curl_setopt($ch, CURLOPT_PROXYTYPE, $proxy['type']);
            curl_setopt($ch, CURLOPT_PROXY_SSL_VERIFYHOST, false);
            curl_setopt($ch, CURLOPT_PROXY_SSL_VERIFYPEER, false);
            //curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, false);
            $this->isBadProxy = false;
        }

        $post = isset($params['post']) ? $params['post'] : false;

        if ( $post ) {
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post));
        }

        $result = curl_exec($ch);

        if ( empty($result) ) {
            $error = curl_error($ch);
            $this->isBadProxy = true;
            curl_close($ch);
            return false;
        } else {
            curl_close($ch);
            return $result;
        }
    }
}