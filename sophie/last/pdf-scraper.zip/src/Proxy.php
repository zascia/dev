<?php

namespace src;

class Proxy
{
    //const LIST_URL = 'https://free-proxy-list.net';
    const LIST_URL = 'https://www.sslproxies.org';

    const REUSE_ATTEMPTS = 10;

    private $loaded;
    private $current;

    private $dynamicFile;
    private $staticFile;

    private $file;
    private $useFree;

    public function __construct($useFree = false)
    {
        $this->dynamicFile = __DIR__ . '/../run/proxy/dynamic.txt';
        $this->staticFile = __DIR__ . '/../run/proxy/static.txt';
        $this->useFree = $useFree;
        $this->loadFile();
    }

    public function getStaticFile()
    {
        return $this->staticFile;
    }

    public function loadFile()
    {
        if (!$this->loaded) {

            if (file_exists($this->staticFile)) {
                $this->file = $this->staticFile;
                $this->loaded = preg_split('/[\r\n]+/', file_get_contents($this->file));
            } elseif ($this->useFree) {
                $this->file = $this->dynamicFile;

                if (file_exists($this->dynamicFile)) {
                    $this->loaded = explode("\n", file_get_contents($this->file));
                } else {
                    $this->loadUrl();
                }
            }
        }

        return $this->loaded;
    }

    private function loadUrl()
    {
        $ch = curl_init(self::LIST_URL);
        curl_setopt($ch, CURLOPT_HEADER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($ch, CURLOPT_MAXREDIRS, 10 );

        $res = curl_exec($ch);

        if (empty($res)) {
            $error = curl_error($ch);
            throw new \Exception($error);
        } else {
            $dom = new \DOMDocument();
            libxml_use_internal_errors(true);
            $dom->loadHTML($res);
            libxml_clear_errors();

            $xpath = new \DOMXPath($dom);
            $nodes = $xpath->query('//table[@id="proxylisttable"]//tr[position()>1]');

            if ($nodes->length > 0) {
                $this->loaded = [];
                /** @var \DOMNode $node */
                foreach ($nodes as $node) {
                    $td = $node->childNodes;
                    $ip = $td[0]->nodeValue;
                    $port = $td[1]->nodeValue;
                    $proto = (strtolower($td[6]->nodeValue) === 'yes' ? 'https' : 'http');
                    // filter by code
                    if ($td[2]->nodeValue === 'US') {
                        $this->loaded[] = $proto . '/' . $ip . ':' . $port;
                    }
                }
            }
            $this->save();
        }

        curl_close($ch);
    }

    public function save()
    {
        if (!empty($this->loaded)) {
            file_put_contents($this->file, implode("\n", $this->loaded));
        } else {
            @unlink($this->file);
			throw new \Exception('No proxies found.');
        }
    }

    public function reuse($incAttempts = true)
    {
        if (!$this->current) {
            throw new \Exception('No proxy to reuse');
        }

        $attempts = $this->current['attempts'];
        $proxy = $this->current['proxy'];
        $type = $this->current['type'];

        if ($attempts < self::REUSE_ATTEMPTS && !in_array($type, [CURLPROXY_HTTPS, CURLPROXY_HTTP])) {
            if ($incAttempts) {
                $attempts++;
            }
            $this->loaded[] = $proxy . '|' . intval($attempts);
        }

        $this->findNext(true);
    }

    public function findNext($remove = false)
    {
        // turn off proxies functionality
        return null;

        if ($remove) {
            array_shift($this->loaded);
            $this->save();
        }

        $this->loadFile();

        if (empty($this->loaded)) {
            throw new \Exception('No proxies found.');
        }

        $parts = explode('|', $this->loaded[0]);
        $proxy = $parts[0];
        $attempts = (isset($parts[1]) ? intval($parts[1]) : 0);

        $proxyParts = explode('/', $proxy);

        switch (strtolower($proxyParts[0])) {
            case 'https':
                $type = CURLPROXY_HTTPS;
                $txtType = 'http';
                break;
            case 'socks4':
                $type = CURLPROXY_SOCKS4;
                $txtType = 'socks5';
                break;
            case 'socks5':
                $type = CURLPROXY_SOCKS5;
                $txtType = 'socks5';
                break;
            default:
                $type = CURLPROXY_HTTP;
                $txtType = 'http';
        }

        $this->current = [
            'proxy' => $proxy,
            'attempts' => $attempts,
            'type' => $type,
            'txtType' => $txtType
        ];

        return [
            'addr' => $proxyParts[1],
            'type' => $type,
            'full' => $proxy,
            'txtType' => $txtType
        ];
    }
}