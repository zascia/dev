<?php

define('APP_PATH', __DIR__);

// Include Composer autoloader if not already done.
require_once 'vendor/autoload.php';
require_once 'src/Proxy.php';
require_once 'src/Epcreg.php';

use Smalot\PdfParser\Parser;
use src\Epcreg;

set_time_limit(0);
ini_set('memory_limit', '1024M');

$lockFile = __DIR__ . '/run/lock.pid';

if (file_exists($lockFile)) {
    printf("*** Another version of script is running. If not remove the /run/lock.pid\r\n");
	exit();
}

// lock start of another cron
file_put_contents($lockFile, '');

/**
 * Retrieve Sqm value from Epcreg.
 *
 * @param string $zip
 * @param string $number
 * @param string $flat
 * @param string $street
 *
 * @return bool|int
 * @throws Exception
 */
function getSqm($zip, $number, $flat, $street)
{
    $epcreg = Epcreg::instance();

    $address = sprintf('%s, %s, %s', $flat, $number, $street);
    printf("*** ZIP: %s, ADDRESS: %s\r\n", $zip, $address);

    $link = $epcreg->search($zip, $address);
    printf("- link to reports: %s\r\n", $link ? $link : 'Failed');

    if ($link) {
        $pdfLink = $epcreg->report($link);
        printf("- link to PDF: %s\r\n", $pdfLink ? $pdfLink : 'Failed');

        if ($pdfLink) {
            $pdfFile = $epcreg->download($pdfLink);
            printf("- download PDF file: %s\r\n", $pdfFile ? $pdfFile : 'Failed');

            if ($pdfFile) {
                $pdfInfo = pathinfo($pdfFile);
                $fixedPdf = $pdfInfo['dirname'] . '/' . $pdfInfo['filename'] . '_fixed.pdf';

                $qpdf = sprintf('%s/vendor/qpdf/bin/qpdf.exe --decrypt %s %s', __DIR__, $pdfFile, $fixedPdf);
                printf("- unlock PDF: %s\r\n", $fixedPdf);
                exec($qpdf);

                if (file_exists($fixedPdf)) {
                    $parser = new Parser();
                    $pdf = $parser->parseFile($fixedPdf);

                    $text = $pdf->getText();

                    if (preg_match('/Total floor area:(\d+)/i', $text, $match)) {
                        $sqm = intval($match[1]);
                        printf("- parse SQM: %d\r\n", $sqm);

                        return $sqm;
                    } else {
                        printf("- SQM value not found\r\n");
                    }
                } else {
                    printf("^ failed to unlock \r\n");
                }

            }
        }
        printf("=== done\r\n");
    }

    return false;
}

$inputDir = __DIR__ . '/input/';
$outputDir = __DIR__ . '/output/' ;

if ($handle = opendir($inputDir)) {
    while (false !== ($csvFile = readdir($handle))) {
        if ($csvFile != "." && $csvFile != "..") {
            $inputCsvFile = $inputDir . $csvFile;
            $outputCsvFile = $outputDir . $csvFile;

            $inputCsv = fopen($inputCsvFile, 'r');
            $header = fgetcsv($inputCsv);

            $addHeader = !file_exists($outputCsvFile);
            $outputCsv = fopen($outputCsvFile, 'a+');

            if ($addHeader) {
                fputcsv($outputCsv, $header);
            }

            try {
                while ($row = fgetcsv($inputCsv)) {
                    $zip = $row[2];
                    $number = $row[6];
                    $flat = $row[7];
                    $street = $row[8];

                    $sqm = getSqm($zip, $number, $flat, $street);

                    if ($sqm) {
                        $row[3] = $sqm;
                        fputcsv($outputCsv, $row);
                    }
                }
                fclose($inputCsv);
                unlink($inputCsvFile);
            } catch (\Exception $e) {
                printf("^^^ %s\r\n", $e->getMessage());
                // remove processed rows from input
                $tmpInputFile = $inputCsv . '-tmp';
                $tmpInput = fopen($tmpInputFile, 'w');
                fputcsv($tmpInput, $header);
                fputcsv($tmpInput, $row);

                while ($row = fgetcsv($inputCsv)) {
                    fputcsv($tmpInput, $row);
                }

                fclose($tmpInput);
                fclose($inputCsv);
                unlink($inputCsvFile);
                rename($tmpInputFile, $inputCsvFile);

                closedir($handle);
                @unlink($lockFile);
                exit();
            } finally {
                fclose($outputCsv);
            }
        }
    }
    closedir($handle);
}
// remove lock file to allow start
@unlink($lockFile);
exit();