<?php
// path to the domain names
$live_domain_list_filename = __DIR__ . '/domains/live_domains.txt';
$reserve_domain_list_filename = __DIR__ . '/domains/reserve_domains.txt';
$archived_domain_list_filename = __DIR__ . '/domains/archived_domains.txt';
$apikey = '10000017bf0628f872d0ab4b7204e9ebc341794';
?>