This script is checking all landings from the Binom account.
All domain lists are in the 3 txt files in the /domains folder.

live_domains.txt contains the list of actual domains for ping.
reserve_domains.txt is the place where the script takes new domains for replacement
archived_domains.txt is keeping all failed domains that were replaced