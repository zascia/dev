<?php  

/*-----------------------------------------------------------------------------
 * Stock Levels for Product Options
 *-----------------------------------------------------------------------------
 * stock_levels.viewcat1.inc.php
 *-----------------------------------------------------------------------------
 * Author:   Estelle Winterflood
 * Email:    cubecart@expandingbrain.com
 * Support:  http://support.expandingbrain.com
 * Store:    http://cubecart.expandingbrain.com
 *
 * Date:     October 22, 2006
 * Updated:  July 19, 2007
 * For CubeCart Version:  3.0.x
 *-----------------------------------------------------------------------------
 * TERMS OF USE:
 * Under no circumstances can this software be sold, given to another person or
 * publically posted without prior written permission from Estelle Winterflood.
 *-----------------------------------------------------------------------------
 * DISCLAIMER:
 * The modification is provided on an "AS IS" basis, without warranty of
 * any kind, including without limitation the warranties of merchantability,
 * fitness for a particular purpose and non-infringement. The entire risk
 * as to the quality and performance of the Software is borne by you.
 * Should the modification prove defective, you and not the author assume 
 * the entire cost of any service and repair. 
 *-----------------------------------------------------------------------------
 */


// VERSION 2.2 - THIS INCLUDE FILE NO LONGER NEEDS TO DO ANYTHING!

// HOWEVER KEEP THE FILE HERE FOR NOW, FOR STORES THAT ARE UPGRADING FROM EARLIER VERSIONS


?>
