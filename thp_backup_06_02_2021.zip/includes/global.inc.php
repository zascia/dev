<?php  
 

    $glob['dbdatabase'  ] = 'snoopido_ccrt3'          ;
    $glob['dbhost'      ] = 'localhost'        ;
    $glob['dbusername'  ] = 'snoopido_ccrt3'        ;
    $glob['dbpassword'  ] = 'b1wjTvoRFuw4'        ;
    $glob['dbprefix'    ] = ''                   ;
    $glob['installed'   ] = '1'                  ;
    $glob['rootDir'     ] = '/home/snoopido/public_html/nyah-beauty'       ;
    $glob['rootRel'     ] = '/' ;
    $glob['storeURL'    ] = 'http://www.nyah-beauty.com' ;

?>