INSERT INTO wd_g_accounts VALUES ('default1', 'Default account', 'Do not delete', '2005-02-22 07:14:08', 0);

INSERT INTO wd_g_settings VALUES ('60316fdc', 3, 'Aff_support_click_commissions', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316fd3', 3, 'Aff_support_sale_commissions', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316fd4', 3, 'Aff_support_lead_commissions', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316001', 3, 'Aff_fixed_cost', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316002', 3, 'Aff_join_campaign', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316003', 3, 'Aff_display_news', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316004', 3, 'Aff_display_resources', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316005', 3, 'Aff_display_banner_stats_all', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316006', 3, 'Aff_use_forced_matrix', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316007', 3, 'Aff_round_numbers', '2', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316008', 3, 'Aff_currency_left_position', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316009', 3, 'Aff_program_signup_bonus', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316010', 3, 'Aff_program_referral_commission', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316011', 3, 'Aff_overwrite_cookie', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316012', 3, 'Aff_delete_cookie', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316013', 3, 'Aff_referred_affiliate_allow', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316014', 3, 'Aff_permanent_redirect', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316015', 3, 'Aff_mail_send_type', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316040', 3, 'Aff_mail_type', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316041', 3, 'Aff_mail_charset', 'UTF-8', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316016', 3, 'Aff_log_level', '11', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('afdcffa5', 3, 'Aff_system_currency', '$', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('afdcffa6', 3, 'Aff_show_minihelp', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316017', 3, 'Aff_default_lang', 'english', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316018', 3, 'Aff_min_payout_options', '100;200;300;400;500', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316019', 3, 'Aff_initial_min_payout', '300', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316020', 3, 'Aff_affiliateapproval', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316021', 3, 'Aff_affpostsignupurl', 'postsignup.php', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316022', 3, 'Aff_allow_choose_lang', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316023', 3, 'Aff_link_style', '2', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316024', 3, 'Aff_forcecommfromproductid', 'no', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316025', 3, 'Aff_maxcommissionlevels', '10', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316026', 3, 'Aff_paging', '10', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316027', 3, 'Aff_login_protection_retries', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316028', 3, 'Aff_login_protection_delay', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316037', 1, 'Glob_accounts_dir', 'accounts', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316038', 3, 'Glob_acct_custom_template', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('23423423', 3, 'Aff_email_dailyreport', '0', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('60316039', 3, 'Aff_style_merchant_skin', 'default', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('4v8xc9v9', 3, 'Aff_style_affiliate_skin', 'default', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('8678a468', 3,'Aff_debug_emails','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('e6c1cf39', 3,'Aff_debug_impressions','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d74f71be', 3,'Aff_debug_clicks','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b4ca2aef', 3,'Aff_debug_sales','1','default1',NULL,NULL,NULL);

INSERT INTO wd_g_settings VALUES ('43425301', 3, 'Aff_menu_item_affprofile_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425302', 3, 'Aff_menu_item_subaffsignup_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425303', 3, 'Aff_menu_item_quick_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425304', 3, 'Aff_menu_item_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425305', 3, 'Aff_menu_item_traffic_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425306', 3, 'Aff_menu_item_subaffiliates_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425307', 3, 'Aff_menu_item_subid_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425308', 3, 'Aff_menu_item_afftopurls_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425309', 3, 'Aff_menu_item_contactus_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425310', 3, 'Aff_menu_item_banners_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('43425311', 3, 'Aff_menu_item_settings_show', 'true', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('8584a42a',3,'Aff_menu_item_profile_show','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('fdc43348',3,'Aff_menu_item_trans_show','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('75a76106',3,'Aff_menu_item_subaff_show','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('137a8997',3,'Aff_menu_item_topurls_show','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('91c56715',3,'Aff_menu_item_notif_show','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('cc22b9eb',3,'Aff_menu_item_faq_show','true','default1',NULL,NULL,NULL);


INSERT INTO wd_g_settings VALUES ('43425312', 6, 'Aff_camp_cookielifetime', '0', 'default1', '1', '1', NULL);
INSERT INTO wd_g_settings VALUES ('43425313', 3, 'Aff_acct_predefined_bannersizes', '88_31;120_60;120_90;125_125;236_60;468_60', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996013', 3, 'Aff_overwrite_cookie', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996018', 3, 'Aff_login_welcome_msg', 'Welcome to the affiliate program.', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996019', 3, 'Aff_display_news', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996020', 4, 'Aff_user_photo_url', 'http://www.affplanet.com/al/ad/man.gif', 'default1', '11111111', NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996021', 4, 'Aff_user_selected_info', 'photo_url,username,name,surname', 'default1', '11111111', NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996022', 3, 'Aff_signup_automatic_form', '1', 'default1', NULL, NULL, NULL);
INSERT INTO wd_g_settings VALUES ('78996014',3,'Aff_login_display_welcome','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('78996015',3,'Aff_login_display_statistics','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('78996016',3,'Aff_login_display_trendgraph','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('78996017',3,'Aff_login_display_manager','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('939ace0e',3,'Aff_login_display_text_in_the_middle','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('916b412d',3,'Aff_login_text_in_the_middle_msg','<p>\r\n    <span style=\"color: #3333cc; font-size: 14px; font-weight: bold; font-family: Tahoma;\">Getting Started As Affiliate</span>\r\n    </p>\r\n    <p>\r\n    Welcome to our affiliate program. On the left side you can see the menu that will help you orient in the system.\r\n    <br/>\r\n    In the <b>Banners</b> section you can get banners, text links, articles or reviews that you can use to promote our products.\r\n    <br/> \r\n    In <b>Reports</b> you can run various reports showing you trends of your promotion efforts over time <b>Traffic & Sales</b>, list of all <b>Transactions</b>, and so on.\r\n    </p>\r\n    \r\n    <br/>\r\n    <p>\r\n    <span style=\"color: #3333cc; font-size: 14px; font-weight: bold; font-family: Tahoma;\">A few ways to make money with our affiliate program</span>\r\n    </p>\r\n    \r\n    <p>\r\n    <ol>\r\n    <li><strong>Write a review of some of our products</strong>, letting people know how good it is. \r\n    Include your affiliate link at the end of the review. Post your review to free sites such \r\n    as <a href=\"http://www.GoArticles.com\" target=_blank>GoArticles.com</a> & <a href=\"http://www.EzineArticles.com\" target=_blank>EzineArticles.com</a>. \r\n    </li>\r\n    <li><strong>Create a free blog</strong> (web log) at sites such as Blogger.com, and post your review of our products, \r\n    including your affiliate link. Then \"ping\" your blog at a site such as Pingomatic.com, so it gets picked up quickly by search engines.\r\n    </li>\r\n    \r\n    <li><strong>Join popular marketing forums</strong> such as WarriorForum.com, and make frequent contributions to popular threads there. \r\n    Be sure to go into your forum profile and edit your \"signature\". Make a signature that includes your  affiliate link, \r\n    or a link to your own \"review\" website of our product. That way, every time you make a post, anyone who sees it will see your \r\n    signature and potentially click on your affiliate link.\r\n    </li>\r\n    \r\n    <li>Once every few weeks <strong>post a press release</strong> at PRweb.com, in which you include your favorable review of our product, \r\n    along with your affiliate link. If you pay them $80, they will guarantee that your press release is picked up by all major search \r\n    engines, potentially sending you thousands of visitors.\r\n    </li>\r\n    \r\n    <li>If you own an email list of <strong>newsletter</strong> subscribers or other people who have opted in to receive email offers from you, \r\n    send them an email telling them about our website, and feel free to use some text from our homepage in your email. Include \r\n    your affiliate link at the end of the email. You can even use our email sample above. \r\n    <br/>\r\n    *NOTE - We do not tolerate spamming in \r\n    any way. \r\n    </li>\r\n    \r\n    <li><strong>Pay-Per-Click</strong> (PPC):\r\n    Using a PPC account from Google Adwords, Overture, or many others, you can easily generate income with the our affiliate program. \r\n    You can either send people directly to us using your affiliate link in your PPC ads, or you can create your own website in which you have \r\n    a review of our product, followed by your affiliate tracking link. \r\n    </li>\r\n    \r\n    <li><strong>Upgrade yourself</strong><br/>\r\n    Being affiliate is not exceptionally difficult, but there are many tricks and techniques that can improve your results.\r\n    Learn from the best - <a style=\"color: #ff0000\" href=\"http://www.superaffiliatehandbook.com/cbae/?a=Zkjh06wHjL\" target=_blank><b>SuperAffiliate Handbook</b></a> is \r\n    highly recommended reading for every affiliate.\r\n    </li>\r\n    </ol>\r\n    </p>\r\n\r\n    <br/>\r\n    <p>\r\n    <span style=\"color: #3333cc; font-size: 14px; font-weight: bold; font-family: Tahoma;\">Tips and tricks to earn more as an affiliate</span>\r\n    </p>\r\n    \r\n    <p>\r\n    <ul>\r\n    <li>From our experience, you will get the best results from writing your own product reviews, even if it\'s short. \r\n        You don\'t have to be a good writer. Just write what you really think about the product. \r\n        When you publish your product review, use your general affiliate link (on the top) to send user to our website.\r\n    </li>\r\n    <br/>\r\n    <li>You will have much better conversion if you\'ll put your visitors into pre-sold mood before sending them to our site. \r\n        <br/>\r\n        Pre-sold mood means that you build interest in product and visitor has decided to potentially buy it after he reads your product review.\r\n        <br/>\r\n        Choose from various types of product descriptions, download and adjust them to fit in your site. \r\n        Experiment with short or long, try to find perfect combination with banners.\r\n    </li>\r\n    <br/>\r\n    <li>Try to think like a visitor, when he comes to your page with review or affiliate link, you should draw his attention, build curiosity\r\n        or feeling that he might need this kind of solution.\r\n    </li>\r\n    <br/>\r\n    <li>Experiment with different banners, text links, or reviews. Keep these that bring good results, and change the others.\r\n        Sometimes only change of few words or color of link can mean difference.\r\n    </li>\r\n    </ul>\r\n    </p>','default1',NULL,NULL,NULL);



INSERT INTO wd_g_settings VALUES ('067c22e8',3,'Aff_settings_mainpage_show_description','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('8b9c6e9d',3,'Aff_settings_mainpage_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('151af7db',3,'Aff_settings_affprofile_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('daf4aa18',3,'Aff_settings_banners_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('344054da',3,'Aff_settings_banners_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5c266818',3,'Aff_settings_banners_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ae177764',3,'Aff_settings_subaffsignup_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('abdf0ba1',3,'Aff_settings_subaffsignup_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('dcce7fe3',3,'Aff_settings_subaffsignup_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('e1ecb26f',3,'Aff_settings_quick_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('fe7515f7',3,'Aff_settings_quick_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c942a1e7',3,'Aff_settings_quick_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b1a4b176',3,'Aff_settings_transactions_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ff582f2d',3,'Aff_settings_transactions_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('0b7b84d4',3,'Aff_settings_transactions_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a4cb28ef',3,'Aff_settings_traffic_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7cd71174',3,'Aff_settings_traffic_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('0ec7aefd',3,'Aff_settings_traffic_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b48c3cf0',3,'Aff_settings_subaffiliates_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('76ead01b',3,'Aff_settings_subaffiliates_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('628ca545',3,'Aff_settings_subaffiliates_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('527051e5',3,'Aff_settings_subid_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('63690dd4',3,'Aff_settings_subid_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7bde5a09',3,'Aff_settings_subid_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f3622c39',3,'Aff_settings_afftopurls_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1000432d',3,'Aff_settings_afftopurls_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('2f1ffb04',3,'Aff_settings_afftopurls_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('abf6cfd9',3,'Aff_settings_settings_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1de2ae56',3,'Aff_settings_settings_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('4a41a274',3,'Aff_settings_settings_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f800843e',3,'Aff_settings_contactus_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('141b9c7e',3,'Aff_settings_contactus_show_customdescription','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('140e0dad',3,'Aff_settings_contactus_customdescription','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('e7c4ecce',3,'Aff_settings_faq_show_description','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('52872995',3,'Aff_settings_faq_show_customdescription','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c92117b5',3,'Aff_settings_faq_customdescription','<table width=\"780\"cellspacing=0 cellpadding-0>\r\n<tr>\r\n<td align=left>\r\n\r\n<table style=\"padding: 0px\"  border=0 cellspacing=0 cellpadding=2>\r\n    <tr><td align=left>  <a class=apFaq href=\"#whatineed\">1. How to start promoting your products?</a></td></tr>\r\n    <tr><td align=left>  <a class=apFaq href=\"#howpaid\">2. How do I know I will be paid for my referral?</a></td></tr>\r\n    <tr><td align=left>  <a class=apFaq href=\"#payment\">3. How is the payment handled?</a></td></tr>\r\n    <tr><td align=left>  <a class=apFaq href=\"#afflink\">4. What is the affiliate link?</a></td></tr>\r\n    <tr><td align=left>  <a class=apFaq href=\"#ppc\">5. Can I promote you through pay-per-click search engines?</a></td></tr>\r\n    <tr><td align=left>  <a class=apFaq href=\"#training\">6. Do you have any training program for affiliates?</a></td></tr>\r\n</table>\r\n</p>\r\n\r\n<br><br>\r\n<p>\r\n<a name=\"whatineed\"></a>\r\n<span class=\"apFaqAnswer\">1. How to start promoting your products?</span><br/>\r\nYou can see the Getting Started section on the main page after you log-in. \r\n<br>\r\nGeneraly, you should choose some banners and links, and place them onto your pages. When your visitor clicks on a banner, he will be redirected to our page. If this visitor buys something, you will be rewarded with a commission for this sale.\r\n</p>\r\n\r\n<p>\r\n<a name=\"howpaid\"></a>\r\n<span class=\"apFaqAnswer\">2. How do I know I will be paid for my referral?</span><br/>\r\nThe program is powered by <b>Post Affiliate Pro</b>, the leading affiliate tracking software.\r\nPost Affiliate Pro uses combination of cookies and IP address to track referrals for best possible reliability. \r\nWhen the visitor follows your affiliate link to our site, our affiliate system registers this referral and places cookie on his or her computer. \r\nWhen the visitor pays for the product, affiliate system checks for cookie (if not found, checks for IP address of referral) and credits \r\nyour account with commission. \r\n<br/>\r\nThis process is absolutely automatic. All your referrals will be properly tracked.\r\n</p>\r\n<p>\r\nPost Affiliate Pro is used by thousands of Internet merchants and affiliates world-wide. \r\n</p>\r\n\r\n<p>\r\n<a name=\"payment\"></a>\r\n<span class=\"apFaqAnswer\">3. How is the payment handled?</span><br/>\r\nYou can choose if you want to be paid by PayPal or by wire transfer, as well as minimum payout value ($100 minimum). \r\nWe do not support regular checks at the moment.\r\n<br/>\r\nPayments are issues in US dollars, and are paid <b>once a month</b>, always on 15th. \r\n</p>\r\n<p>\r\n<a name=\"afflink\"></a>\r\n<span class=\"apFaqAnswer\">4. What is the affiliate link?</span><br/>\r\nAffiliate link is a special URL where you should be sending the visitors. You will get the URL\'s for different banners\r\nin your affiliate panel after log in. \r\n</p>\r\n\r\n<p>\r\n<a name=\"ppc\"></a>\r\n<span class=\"apFaqAnswer\">5. Can I promote you through pay-per-click search engines?</span><br/>\r\nYES! You can promote us through pay-per-click search engines. In fact, this type of promotion becomes \r\nincreasingly popular and we are aware of several affiliates promoting our products in this way and making a very good profit. \r\n(Well, they keep promoting us month after month, which tells you something, doesn\'t it?)\r\n\r\nIf you are not familiar with with type of promotion, we recommend <a href=\"http://netquality.wingcube.hop.clickbank.net/\" target=_blank>this excellent ebook</a>. \r\nSome people are making MILLIONS promoting other people\'s products - why not you?\r\n</p>\r\n\r\n<p>\r\n<a name=\"whatnow\"></a>\r\n<span class=\"apFaqAnswer\">6. Do you have any training program for affiliates?</span><br/>\r\nThe basics of affiliate marketing and most useful tips are described in your affiliate panel. \r\nYou can find new tips and techniques also in our affiliate newsletter.\r\n<br/>\r\nIf you are serious with earning your income as an affiliate, we recommend \r\nexcellent <a href=\"http://www.superaffiliatehandbook.com/cbae/?a=Zkjh06wHjL\" target=_blank>SuperAffiliate Handbook</a>.\r\n</p>\r\n\r\n</td>\r\n</tr>\r\n</table>','default1',NULL,NULL,NULL);


INSERT INTO wd_g_settings VALUES ('2739f548',3,'Aff_style_c_normallink','#FF0000','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('8fcdde81',3,'Aff_style_c_helplink','#00AA00','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ce0b9f15',3,'Aff_style_c_textlink','#0056B6','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a2fb0e68',3,'Aff_style_c_error_border','#FF0000','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c9ca2889',3,'Aff_style_c_error_header','#FFA9A9','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('908e3967',3,'Aff_style_c_error_message','#FF0000','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('8c7db251',3,'Aff_style_c_ok_border','#00AA00','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('46f2762d',3,'Aff_style_c_ok_header','#BAFCBA','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('dd234c81',3,'Aff_style_c_ok_message','#00AA00','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5cdd8ff1',3,'Aff_style_c_footer_text','#555555','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('2a630357',3,'Aff_style_c_footer_background','#E8EDFA','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5505c066',3,'Aff_style_c_form_button','#B3CED9','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d6fab855',3,'Aff_style_c_frm_button_shadow','#B4B4B6','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b855227b',3,'Aff_style_c_frm_button_light','#F5F5F5','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c1507b66',3,'Aff_style_c_border','#5993AB','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('6e6ce0c8',3,'Aff_style_c_border2','#D9E6EC','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('be76e83b',3,'Aff_style_c_actionheader','#FFFFFF','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('557b55cb',3,'Aff_style_c_tableheader','#B3CED9','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('449bf520',3,'Aff_style_c_tableheader2','#D6DFF5','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1c82ff7c',3,'Aff_style_c_listheader','#D9E6EC','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ebac34ee',3,'Aff_style_c_listheader_sort','#B3CED9','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('67830a89',3,'Aff_style_c_listresult_row1','#FFFFFF','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7675f9d7',3,'Aff_style_c_listresult_row2','#E8EDFA','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a233bc2a',3,'Aff_style_c_datail_row1','#EBEEF5','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f878eda6',3,'Aff_style_c_datail_row2','#F2F5FC','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('874c1f46',3,'Aff_style_c_background','#E8EDFA','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('9385969d',3,'Aff_style_c_background_logo','#FFFFFF','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5a55b7fd',3,'Aff_style_c_bacground_active','#B3CED9','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1da2a4a8',3,'Aff_style_c_menu_link','#0056B6','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f7869da1',3,'Aff_style_c_menu_link2','#0056B6','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('0c1c8958',3,'Aff_style_c_menu_link_disbled','#666666','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('bc17a4e9',4,'Aff_user_icq','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('08c6b3c4',4,'Aff_user_msn','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('37a45385',4,'Aff_user_skype','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b719fd51',4,'Aff_user_yahoomessenger','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5648e1a3',4,'Aff_user_googletalk','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('706f8417',4,'Aff_user_other_name','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('efd4dd7e',4,'Aff_user_other_contact','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('cbbae032',4,'Aff_user_photo_url','../affiliate-manager.gif','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7aa3fad5',4,'Aff_user_welcome_msg','Hello and welcome to our affiliate program.\r\n      <br/>\r\n      I\'m your affiliate manager, and I\'m here for you if you have ANY questions or problems related to our affiliate program.\r\n      <br/><br/>\r\n      I wish you all success in promoting our products, and profitable partnership for both you and us.\r\n','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('3aff3269',4,'Aff_user_custom_html','','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('6cc87d6b',4,'Aff_user_selected_info','photo_url,welcome_msg','default1','1',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ds5fds68',5,'Aff_min_payout','300','default1','2',NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ds5fds69',5,'Aff_payoptionfield_paypal01','test@test.test','default1','2','paypal01',NULL);

INSERT INTO wd_g_settings VALUES ('6f76ac90',3,'Aff_signup_terms_conditions','To be an authorized affiliate of www.yoursite.com, you agree to abide by the terms and conditions contained in this agreement.\r\n\r\nEnter Your Terms & Conditions Here','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1cf7c642',3,'Aff_signup_display_terms','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1967072e',3,'Aff_signup_force_acceptance','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('87378f58',3,'Aff_signup_affect_editing','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('de243cc7',3,'Aff_signup_phone','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('ea21e59e',3,'Aff_signup_phone_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c5ac8f03',3,'Aff_signup_fax','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('1c43ee8f',3,'Aff_signup_fax_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f8542885',3,'Aff_signup_tax_ssn','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('da426588',3,'Aff_signup_tax_ssn_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('aed560ea',3,'Aff_signup_data1','0','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d5f3a27e',3,'Aff_signup_data1_mandatory','hide','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('0620dca6',3,'Aff_signup_data1_name','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('bea3f852',3,'Aff_signup_data2','0','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a32a2d49',3,'Aff_signup_data2_mandatory','hide','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5cbd13b3',3,'Aff_signup_data2_name','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('eca39e30',3,'Aff_signup_data3','0','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('67f77e5c',3,'Aff_signup_data3_mandatory','hide','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('cee8a009',3,'Aff_signup_data3_name','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('3b0529b9',3,'Aff_signup_data4','0','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('caddaeeb',3,'Aff_signup_data4_mandatory','hide','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f3e2e9f6',3,'Aff_signup_data4_name','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('dfde94a8',3,'Aff_signup_data5','0','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('8c340688',3,'Aff_signup_data5_mandatory','hide','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b94d0339',3,'Aff_signup_data5_name','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b30d0924',3,'Aff_signup_refid','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('3f711726',3,'Aff_signup_refid_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('aa22566b',3,'Aff_signup_description','<b>Welcome To The Post Affilaite Pro Demo Affiliate Program!</b>\r\n\r\n<p>\r\nOur program is free to join, it\'s easy to sign-up and requires no technical knowledge.<br>\r\n</p>\r\n\r\n<p>\r\n<b>How does it work</b><br>\r\nWhen you join our program you will get an access to your own control panel. There you can get banners and text links to promote our site. \r\n<br>\r\nWhen you refer some customer to us, you will receive a percentage of his purchase as a reward.\r\n</p>\r\n\r\n<p>\r\n<b>Real-Time Statistics And Reporting</b><br/>\r\nCheck your statistic, sales, traffic, account balance and see how your banners are performing anytime inyour affiliate panel.\r\n</p>\r\n\r\n<p>\r\n<b>Affiliate Program Details</b><br/>\r\nCommission: <font color=#ff0000><b>pay per sale 10%</b></font>\r\n</p>','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d8d02be9',3,'Aff_signup_display_description','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('f854040e',3,'Aff_signup_username','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('c48510c6',3,'Aff_signup_username_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('e71940ac',3,'Aff_signup_name','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('8bf0b0c3',3,'Aff_signup_name_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d78b2875',3,'Aff_signup_surname','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('17a90bc4',3,'Aff_signup_surname_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('6c5554b5',3,'Aff_signup_street','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('94f204a5',3,'Aff_signup_street_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('9b4cd65c',3,'Aff_signup_city','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5d20a253',3,'Aff_signup_city_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('e21dd880',3,'Aff_signup_company_name','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d69da25b',3,'Aff_signup_company_name_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5734a90e',3,'Aff_signup_state','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('d95dcfc1',3,'Aff_signup_state_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('0bc27d29',3,'Aff_signup_zipcode','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('69906596',3,'Aff_signup_zipcode_mandatory','false','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7dc591ad',3,'Aff_signup_weburl','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('85504dff',3,'Aff_signup_weburl_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('35feef34',3,'Aff_signup_country','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b8f8aa2e',3,'Aff_signup_country_mandatory','true','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a476eee5',3,'Aff_bannerformat_textformat','<a href=$DESTINATION><b>$TITLE</b><br>$DESCRIPTION$IMPRESSION_TRACK</a>','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('a476eee6',3,'Aff_bannerformat_graphicformat','<a href=$DESTINATION><img src=$IMAGE_SRC alt="$ALT" title="$ALT"></a>','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('702176a5',3,'Aff_p3p_xml','p3p.xml','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('eb161702',3,'Aff_p3p_compact','NOI NID ADMa DEVa PSAa OUR BUS ONL UNI COM STA OTC','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b0ee0521',3,'Aff_track_by_ip','1','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('7d1ea272',3,'Aff_track_by_browser','','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b6f50a3d',3,'Aff_ip_validity','24','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b52bcf76',3,'Aff_ip_validity_type','hours','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('b589cf76',3,'Aff_integration_version','1000006','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5ece17b5',3,'Aff_resources_dir','resources','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('5ece17b6',3,'Aff_nonreferred_signup','_','default1',NULL,NULL,NULL);
INSERT INTO wd_g_settings VALUES ('33d7462f',3,'Aff_default_campaign','1','default1',NULL,NULL,NULL);

INSERT INTO wd_g_settings VALUES ('camp1_01',6,'Aff_camp_status','1','default1',1,1,NULL);
INSERT INTO wd_g_settings VALUES ('camp1_02',6,'Aff_camp_clickapproval','2','default1',1,1,NULL);
INSERT INTO wd_g_settings VALUES ('camp1_03',6,'Aff_camp_cookielifetime','0','default1',1,1,NULL);
INSERT INTO wd_g_settings VALUES ('camp1_04',6,'Aff_camp_saleapproval','2','default1',1,1,NULL);
INSERT INTO wd_g_settings VALUES ('camp1_05',6,'Aff_camp_signup_bonus','0','default1',1,1,NULL);

INSERT INTO wd_g_emailtemplates VALUES ('1','AFF_EMAIL_SIGNUP','Thank you for joining','Dear $Affiliate_name,\r\n\r\nthank you for joining our affiliate program.\r\n\r\nYour username is: $Affiliate_username\r\nYour password is: $Affiliate_password\r\nYou can log in into your control panel in url: http://www.yoursite.com/affiliate/affiliates/\r\n\r\nIf you have any requests regarding the affiliate program, don\'t hesitate to contact me on the email address.\r\n\r\nsincerelly,\r\n\r\nYour Affiliate manager',0,'English','default1');
INSERT INTO wd_g_emailtemplates VALUES ('2','AFF_EMAIL_NTF_SIGNUP','New affiliate signup','Email notification\r\n\r\nNew affiliate joined your affiliate program. Affiliate details:\r\n\r\nName: $Affiliate_name\r\nUsername/email: $Affiliate_username\r\nWebsite: $Affiliate_website\r\nCountry: $Affiliate_country\r\nStatus: $Affiliate_status ',0,'English','default1');
INSERT INTO wd_g_emailtemplates VALUES ('3','AFF_EMAIL_NTF_SALE','New sale','Affiliate Program Email Notification\r\n\r\nNew sale was registered by affiliate program. Sale details:\r\n\r\nTransaction ID:  $Sale_id\r\nCommission:  $Sale_commission\r\nTotal cost:  $Sale_totalcost\r\nOrderID:  $Sale_orderid\r\nProductID:  $Sale_productid\r\nDate&time:  $Sale_date\r\nAffiliate:  $Sale_affiliate\r\nStatus:  $Sale_status\r\nIP address:  $Sale_ip\r\nReferrer:  $Sale_referrer\r\n',0,'English','default1');
INSERT INTO wd_g_emailtemplates VALUES ('5','AFF_EMAIL_AF_NTF_SGN','New affiliate signup','Affiliate Program Email Notification\r\n\r\nNew affiliate joined the affiliate program. Affiliate details:\r\n\r\nUsername/email: $Affiliate_username\r\nWebsite: $Affiliate_website\r\nCountry: $Affiliate_country\r\nStatus: $Affiliate_status ',0,'English','default1');
INSERT INTO wd_g_emailtemplates VALUES ('6','AFF_EMAIL_AF_NTF_SLE','New sale commission','Affiliate Program Email Notification\r\n\r\nNew sale was registered by affiliate program. Sale details:\r\n\r\nCommission:  $Sale_commission\r\nOrderID:  $Sale_orderid\r\nProductID:  $Sale_productid\r\nDate&time:  $Sale_date\r\nStatus:  $Sale_status\r\nIP address:  $Sale_ip\r\nReferrer:  $Sale_referrer\r\n',0,'English','default1');
INSERT INTO wd_g_emailtemplates VALUES ('491603db','AFF_EMAIL_FORGOTPAS1','Forgot password - step1','Hello,\r\n\r\nplease use the verification code below in the step 2:\r\n$Affiliate_verification_code\r\n\r\n\r\n',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('a8a1013a','AFF_EMAIL_FORGOTPAS2','Forgot password','Hello,\r\n\r\nyour password was set to: $Affiliate_password\r\nYour username is: $Affiliate_username',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('1916de1b','AFF_EMAIL_CONTACT_US','Message from affiliate','$Date $Time\r\n\r\nAffiliate: $Affiliate_id - $Affiliate_name\r\n\r\nSubject: $Affiliate_emailsubject\r\n\r\nText:\r\n$Affiliate_emailtext',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('5f6e0260','AFF_EMAIL_ONSIGN','Thank you for signing up','Dear $Affiliate_name,\r\n\r\nthank you for signing up to our affiliate program. Your application will be reviewed and you will receive email with access information after approval.\r\n\r\nIf you have any requests regarding the affiliate program, don\'t hesitate to contact me on the email address\r\nname@yoursite.com.\r\n\r\nsincerelly,\r\n\r\nYour Affiliate manager',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('091ab586','AFF_EMAIL_MONTH_REP','Monthly report $Date-$Month','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('70aedbf5','AFF_EMAIL_WE_REP','Weekly Report $Date','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('574e3282','AFF_EMAIL_AF_ML_REP','Monthly report $Date $Month','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('5b108965','AFF_EMAIL_AFF_WE_REP','Weekly report','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('5535e79a','AFF_EMAIL_NOTIFY_RC','New recurring commission was regerated','Email Notification\r\n\r\nNew recurring commission was generated\r\n\r\n$Date\r\n$Time\r\n$Rc_id\r\n$Rc_commission\r\n$Rc_orderid\r\n$Rc_affiliate\r\n$Rc_status\r\n$Rc_recurringcommissionid',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('4cc40c29','AFF_EMAIL_DAILY_REP','Daily Report $Date','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('f595c543','AFF_EMAIL_AF_DL_REP','Daily report $Date','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('3cd5c8e5','AFF_EMAIL_AF_WE_REP','Weekly Report $Date','Impressions: $Impressions\r\nClicks: $Clicks\r\nSales: $Sales_approved\r\nLeads: $Leads_approved\r\nCommissions: $Commissions_approved\r\n\r\n-----------------------------------\r\n$Sales_list\r\n\r\n\r\n-----------------------------------\r\n$Leads_list',0,'english','default1');
INSERT INTO wd_g_emailtemplates VALUES ('ed25972d','AFF_EMAIL_AFF_CAMP_A','You have been approved','Dear $Affiliate_name,\r\n\r\nyou have been approved for campaign $camp_name.\r\n\r\nBest regards,\r\n\r\nYour affiliate manager',0,'english','default1');


INSERT INTO wd_g_righttypes VALUES("01", "02", "", "campaigns", "aff_camp_product_categories", "view", "0000-00-00 00:00:00", "L_G_RT_CAMPAIGNS", "L_G_CAMPAIGNS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("02", NULL, "", "campaigns", "aff_camp_product_categories", "modify", "0000-00-00 00:00:00", "L_G_RT_CAMPAIGNS", "L_G_CAMPAIGNS", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("03", "04", "", "affiliates", "aff_aff_affiliates", "view", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_AFFILIATES", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("04", NULL, "", "affiliates", "aff_aff_affiliates", "modify", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_AFFILIATES", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("05", "06", "", "affiliates", "aff_aff_pay_affiliates", "view", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_PAYOUT", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("06", NULL, "", "affiliates", "aff_aff_pay_affiliates", "modify", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_PAYOUT", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("07", "08", "", "affiliates", "aff_aff_accounting", "view", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_ACCOUNTING", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("08", NULL, "", "affiliates", "aff_aff_accounting", "modify", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_ACCOUNTING", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("09", "10", "", "transactions", "aff_trans_transactions", "view", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_TRANSACTIONS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("10", "11", "", "transactions", "aff_trans_transactions", "approvedecline", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_TRANSACTIONS", "L_G_RT_APPROVE_DECLINE", "2");
INSERT INTO wd_g_righttypes VALUES("11", NULL, "", "transactions", "aff_trans_transactions", "modify", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_TRANSACTIONS", "L_G_RT_MODIFY", "3");
INSERT INTO wd_g_righttypes VALUES("12", NULL, "", "reports", "aff_rep_quick_report", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_QUICK", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("13", NULL, "", "reports", "aff_rep_transactions", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_TRANSACTIONS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("14", NULL, "", "reports", "aff_rep_traffic_and_sales", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_TRAFFIC", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("15", NULL, "", "reports", "aff_rep_top_20_affiliates", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_TOP20AFFILIATES", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("16", NULL, "", "reports", "aff_rep_number_of_affiliates", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_AFFILIATECOUNTS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("17", "18", "", "communication", "aff_comm_email_templates", "view", "0000-00-00 00:00:00", "L_G_COMMUNICATION", "L_G_EMAILTEMPLATES", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("18", NULL, "", "communication", "aff_comm_email_templates", "modify", "0000-00-00 00:00:00", "L_G_COMMUNICATION", "L_G_EMAILTEMPLATES", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("19", NULL, "", "communication", "aff_comm_broadcast_email", "use", "0000-00-00 00:00:00", "L_G_COMMUNICATION", "L_G_BROADCAST_MESSAGE", "L_G_RT_USE", "0");
INSERT INTO wd_g_righttypes VALUES("20", "21", "", "tools", "aff_tool_admins", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_ADMINS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("21", NULL, "", "tools", "aff_tool_admins", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_ADMINS", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("22", "23", "", "tools", "aff_tool_user_profiles", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_USER_PROFILES_MANAGER", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("23", NULL, "", "tools", "aff_tool_user_profiles", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_USER_PROFILES_MANAGER", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("24", "25", "", "tools", "aff_tool_settings", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_SETTINGS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("25", NULL, "", "tools", "aff_tool_settings", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_SETTINGS", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("26", NULL, "", "tools", "aff_tool_integration", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_INTEGRATIONCODE", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("27", "28", "", "tools", "aff_tool_history", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_HISTORY", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("28", NULL, "", "tools", "aff_tool_history", "purge", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_HISTORY", "L_G_RT_PURGE", "2");
INSERT INTO wd_g_righttypes VALUES("29", NULL, "", "tools", "aff_tool_db_maintenance", "backup", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_MAINTENANCE", "L_G_RT_BACKUP", "1");
INSERT INTO wd_g_righttypes VALUES("30", NULL, "", "tools", "aff_tool_db_maintenance", "restore", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_MAINTENANCE", "L_G_RT_RESTORE", "2");
INSERT INTO wd_g_righttypes VALUES("31", "32", "", "transactions", "aff_trans_recurr_transactions", "view", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_RECURRINGCOMMS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("32", "33", "", "transactions", "aff_trans_recurr_transactions", "approvedecline", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_RECURRINGCOMMS", "L_G_RT_APPROVE_DECLINE", "2");
INSERT INTO wd_g_righttypes VALUES("33", NULL, "", "transactions", "aff_trans_recurr_transactions", "modify", "0000-00-00 00:00:00", "L_G_TRANSACTIONS", "L_G_RECURRINGCOMMS", "L_G_RT_MODIFY", "3");
INSERT INTO wd_g_righttypes VALUES("34", "35", "", "campaigns", "aff_camp_banner_links", "view", "0000-00-00 00:00:00", "L_G_RT_CAMPAIGNS", "L_G_BANNERS", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("35", NULL, "", "campaigns", "aff_camp_banner_links", "modify", "0000-00-00 00:00:00", "L_G_RT_CAMPAIGNS", "L_G_BANNERS", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("36", "37", "", "communication", "aff_comm_communications", "view", "0000-00-00 00:00:00", "L_G_COMMUNICATION", "L_G_COMMUNICATION", "L_G_RT_VIEW", "1");
INSERT INTO wd_g_righttypes VALUES("37", NULL, "", "communication", "aff_comm_communications", "modify", "0000-00-00 00:00:00", "L_G_COMMUNICATION", "L_G_COMMUNICATION", "L_G_RT_MODIFY", "2");
INSERT INTO wd_g_righttypes VALUES("38", NULL, "", "reports", "aff_rep_top_urls", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_TOPREFERRINGURLS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("39", NULL, "", "reports", "aff_rep_top_campaigns", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_TOPCAMPAIGNS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("41", NULL, "", "reports", "aff_rep_non_perform_affiliates", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_NONPERFORMAFFILIATES", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("42", NULL, "", "reports", "aff_rep_rotator", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_ROTATORSTATS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("51", NULL, "", "tools", "aff_tool_db_maintenance", "repair", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_MAINTENANCE", "L_G_RT_REPAIROPTIMIZE", "3");
INSERT INTO wd_g_righttypes VALUES("52", NULL, "", "tools", "aff_tool_integration", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_INTEGRATIONCODE", "L_G_RT_MODIFY", "1");
INSERT INTO wd_g_righttypes VALUES("53", NULL, "", "tools", "aff_tool_signupsettings", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_AFFSIGNUPSETTINGS", "L_G_RT_MODIFY", "1");
INSERT INTO wd_g_righttypes VALUES("55", NULL, "", "tools", "aff_tool_signupsettings", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_AFFSIGNUPSETTINGS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("56", NULL, "", "tools", "aff_tool_afflayoutsettings", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_LAYOUTSETTINGS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("57", NULL, "", "affiliates", "aff_aff_accountingsettings", "view", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_ACCOUNTINGSETTINGS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("58", NULL, "", "affiliates", "aff_aff_accountingsettings", "modify", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_ACCOUNTINGSETTINGS", "L_G_RT_MODIFY", "0");
INSERT INTO wd_g_righttypes VALUES("59", NULL, "", "affiliates", "aff_aff_appliedaffiliates", "view", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_APPLIEDAFFILIATES", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("60", NULL, "", "affiliates", "aff_aff_appliedaffiliates", "modify", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_APPLIEDAFFILIATES", "L_G_RT_MODIFY", "0");
INSERT INTO wd_g_righttypes VALUES("61", NULL, "", "affiliates", "aff_aff_appliedaffiliates", "approvedecline", "0000-00-00 00:00:00", "L_G_AFFILIATES", "L_G_APPLIEDAFFILIATES", "L_G_RT_APPROVE_DECLINE", "0");
INSERT INTO wd_g_righttypes VALUES("62", NULL, "", "tools", "aff_tool_affpanelsettings", "view", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_PANELSETTINGS", "L_G_RT_VIEW", "0");
INSERT INTO wd_g_righttypes VALUES("63", NULL, "", "tools", "aff_tool_db_maintenance", "archive", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_MAINTENANCE", "L_G_RT_ARCHIVE", "4");
INSERT INTO wd_g_righttypes VALUES("64", NULL, "", "tools", "aff_tool_affpanelsettings", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_PANELSETTINGS", "L_G_RT_MODIFY", "1");
INSERT INTO wd_g_righttypes VALUES("65", NULL, "", "tools", "aff_tool_afflayoutsettings", "modify", "0000-00-00 00:00:00", "L_G_TOOLS", "L_G_LAYOUTSETTINGS", "L_G_RT_MODIFY", "1");
INSERT INTO wd_g_righttypes VALUES("66", NULL, "", "reports", "aff_rep_impclicks", "view", "0000-00-00 00:00:00", "L_G_REPORTS", "L_G_IMPRESSIONCLICKS", "L_G_RT_VIEW", "1");


INSERT INTO wd_g_userprofiles VALUES ('userpro1', 'Default admin profile', '3', 'default1');


INSERT INTO wd_g_userrights VALUES("303322f3", "userpro1", "01");
INSERT INTO wd_g_userrights VALUES("98edf3f2", "userpro1", "02");
INSERT INTO wd_g_userrights VALUES("6d0469b2", "userpro1", "03");
INSERT INTO wd_g_userrights VALUES("8a264905", "userpro1", "04");
INSERT INTO wd_g_userrights VALUES("3591ac15", "userpro1", "05");
INSERT INTO wd_g_userrights VALUES("fe7c978a", "userpro1", "06");
INSERT INTO wd_g_userrights VALUES("9eaa424f", "userpro1", "07");
INSERT INTO wd_g_userrights VALUES("de631656", "userpro1", "08");
INSERT INTO wd_g_userrights VALUES("62670421", "userpro1", "09");
INSERT INTO wd_g_userrights VALUES("8a721021", "userpro1", "10");
INSERT INTO wd_g_userrights VALUES("6bfdc423", "userpro1", "11");
INSERT INTO wd_g_userrights VALUES("55bae64f", "userpro1", "12");
INSERT INTO wd_g_userrights VALUES("0acf1810", "userpro1", "13");
INSERT INTO wd_g_userrights VALUES("7a209eb2", "userpro1", "14");
INSERT INTO wd_g_userrights VALUES("75d8c0f7", "userpro1", "15");
INSERT INTO wd_g_userrights VALUES("c2c671fe", "userpro1", "16");
INSERT INTO wd_g_userrights VALUES("0f2295a4", "userpro1", "17");
INSERT INTO wd_g_userrights VALUES("f5f6a7f6", "userpro1", "18");
INSERT INTO wd_g_userrights VALUES("e4025111", "userpro1", "19");
INSERT INTO wd_g_userrights VALUES("d6f68d7a", "userpro1", "20");
INSERT INTO wd_g_userrights VALUES("c677b9d0", "userpro1", "21");
INSERT INTO wd_g_userrights VALUES("39d51858", "userpro1", "22");
INSERT INTO wd_g_userrights VALUES("df484242", "userpro1", "23");
INSERT INTO wd_g_userrights VALUES("18f2a81a", "userpro1", "24");
INSERT INTO wd_g_userrights VALUES("c702dc78", "userpro1", "25");
INSERT INTO wd_g_userrights VALUES("46cb70c0", "userpro1", "26");
INSERT INTO wd_g_userrights VALUES("fd95d2e5", "userpro1", "27");
INSERT INTO wd_g_userrights VALUES("44d46fef", "userpro1", "28");
INSERT INTO wd_g_userrights VALUES("0723cf68", "userpro1", "29");
INSERT INTO wd_g_userrights VALUES("0e8581e8", "userpro1", "30");
INSERT INTO wd_g_userrights VALUES("a0c939d5", "userpro1", "31");
INSERT INTO wd_g_userrights VALUES("c5bcad90", "userpro1", "32");
INSERT INTO wd_g_userrights VALUES("715114df", "userpro1", "33");
INSERT INTO wd_g_userrights VALUES("e5597917", "userpro1", "34");
INSERT INTO wd_g_userrights VALUES("79cc1788", "userpro1", "35");
INSERT INTO wd_g_userrights VALUES("eede7703", "userpro1", "36");
INSERT INTO wd_g_userrights VALUES("cdc30ab1", "userpro1", "37");
INSERT INTO wd_g_userrights VALUES("cdc59g1u", "userpro1", "38");
INSERT INTO wd_g_userrights VALUES("c285fdsg", "userpro1", "39");
INSERT INTO wd_g_userrights VALUES("g45h4g41", "userpro1", "41");
INSERT INTO wd_g_userrights VALUES("grte4g41", "userpro1", "42");
INSERT INTO wd_g_userrights VALUES("g45h4g51", "userpro1", "51");
INSERT INTO wd_g_userrights VALUES("g45h4g52", "userpro1", "52");
INSERT INTO wd_g_userrights VALUES("g45h4g53", "userpro1", "53");
INSERT INTO wd_g_userrights VALUES("g45h4g55", "userpro1", "55");
INSERT INTO wd_g_userrights VALUES("g45h4g56", "userpro1", "56");
INSERT INTO wd_g_userrights VALUES("g45h4g57", "userpro1", "57");
INSERT INTO wd_g_userrights VALUES("g45h4g58", "userpro1", "58");
INSERT INTO wd_g_userrights VALUES("g45h4g59", "userpro1", "59");
INSERT INTO wd_g_userrights VALUES("g45h4g60", "userpro1", "60");
INSERT INTO wd_g_userrights VALUES("g45h4g61", "userpro1", "61");
INSERT INTO wd_g_userrights VALUES("g45h4g62", "userpro1", "62");
INSERT INTO wd_g_userrights VALUES("g45h4g63", "userpro1", "63");
INSERT INTO wd_g_userrights VALUES("g45h4g64", "userpro1", "64");
INSERT INTO wd_g_userrights VALUES("g45h4g65", "userpro1", "65");
INSERT INTO wd_g_userrights VALUES("g45h4g66", "userpro1", "66");


INSERT INTO wd_pa_campaigns VALUES ('1', 'default1', 'Test Sale campaign', 'Test Sale campaign description', 'Test Sale campaign short description','2005-02-22 10:28:23', 0, 0, 7, '123;456;789');

INSERT INTO wd_pa_bannercategories VALUES ('79bf2443','Text links');
INSERT INTO wd_pa_bannercategories VALUES ('fe50b29a','Graphic banners');
INSERT INTO wd_pa_bannercategories VALUES ('2ed1e0ca','Articles & Reviews');

INSERT INTO wd_pa_banners VALUES ('2','Test banner','Test banner','http://www.qualityunit.com/','Test banner title',1,0,'1',0,'','2006-06-20 15:47:40','79bf2443');
INSERT INTO wd_pa_banners VALUES ('c01ba2c5','Test graphic banner','','http://www.qualityunit.com/','../banners/sample_banner.gif',2,0,'1',0,'','2006-06-21 10:02:52','fe50b29a');
INSERT INTO wd_pa_banners VALUES ('33c1a035','Test html banner','           <table width=\"100%\" border=0 cellpadding=3>\r\n            <tr>\r\n              <td align=left valign=top><img src=\"../banners/pap_box.gif\"></td>\r\n              <td>   </td>\r\n              <td align=left valign=top>\r\n                <b>Post Affiliate Pro</b><br>\r\n\r\n                - a powerful affiliate management system that allows you:<br>\r\n                - easy set up and maintain your own affiliate program  <br>\r\n                - pay your affiliates per lead per click per sale or %commission.<br>\r\n                - multi-tier commissions: up to 10 tiers<br>\r\n                - get more traffic for you website without additional costs<br>\r\n                - increase sales<br>\r\n                - already used by more than thousand merchants worldwide\r\n                <BR>\r\n              </td>\r\n            </tr>\r\n            <tr>\r\n              <td colspan=3 align=left>\r\n              Post Affiliate Pro offers you a vast spectrum of features and PRICE / FEATURES RATIO IS THE BEST you can find.\r\n              <BR>You also get FREE INSTALLATION, lifetime upgrades and fast and helpful support.\r\n\r\n\r\n\r\n              <br><br>\r\n              <b>Post Affiliate Pro</b> is compatible with nearly all merchant accounts, payment gateways, shopping carts and \r\n              membership systems. \r\n              <br/>\r\n              <a style=\"color:red;\" href=\"$CLICKURL_NOTENCODED\">Click here to learn more</a> \r\n</td>\r\n</table>\r\n','http://www.qualityunit.com/','',3,0,'1',0,'','2006-06-21 10:10:06','2ed1e0ca');
INSERT INTO wd_pa_banners VALUES ('f6ae0ff3','','<OBJECT classid=\"clsid:D27CDB6E-AE6D-11cf-96B8-444553540000 codebase=\"http:// download.macromedia.com/pub/shockwave/cabs/ flash/swflash.cab#version=4,0,0,0\" ID=ad_banner_example1 WIDTH=468 HEIGHT=60>\r\n\r\n<PARAM NAME=movie VALUE=\"ad_banner_example.swf?clickTAG=$CLICKURL\">\r\n<PARAM NAME=loop VALUE=false>\r\n<PARAM NAME=menu VALUE=false>\r\n<PARAM NAME=quality VALUE=medium>\r\n<PARAM NAME=bgcolor VALUE=#FFFFFF>\r\n\r\n<EMBED src=\"ad_banner_example.swf?clickTAG=$CLICKURL\" loop=false menu=false quality=medium bgcolor=#FFFFFF swLiveConnect=FALSE WIDTH=468 HEIGHT=60 TYPE=\"application/x-shockwave-flash\">','http://www.aaa.com/maros/','',3,1,'1',0,'','2006-06-21 10:16:56','_');


INSERT INTO wd_pa_campaigncategories VALUES ('1', 'L_G_UNASSIGNED_USERS', 0, 0, 10, 20, 0, '$', NULL, 1, '1', '$', '$', 0, 9, 0, 8, 0, 7, 0, 6, 0, 5, 0, 4, 0, 3, 0, 2, 0, 1, '$', 0, 0, 0, 0, 0, 0, 0, 0, 0);

INSERT INTO wd_pa_payoutoptions VALUES("paypal01", "default1", "PayPal", "0", "PPEMAIL\\t$Affiliate_amount\\tUSD\\t$Affiliate_name\\r\\n", "0", "L_G_METHODPAYPAL", "2", "<form action=\"https://www.paypal.com/cgi-bin/webscr\" method=\"post\" target=_blank>\r\n<input type=\"hidden\" name=\"currency_code\" value=\"USD\">\r\n<input type=\"hidden\" name=\"no_note\" value=\"1\">\r\n<input type=\"hidden\" name=\"amount\" value=\"$Affiliate_amount\">\r\n<input type=\"hidden\" name=\"item_number\" value=\"Affiliate_Payment_$Date\">\r\n<input type=\"hidden\" name=\"item_name\" value=\"Affiliate Program Payment\">\r\n<input type=\"hidden\" name=\"business\" value=\"PPEMAIL\">\r\n<input type=\"hidden\" name=\"cmd\" value=\"_xclick\">\r\n<input type=\"submit\" name=\"submit\" value=\"Pay by PayPal\">\r\n</form>\r\n");
INSERT INTO wd_pa_payoutoptions VALUES ('moneyboo','default1','MoneyBookers',0,'',0,'L_G_PAYOUTMB', 3, '');
INSERT INTO wd_pa_payoutoptions VALUES ('check001','default1','Check',0,'',0,'L_G_PAYOUTCHECK', 1, '');
INSERT INTO wd_pa_payoutoptions VALUES ('wiretran','default1','Bank/Wire transfer',0,'',0,'L_G_PAYOUTWIRE', 4, '');


INSERT INTO wd_pa_payoutfields VALUES ('paypal01','paypal01','PPEMAIL','PayPal Email','L_G_METHODFIELDPAYPALEMAIL',1,0,1,'',1,'');
INSERT INTO wd_pa_payoutfields VALUES ('moneybo1','moneyboo','MBEMAIL','MoneyBookers email','L_G_PAYOUTFIELDMBEMAIL',1,0,1,'',1,'');
INSERT INTO wd_pa_payoutfields VALUES ('check001','check001','CHPAYABLETO','Payable to','L_G_PAYOUTFIELDPAYABLETO',1,0,1,'',1,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra1','wiretran','BANKACCNAME','Bank account name','L_G_PAYOUTFIELDBANKACCNAME',1,0,1,'',1,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra2','wiretran','BANKNAME','Bank name','L_G_PAYOUTFIELDBANKNAME',1,0,1,'',2,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra3','wiretran','BANKACCNUMBER','Account number','L_G_PAYOUTFIELDACCNUMBER',1,0,1,'',3,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra4','wiretran','BANKCODE','Bank code','L_G_PAYOUTFIELDBANKCODE',1,0,1,'',4,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra5','wiretran','BANKADDRESS','Bank address','L_G_PAYOUTFIELDBANKADDRESS',1,0,1,'',5,'');
INSERT INTO wd_pa_payoutfields VALUES ('wiretra6','wiretran','BANKSWIFT','S.W.I.F.T code','L_G_PAYOUTFIELDSWIFT',1,0,1,'',6,'');

INSERT INTO wd_g_messages VALUES ('bf0ec759', 2, '2006-03-03 08:32:00', 'Welcome to Affiliate Program', 'Dear $Affiliate_name,\r\n\r\nwelcome to our affiliate program.\r\n\r\nYour Affiliate Manager\r\n', 0, 'default1', '2006-03-03 00:00:00', '2008-04-03 23:59:59', 1, 1);

INSERT INTO wd_g_users VALUES ('2','default1','','test@test.test','test','Test','Surname',2,'','2006-06-20 15:47:40',NULL,0,'',4,'',0,0,'','http://www.mywebsite.com','','','','United States','','','','','','','','','','paypal01','',0);


insert into wd_pa_integration
values('general1',
'General solution', '',
'AffPlanet is compatible with nearly ALL merchant accounts, payment gateways, shopping carts and membership systems.<br/><br/><b>What integration means</b><br>
Integration is a way to connect the affiliate system to your current website, shopping cart or payment gateway in a way that affiliate system will
be notified about purchases. When notified, affiliate system registers the sale, finds referring affiliate (if any) and creates appropriate commission for him.
<br/><br/>
The general method of integration is putting an invisible image anywhere in the "thank you for order" or order confirmation page that is displayed to the customer
after the payment is processed.',
'This is all that is required. Now whenever there\'s sale, the sale tracking script sale.php is called, and it will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('general1', 'general1', 1,
'<b>Open your order confirmation or "thank you for order" page template, and put the following code somewhere onto the page</b>',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n<script type=\"text/javascript\"><!--\r\n\r\nvar TotalCost="XXXXXX.XX";\r\nvar OrderID="XXXXXX";\r\nvar ProductID="XXXXXX";\r\npapSale();\r\n--></script>',
'where the values XXXXXX should be replaced with correct values for:<br/>
<b>TotalCost</b> (mandatory for % commissions) - price of the product <br/>
<b>OrderID</b> (optional) - can be your unique generated order ID to cross-check the sale. <br/>
<b>ProductID</b> (optional) - the ID of the product bought.
<br/><br/>
All fields are optional, but without TotalCost system will be not able to compute percentage commissions.
<br/>
Also, ProductID is required if you plan to use <b>Force choosing commission by product ID</b> - this is available only in Pro version.
<br/><br/>
If you need to set total sale cost and order id, but you don\'t have access to their values in your "Thank you" page, the situation is more complicated.
There is no general solution for this. If you know that you can register sale in some other place, where those values (total cost and order id) are available, you can put the tracking code there.
Otherwise, consult us for advice and finding possible solution. ',
'english');


insert into wd_pa_integration
values('oscom01',
'osCommerce', '',
'Integration with osCommerce is made by placing sale tracking script into the confirmation page. To obtain the values of OrderID and TotalSale, snippet connects to osCommerce database and retrieves the values from there.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('oscom01', 'oscom01', 1,
'Find and open file <b>checkout_success.php</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('oscom02', 'oscom01', 2,
'Inside the file find this line <br>
<b><i>if ($global[\'global_product_notifications\'] != \'1\') {<br>
...
</i></b>',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('oscom03', 'oscom01', 3,
'insert the following code just above that line',
'  //--------------------------------------------------------------------------\n
  // integration code\n
  //--------------------------------------------------------------------------\n
  // get order id\n
  $sql = "select orders_id from ".TABLE_ORDERS.\n
         " where customers_id=\'".(int)$customer_id.\n
         "\' order by date_purchased desc limit 1";\n
  $pap_orders_query = tep_db_query($sql);\n
  $pap_orders = tep_db_fetch_array($pap_orders_query);\n
  $pap_order_id = $pap_orders[\'orders_id\'];\n
\n
  // get total amount of order\n
  $sql = "select value from ".TABLE_ORDERS_TOTAL.\n
         " where orders_id=\'".(int)$pap_order_id.\n
         "\' and class=\'ot_subtotal\'";\n
  $pap_orders_total_query = tep_db_query($sql);\n
  $pap_orders_total = tep_db_fetch_array($pap_orders_total_query);\n
  $pap_total_value = $pap_orders_total[\'value\'];\n
\n
  // draw invisible image to register sale\n
  if($pap_total_value != "" && $pap_order_id != "")\n
  {\n
    $img = \'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n<script type=\"text/javascript\"><!--\r\n\r\nvar TotalCost="\'.$pap_total_value.\'";\r\nvar OrderID="\'.$pap_order_id.\'";\r\nvar ProductID="";\r\npapSale();\r\n--></script>\';\n
    print $img;\n
  }\n
  //--------------------------------------------------------------------------\n
  // END of integration code\n
  //--------------------------------------------------------------------------\n
',
'',
'english');


insert into wd_pa_integrationsteps
values('oscom04', 'oscom01', 4,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');



insert into wd_pa_integration
values('crelo01',
'CRE Loaded', '',
'Integration with CRE Loaded is made by placing sale tracking script into the confirmation page. To obtain the values of OrderID and TotalSale, snippet connects to CRE Loaded database and retrieves the values from there.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('crelo01', 'crelo01', 1,
'Find and open file: <br> <b>checkout_success.php</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('crelo02', 'crelo01', 2,
'Inside this find this lines: <br>\n<b><i>  // load all enabled checkout success modules<br>\nrequire(DIR_WS_CLASSES . \'checkout_success.php\');\n</i></b>',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('crelo03', 'crelo01', 3,
'Before these lines insert this code:',
' //--------------------------------------------------------------------------\n  // Post Affiliate Pro code\n  // The code below will get the order_id and total value of recent order\n  // from the database and displays invisible image that registers the sale\n  // for affiliate (if some affiliate referred this visitor)\n  //--------------------------------------------------------------------------\n\n  // get order id\n  $sql = "select orders_id from ".TABLE_ORDERS.\n         " where customers_id=\'".(int)$customer_id.\n         "\' order by date_purchased desc limit 1";\n  $pap_orders_query = tep_db_query($sql);\n  $pap_orders = tep_db_fetch_array($pap_orders_query);\n  $pap_order_id = $pap_orders[\'orders_id\'];\n\n  // get total amount of order\n  $sql = "select value from ".TABLE_ORDERS_TOTAL.\n         " where orders_id=\'".(int)$pap_order_id.\n         "\' and class=\'ot_subtotal\'";\n  $pap_orders_total_query = tep_db_query($sql);\n  $pap_orders_total = tep_db_fetch_array($pap_orders_total_query);\n  $pap_total_value = $pap_orders_total[\'value\'];\n\n  // draw invisible image to register sale\n  if($pap_total_value != "" && $pap_order_id != "")\n  {\n    $pap_sale_img = \'<img src=\"$SCRIPTDIRsale.php?TotalCost=\'.$pap_total_value.\'&OrderID=\'.$pap_order_id.\'" width=1 height=1>\';\n  }\n\n  //--------------------------------------------------------------------------\n  // END of Post Affiliate Pro code\n  //--------------------------------------------------------------------------',
'',
'english');

insert into wd_pa_integrationsteps
values('crelo04', 'crelo01', 4,
'Find and open file: <b>/templates/content/checkout_success.tpl.php</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('crelo05', 'crelo01', 5,
'In this file find: <br> <b> &lt;?php require(\'add_checkout_success.php\'); //ICW CREDIT CLASS/GV SYSTEM ?&gt;</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('crelo06', 'crelo01', 6,
'After this line insert this code:',
'&lt;?php\n//--------------------------------------------------------------------------\n// START of Post Affiliate Pro code\n//--------------------------------------------------------------------------\necho $pap_sale_img;\n//--------------------------------------------------------------------------\n// END of Post Affiliate Pro code\n//--------------------------------------------------------------------------\n?&gt',
'',
'english');


insert into wd_pa_integrationsteps
values('crelo07', 'crelo01', 7,
'Your CRE Loaded shopping cart is integrated now. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.<br>\n<b>Note:</b> Tested on CRE Loaded 6.2 Pro B2B 6.2.06',
'',
'',
'english');





insert into wd_pa_integration
values('2check01',
'2Checkout', '',
'2Checkout system has two versions (1 and 2). affiliate software can be easily integrated with both of them. They way of integration is the same, the versions differÂ only in structure of menu in 2checkout control panel.
2Checkout directly supports putting the hidden image tag on the sales confirmation page.',
'This is all that is required. Now whenever there\'s sale, 2checkout will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('2check01', '2check01', 1,
'Log-in to 2checkout vendor panel, go to <b>Look and Feel</b> and put the following URL to the <b>Affiliate URL</b> &lt;img src = field:',
'$SCRIPTDIRsale.php?TotalCost=$a_total&OrderID=$a_order&ProductID=$a_product',
'',
'english');


insert into wd_pa_integration
values('paypal01',
'PayPal', '',
'PayPal integrates using IPN callback.<br/>
Note! This is description of integration with PayPal if you use PayPal buttons on your web pages. If you use PayPal as a processing system in your shopping cart,
use the method for integrating with shopping cart, not these steps.
<br/>
Also, make sure you don\'t already use PayPal IPN for another purpose, such as some kind of digital delivery or membership registration.',
'This is all that is required. Now whenever there\'s sale, PayPal will use its IPN function to call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('paypal01', 'paypal01', 1,
'Now add the following code into EVERY PayPal button form',
'<input type="hidden" name="notify_url" value="$SCRIPTDIRpaypal.php">\n
<input type="hidden" name="custom" value="" id="pap_dx8vc2s5">\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\n
<script type="text/javascript"><!--\n
\n
paypalSale();\n
--></script>\n',
'This will tell PayPal that it should silently
call <b>$SCRIPTDIRpaypal.php</b> script upon every sale, and it will pass
all sale variables including the custom field to this script.', 'english');

insert into wd_pa_integrationsteps
values('paypal02', 'paypal01', 2,
'Example of updated PayPal form:<br/><br/>
<code>
&lt;!-- Begin PayPal Button --&gt;<br/>
&lt;form action="https://www.paypal.com/cgi-bin/webscr" method="post"&gt;<br/>
&lt;input type="hidden" name="cmd" value="_xclick"&gt;<br/>
&lt;input type="hidden" name="business" value="paypalemail@yoursite.com"&gt;<br/>
&lt;input type="hidden" name="undefined_quantity" value="1"&gt;<br/>
&lt;input type="hidden" name="item_name" value="Product Name"&gt;<br/>
&lt;input type="hidden" name="amount" value="19.95"&gt;<br/>
&lt;input type="hidden" name="image_url" value="https://yoursite.com/images/paypaltitle.gif"&gt;<br/>
&lt;input type="hidden" name="no_shipping" value="1"&gt;<br/>
&lt;input type="hidden" name="return" value="http://www.yoursite.com/paypalthanks.html"&gt;<br/>
&lt;input type="hidden" name="cancel_return" value="http://www.yoursite.com"&gt;<br/>
<b>&lt;input type="hidden" name="notify_url" value="$SCRIPTDIRpaypal.php"&gt;<br/>
&lt;input type="hidden" name="custom" value="" id="pap_dx8vc2s5"&gt;<br/>
&lt;script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"&gt;&lt;/script&gt;<br/>
&lt;script type="text/javascript"&gt;&lt;!--<br/>
<br/>
paypalSale();<br/>
--&gt;&lt;/script&gt;<br/></b>
&lt;input type="image" src="http://images.paypal.com/images/x-click-but5.gif" border="0" name="submit"&gt;<br/>
&lt;/form&gt;<br/>
&lt;!-- End PayPal Button --&gt;</code>',
'',
'', 'english');



insert into wd_pa_integration
values('stormp01',
'StormPay', '',
'StormPay integration is similar to PayPal, it also uses StormPay\'s IPN callback.<br/>
Note! This is description of integration with StormPay if you use StormPay buttons on your web pages. If you use StormPay as a processing system in your shopping cart,
use the method for integrating with shopping cart, not these steps.
<br/>
Also, make sure you don\'t already use StormPay IPN for another purpose, such as some kind of digital delivery or membership registration.',
'This is all that is required. Now whenever there\'s sale, StormPay will use its IPN function to call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('stormp01', 'stormp01', 1,
'Now add the following code into EVERY StormPay button form',
'<input type="hidden" name="user1" value="" id="pap_dx8vc2s5">\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\n
<script type="text/javascript"><!--\n
\n
paypalSale();\n
--></script>\n',
'This will tell StormPay that it should silently
call <b>$SCRIPTDIRstormpay.php</b> script upon every sale, and it will pass
all sale variables including the custom field to this script.', 'english');


insert into wd_pa_integrationsteps
values('stormp02', 'stormp01', 2,
'Example of updated StormPay form:<br/><br/>
<code>
&lt;form action="http://www.stormpay.com....&gt;<br/>
... <br/>
&lt;input type="hidden" name="user1" value="" id="pap_dx8vc2s5"&gt;<br/>
&lt;script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"&gt;&lt;/script&gt;<br/>
&lt;script type="text/javascript"&gt;&lt;!--<br/>
<br/>
paypalSale();<br/>
--&gt;&lt;/script&gt;<br/>
...<br/>
&lt;/form&gt;<br/>',
'',
'', 'english');

insert into wd_pa_integrationsteps
values('stormp04', 'stormp01', 3,
'Next step is to configure StormPay to use IPN callback to our
stormpay script.
There is an <b>IPN Cofiguration</b> section of your <b>Profile / Setup</b> page.
You should specify there full url to the stormpay script: ',
'$SCRIPTDIRstormpay.php',
'', 'english');



insert into wd_pa_integration
values('worldp01',
'WorldPay', '',
'WorldPay integration is similar to PayPal, it also uses WorldPay callback.<br/>
Note! This is description of integration with WorldPay if you use WorldPay buttons on your web pages. If you use WorldPay as a processing system in your shopping cart,
use the method for integrating with shopping cart, not these steps.
<br/>
Also, make sure you don\'t already use WorldPay callback for another purpose, such as some kind of digital delivery or membership registration.',
'This is all that is required. Now whenever there\'s sale, WorldPay will use its callback function to call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('worldp01', 'worldp01', 1,
'Now add the following code into EVERY WorldPay button form',
'<input type="hidden" name="M_aid" value="" id="pap_dx8vc2s5">\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\n
<script type="text/javascript"><!--\n
\n
paypalSale();\n
--></script>\n',

'This will tell WorldPay that it should silently
call <b>$SCRIPTDIRworldp.php</b> script upon every sale, and it will pass
all sale variables including the custom field to this script.', 'english');


insert into wd_pa_integrationsteps
values('worldp02', 'worldp01', 2,
'Example of updated WorldPay form:<br/><br/>
<code>
&lt;form action="http://www.worldpay.com....&gt;<br/>
... <br/>
&lt;input type="hidden" name="M_aid" value="" id="pap_dx8vc2s5"&gt;<br/>
&lt;script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"&gt;&lt;/script&gt;<br/>
&lt;script type="text/javascript"&gt;&lt;!--<br/>
<br/>
paypalSale();<br/>
--&gt;&lt;/script&gt;<br/>
...<br/>
&lt;/form&gt;<br/>',
'',
'', 'english');

insert into wd_pa_integrationsteps
values('worldp03', 'worldp01', 3,
'Next step is to configure WorldPay to use callback to our
worldpay script.
You should specify there full url to the worldpay script: ',
'$SCRIPTDIRworldpay.php',
'', 'english');



insert into wd_pa_integration
values('amembe01',
'aMember', '',
'aMember uses a variation of General solution, it tracks sales by invoking hidden script from "thank you" page.',
'This is all that is required. Now whenever there\'s sale, aMember will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('amembe01', 'amembe01', 1,
'Put the following code to the aMember thanks.html page',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n
<script type=\"text/javascript\"><!--\r\n
\r\n
var TotalCost="{$payment.amount}";\r\n
var OrderID="{$payment.payment_id}";\r\n
var ProductID="{$payment.product_id}";\r\n
papSale();\r\n
--></script>',
'',
'english');


insert into wd_pa_integration
values('snscar01',
'SecureNetShop (snscart)', '',
'To integrate with SecureNetShop you have to display affiliate-tracking code in the "receipt page" of the shopping cart.',
'This is all that is required. Now whenever there\'s sale, aMember will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);

insert into wd_pa_integrationsteps
values('snscar01', 'snscar01', 1,
'Click on the <b>Settings</b> menu in your shopping cart administration area',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('snscar02', 'snscar01', 1,
'Click on <b>Order tracking</b> that will be displayed under "Marketing". ',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('snscar03', 'snscar01', 1,
'Click on the <b>Add new</b> button.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('snscar04', 'snscar01', 1,
'Choose your affiliate tracking provider from the list of options or else enter the tracking codes in the text box <b>Tracking code</b>. You can also choose the substitution codes for the affiliate tracking.<br/>
The tracking code is:',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n<script type=\"text/javascript\"><!--\r\n\r\nvar TotalCost="XXXXXXXX";\r\nvar OrderID="XXXXXX";\r\nvar ProductID="XXXXXX";\r\npapSale();\r\n--></script>',
'where the values XXXXXX should be replaced with correct values for:<br/>
<b>TotalCost</b> (mandatory for % commissions) - price of the product <br/>
<b>OrderID</b> (optional) - can be your unique generated order ID to cross-check the sale. <br/>
<b>ProductID</b> (optional) - the ID of the product bought.
<br/><br/>',
'english');

insert into wd_pa_integrationsteps
values('snscar05', 'snscar01', 1,
'Choose the placement conditions and than click on the save button.',
'',
'',
'english');



insert into wd_pa_integration
values('ccbill01',
'ccBill', '',
'Integration with ccBill can be made using the Approval URL supported by them.',
'This is all that is required. Now whenever there\'s sale, ccBill will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('ccbill01', 'ccbill01', 1,
'Login to your ccBill <b>Admin Center</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('ccbill02', 'ccbill01', 1,
'Go to <b>Account Maintenance -> Account Admin</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('ccbill03', 'ccbill01', 1,
'Click on the sub/account (if applicable),then on advanced (left side menu) and place the following code into the <b>Approval Post URL</b> section:.',
'$SCRIPTDIRccBill.php',
'',
'english');


insert into wd_pa_integration
values('psigat01',
'PSiGate', '',
'PSiGate uses a variation of General solution, it tracks sales by invoking hidden script from "thank you" page.',
'This is all that is required. Now whenever there\'s sale, PSiGate will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('psigat01', 'psigat01', 1,
'Specify your own thank you page for PsiGate and put there the following code',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n
<script type=\"text/javascript\"><!--\r\n
\r\n
var TotalCost="SubTotal";\r\n
var OrderID="OrdNo";\r\n
var ProductID="";\r\n
papSale();\r\n
--></script>',
'',
'english');



insert into wd_pa_integration
values('clicar01',
'ClickCartPro', '',
'Integration with ccBill can be made using the Approval URL supported by them.
 Go to Account Maintenance -> Account Admin. ',
'This is all that is required. Now whenever there\'s sale, ClickCartPro will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('clicar01', 'clicar01', 1,
'Login to your ClickCartPro <b>Admin Center</b> and go to the <b>Main Menu</b>. ',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('clicar02', 'clicar01', 1,
'go to <b>HTML Pages and Elements - > Manage Site Elements</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('clicar03', 'clicar01', 1,
'Open and update this template: <b>Order Confirmation - Third Party Affiliate Program Placeholder</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('clicar04', 'clicar01', 1,
'Place the following code anywhere in the box (all in one line) and click submit:',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>
<script type=\"text/javascript\">\r\n<!--\r\n
\r\nvar TotalCost="(CGIVAR)tracking_subtotal(/CGIVAR)";\r\nvar OrderID="(CGIVAR)tracking_id(/CGIVAR)";\r\nvar ProductID="";\r\npapSale();\r\n-->\r\n</script>',
'',
'english');

insert into wd_pa_integration
values('hspher01',
'H-Sphere', '',
'Integration with any affiliate system is directly supported by H-Sphere.',
'This is all that is required. Now whenever there\'s sale, H-Sphere will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('hspher01', 'hspher01', 1,
'Log-in to your <b>H-Sphere Admin Center</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('hspher02', 'hspher01', 1,
'Go to <b>Settings - Affiliate Program</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('hspher03', 'hspher01', 1,
'Leave AutoInsert set to amount and place the following code into the area for Link 1:',
'$SCRIPTDIRsale.php?TotalCost=${amount}',
'',
'english');


insert into wd_pa_integration
values('mambop01',
'mambo-phpShop', '',
'Integration with mambo-phpShop is made by placing sale tracking script into the order confirmation page.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('mambop01', 'mambop01', 1,
'open and edit the temlate file that displays order confirmation page. It is the file
<b>/mambo/administrator/components/com_phpshop/classes/ps_checkout.php</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('mambop02', 'mambop01', 2,
'Find the following code which should already exist in the file.  <br>
<code>if (AFFILIATE_ENABLE == \'1\') { $ps_affiliate->register_sale($order_id); }</code>',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('mambop03', 'mambop01', 3,
'Cut/Paste the following code into the file, under the code found above:',
'print \'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>
<script type=\"text/javascript\">\r\n<!--\r\n\r\nvar TotalCost=\"\'.$order_subtotal.\'\";\r\nvar OrderID=\"\'.$order_id.\'\";\r\nvar ProductID=\"\";\r\npapSale();\r\n-->\r\n</script>\';',
'',
'english');


insert into wd_pa_integrationsteps
values('mambop04', 'mambop01', 4,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');


insert into wd_pa_integration
values('shopsi01',
'ShopSite', '',
'Integration with ShopSite is made by placing sale tracking script into the order confirmation page.',
'This is all that is required. Now whenever there\'s sale, ShopSite will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('shopsi01', 'shopsi01', 1,
'Log-in to your <b>ShopSite Admin Center</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('shopsi02', 'shopsi01', 1,
'Click on <b>Commerce Setup -> Order System -> Thank You</b>.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('shopsi03', 'shopsi01', 1,
'Cut/Paste the following code into the top box labeled <b>Information on the Thank You screen to return to storefront</b>:',
'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>\r\n
<script type=\"text/javascript\"><!--\r\n
\r\n
var TotalCost=ss_subtotal;\r\n
var OrderID=ss_ordernum;\r\n
var ProductID="";\r\n
papSale();\r\n
--></script>',
'',
'english');


insert into wd_pa_integration
values('yahoos01',
'Yahoo Stores', '',
'Integration with Yahoo Stores is made by placing sale tracking script into the order confirmation page.',
'This is all that is required. Now whenever there\'s sale, Yahoo Stores will call our sale tracking script, and system will generate commission for the affiliate.',
0, 1);


insert into wd_pa_integrationsteps
values('yahoos01', 'yahoos01', 1,
'Login to your <b>Yahoo Store Manager and click Order Settings -> Order Form</b>',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('yahoos02', 'yahoos01', 1,
'Find the box labeled: <b>Order Confirmation : Message</b>, place the following code into the box and click done.',
'<script>
<!--\r\n
function getSaleInfo(){\r\n
var totalCost;\r\n
var orderId;\r\n
bs = bs2 = document.getElementsByTagName("b");\r\n
for(i=0;i<bs.length;i++) {\r\n
if(prz = bs[i].innerHTML.match(/(\d+\.\d{2})/)) { totalCost = prz[1];}\r\n
}\r\n
for(var i=0;i<bs2.length;i++) {\r\n
if(bs2[i].innerHTML.indexOf("Order Number:")!=-1) {\r\n
orderId = bs2[i].nextSibling.nodeValue;\r\n
}\r\n
}\r\n
document.getElementById(\'st_code\').innerHTML=\'<img src="$SCRIPTDIRsale.php?TotalCost=\' + totalCost + \'&OrderID=\' + orderId + \'" alt="" width=1 height=1>\';\r\n
}\r\n
window.onload = getSaleInfo;\r\n
// -->\r\n
</script> \r\n
<div id="st_code"></div>',
'',
'english');

insert into wd_pa_integrationsteps
values('yahoos03', 'yahoos01', 1,
'After inserting the code below you should click <b>Order Settings -> Publish Order Settings</b> to make the changes live.',
'',
'',
'english');


insert into wd_pa_integration
values('zencar01',
'ZenCart', '',
'Integration with ZenCart is made by placing sale tracking script into the order confirmation page.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('zencar01', 'zencar01', 1,
'To integrate ZenCart you should edit the order confirmation template. Open the file
<b>/zencart/tpl_checkout_success_default.php</b>',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('zencar02', 'zencar01', 2,
'Find the line with following code which should already exist in the file.  <br>
<code>fields[\'orders_id\']; ?></code>',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('zencar03', 'zencar01', 3,
'Cut/Paste the following code into the file, under the line found above:',
'<?php\r\n
$dbreq = $db->Execute("select * from " . TABLE_ORDERS_TOTAL . " where orders_id = \'".(int)$orders->fields[\'orders_id\']."\' AND class = \'ot_subtotal\'");\r\n
$totalCost = (number_format($dbreq->fields[\'value\'],2));\r\n
$orderId = $dbreq->fields[\'orders_id\'];\r\n
print \'<script id=\"pap_x2s6df8d\" src=\"$SCRIPTDIRsale.js\" type=\"text/javascript\"></script>
<script type=\"text/javascript\">\r\n<!--\r\n\r\nvar TotalCost=\"\'.$totalCost.\'\";\r\nvar OrderID=\"\'.$orderId.\'\";\r\nvar ProductID=\"\";\r\npapSale();\r\n-->\r\n</script>\';\r\n
?>',
'',
'english');



insert into wd_pa_integration
values('vtmart01',
'Virtue Mart', '',
'Integration with Virtue Mart is made by placing sale tracking script into the confirmation page.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('vtmart01', 'vtmart01', 1,
'Find and open file <b>checkout.thankyou.php</b>',
'','', 'english');


insert into wd_pa_integrationsteps
values('vtmart02', 'vtmart01', 2,
'Replace last ?> with following code',
'$q = "SELECT * FROM #__{vm}_orders WHERE order_id=\'$order_id\'";\r\n
$db->query( $q );\r\n
$pap_order_total = $db->f(\'order_subtotal\' );\r\n
\r\n
$q = "SELECT * FROM #__{vm}_order_item WHERE order_id=\'$order_id\'";\r\n
$db->query( $q );\r\n
$pap_product_id = $db->f(\'product_id\');\r\n
?>\r\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost="<?php echo  $pap_order_total ?>";\r\n
var OrderID="<?php echo  $order_id ?>";\r\n
var ProductID="<?php echo  $pap_product_id ?>";\r\n
papSale();\r\n
</script>',
'',
'english');


insert into wd_pa_integrationsteps
values('vtmart03', 'vtmart01', 3,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');


insert into wd_pa_integration
values('cartm01',
'Cart Manager', '',
'Integration with Cart Manager can be made using the Approval URL supported by them.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('cartm01', 'cartm01', 1,
'Login to your CartManager admin center and click <b>Advanced Settings</b>.',
'','', 'english');

insert into wd_pa_integrationsteps
values('cartm02', 'cartm01', 2,
'Find the box labeled: <b>HTML For Bottom of Receipt</b>.',
'','', 'english');

insert into wd_pa_integrationsteps
values('cartm03', 'cartm01', 3,
'Place the following code into the box.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost=PRINTSUBTOTAL;\r\n
var OrderID=PRINTORDERNUMBER;\r\n
var ProductID="";\r\n
papSale();\r\n
</script>','', 'english');

insert into wd_pa_integrationsteps
values('cartm04', 'cartm01', 4,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');


insert into wd_pa_integration
values('ecomt01',
'eCommerce Templates', '',
'Integration with eCommerce Templates is made by placing sale tracking script into the confirmation page.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('ecomt01', 'ecomt01', 1,
'Find and open file <b>thanks.php</b>.',
'','', 'english');

insert into wd_pa_integrationsteps
values('ecomt02', 'ecomt01', 2,
'Find the following line which already exists in the file: <b>&lt;?php include "vsadmin/inc/incthanks.php" ?&gt;</b>',
'','', 'english');

insert into wd_pa_integrationsteps
values('ecomt03', 'ecomt01', 3,
'Put following code right after this line.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost="<?php echo  $ordGrandTotal ?>";\r\n
var OrderID="<?php echo  $ordID ?>";\r\n
var ProductID="";\r\n
papSale();\r\n
</script>','', 'english');

insert into wd_pa_integrationsteps
values('ecomt04', 'ecomt01', 4,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');



insert into wd_pa_integration
values('mamchp01',
'Mambo-ChargePlus', '',
'Integration with Mambo-ChargePlus is made by placing sale tracking script into the confirmation page.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('mamchp01', 'mamchp01', 1,
'Find and open file <b>/components/com_mambocharge_plus/mambocharge_plus_thankyou.php</b>.',
'','', 'english');

insert into wd_pa_integrationsteps
values('mamchp02', 'mamchp01', 2,
'Put the following code into the very bottom of this file.',
'<?php\r\n
$aff_subtotal = $_POST[\'amount3\'];\r\n
$aff_orderid = $_POST[\'invoice\'];\r\n
?>\r\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost="<?php echo  $aff_subtotal ?>";\r\n
var OrderID="<?php echo  $aff_orderid ?>";\r\n
var ProductID="";\r\n
papSale();\r\n
</script>','', 'english');

insert into wd_pa_integrationsteps
values('mamchp04', 'mamchp01', 3,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');


insert into wd_pa_integration
values('swreg01',
'SWREG', '',
'Integration with SWREG is very simple - you only need to place sale tracking script into the template of order confirmation page.<br>
If you use Advanced ordering method, then you probably don\'t need to follow the steps below. Use the General Solution tracking code and put it to your own custom order confirmation page.
<br/>If you use standard ordering, follow the steps below.',
'',
0, 1);


insert into wd_pa_integrationsteps
values('swreg01', 'swreg01', 1,
'Log in to SWREG admin panel and click to <b>edit your look and feel templates</b><br/>If your templates are disabled, you should enable them by clicking on the top link <b>enable templates</b>.',
'',
'',
'english');


insert into wd_pa_integrationsteps
values('swreg02', 'swreg01', 2,
'Open <b>Credit Card Confirmation Template</b> and edit it\'s code. If you don\'t have this template customized yet, you should download the system template and make the changes there.
<br/>Put the following code anywhere inside the &lt;body&gt; &lt;/body&gt; tags of the template.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>
<script type="text/javascript"><!--\r\n
\r\n
var TotalCost="###BASECURRENCYTOTAL###";\r\n
var OrderID="###ORDERNO###";\r\n
var ProductID="";\r\n
papSale();\r\n
--></script>',
'If you want to use secure images, only replace http:// with https:// in script src.<br/>When you added the code to template file, upload it back to server, then Activate it and make it Default. This will tell system to use your customized template with tracking code when displaying order confirmation page.',
'english');

insert into wd_pa_integrationsteps
values('swreg03', 'swreg01', 3,
'This way you added tracking code to <b>Credit Card Confirmation Template</b>. You should do the same for other ordering methods, like <b>PayPal Template</b>, <b>Wire Transfer Ordering Template</b> and <b>Check/Cheque Ordering Template</b>',
'',
'',
'english');

insert into wd_pa_integration
values('xcart01',
'X-Cart', '',
'Integration with X-Cart is made by placing sale tracking script into the order confirmation page.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('xcart01', 'xcart01', 1,
'Find and open file <b>/xcart/skin1/customer/main/order_message.tpl</b>.<br/>
If you use other skin, your skin directory could be different.',
'','', 'english');

insert into wd_pa_integrationsteps
values('xcart02', 'xcart01', 2,
'Put the following code right after the &lt;BR&gt;&lt;BR&gt;&lt;BR&gt;&lt;BR&gt; line.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost="{$orders[oi].order.subtotal}";\r\n
var OrderID="{$orders[oi].order.orderid}";\r\n
var ProductID="";\r\n
papSale();\r\n
</script>','', 'english');

insert into wd_pa_integrationsteps
values('xcart03', 'xcart01', 3,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');

insert into wd_pa_integration
values('1shop01',
'1ShoppingCart', '',
'Integration with 1ShoppingCart is made by placing sale tracking script into the than you page.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('1shop01', '1shop01', 1,
'1ShoppingCart allows you to have custom template of <b>thank you</b> page. They even provide sample custom thank you page.<br>
Find and open this custom thank you template file.',
'','', 'english');

insert into wd_pa_integrationsteps
values('1shop02', '1shop01', 2,
'Put the following code right after last presence of ?&gt mark.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
\r\n
var TotalCost="<?php echo  $_POST[\'Total\']; ?>";\r\n
var OrderID="<?php echo  $_POST[\'orderID\']; ?>";\r\n
var ProductID="";\r\n
papSale();\r\n
</script>','', 'english');

insert into wd_pa_integrationsteps
values('1shop03', '1shop01', 3,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');


insert into wd_pa_integration
values('xtcom01',
'XtCommerce', '',
'Integration with XtCommerce is made by changing checkout_success.php file.',
'',
0, 1);

insert into wd_pa_integrationsteps
values('xtcom01', 'xtcom01', 1,
'Find and open checkout_success.php file.',
'','', 'english');

insert into wd_pa_integrationsteps
values('xtcom02', 'xtcom01', 2,
'Put the following code right before line "if (DOWNLOAD_ENABLED == \'true\')".',
'//--------------------------------------------------------------------------\r\n
// Post Affiliate Pro code\r\n
// The code below will get the order_id and total value of recent order\r\n
// from the database and displays invisible image that registers the sale\r\n
// for affiliate (if some affiliate referred this visitor)\r\n
//--------------------------------------------------------------------------\r\n
  $sql = "select orders_id from ".TABLE_ORDERS." where customers_id=\'".$_SESSION[\'customer_id\']."\' order by orders_id desc limit 1";\r\n
  $pap_orders_query = xtc_db_query($sql);\r\n
  $pap_orders = xtc_db_fetch_array($pap_orders_query);\r\n
  $pap_order_id = $pap_orders[\'orders_id\'];\r\n
\r\n
  // get total amount of order\r\n
  $sql = "select value from ".TABLE_ORDERS_TOTAL.\r\n
         " where orders_id=\'".(int)$pap_order_id."\'";\r\n
  $pap_orders_total_query = xtc_db_query($sql);\r\n
  $pap_orders_total = xtc_db_fetch_array($pap_orders_total_query);\r\n
  $pap_total_value = $pap_orders_total[\'value\'];\r\n
\r\n
  // draw sale tracking code to register sale\r\n
  if($pap_total_value != "" && $pap_order_id != "")\r\n
  {\r\n
     $smarty->assign(\'pap_sale_tracking\',\'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
        <script type="text/javascript"><!--\r\n
        var TotalCost="\'.$pap_total_value.\'";\r\n
        var OrderID="\'.$pap_order_id.\'";\r\n
        papSale();\r\n
        --></script>\');\r\n
  }\r\n
//--------------------------------------------------------------------------\r\n
// END of Post Affiliate Pro code\r\n
//------------------------------------------------------------------','', 'english');

insert into wd_pa_integrationsteps
values('xtcom03', 'xtcom01', 3,
'Find and open /templates/xtc4/module/checkout_success.html file.',
'',
'',
'english');

insert into wd_pa_integrationsteps
values('xtcom04', 'xtcom01', 4,
'Put the following code right before line " {if $downloads_content neq ''}".',
'<!-- START of Post Affiliate Pro code -->\r\n
{$pap_sale_tracking}\r\n
<!-- END of Post Affiliate Pro code -->','', 'english');


insert into wd_pa_integrationsteps
values('xtcom05', 'xtcom05', 3,
'It is now integrated. Every time customer enters the order confirmation page the tracking code is called and it will register a sale for referring affiliate.',
'',
'',
'english');




insert into wd_pa_integration
values('malse01',
'Mal\'s e-commerce', '',
'Please follow these steps to integrate with Mal\'s e-commerce:',
'',
0, 1);

insert into wd_pa_integrationsteps
values('malse01', 'malse01', 1,
'Log in to your Mal\'s administration and go to Cart set-up > OTHER MESSAGES and GENERAL SETTINGS section.',
'','', 'english');

insert into wd_pa_integrationsteps
values('malse02', 'malse01', 1,
'There is EXIT MESSAGES section at the bottom of this page, which contains Secure and Unsecure payments fields.',
'','', 'english');

insert into wd_pa_integrationsteps
values('malse03', 'malse01', 2,
'Add following code to both of these fields:',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
<!--\r\n
var TotalCost="{sb}";\r\n
var OrderID="{id}";\r\n
papSale();\r\n
-->\r\n
</script>\r\n','', 'english');

insert into wd_pa_integrationsteps
values('malse04', 'malse01', 3,
'It is now integrated.',
'',
'',
'english');


    

insert into wd_pa_integration
values('dlgua01',
'DL guard', '',
'Please follow these steps to integrate with DL guard:',
'',
0, 1);

insert into wd_pa_integrationsteps
values('dlgua01', 'dlgua01', 2,
'In DLGuard, the following code can be added into the "Extra Text/HTML Code" box on the Edit Product screen of their particular product.',
'<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript">\r\n
<!--\r\n
var TotalCost="%%productprice%%";\r\n
var OrderID="%%customerreceipt%%";\r\n
var ProductID="%%productnumber%%";\r\n
papSale();\r\n
-->\r\n
</script>\r\n','', 'english');

insert into wd_pa_integrationsteps
values('dlgua04', 'dlgua01', 3,
'It is now integrated.',
'',
'',
'english');




insert into wd_pa_integration
values('wpeco01',
'WP e-Commerce', '',
'The WP e-Commerce shopping cart is plugin for WordPress is an elegant easy to use fully featured shopping cart application suitable for selling your products, services, and or fees online.<br><br>For integration follow these easy steps:',
'',
0, 1);

insert into wd_pa_integrationsteps
values('wpeco01', 'wpeco01', 1,
'Open <b>transaction_result_functions.php</b> file in your favorite editor. This file is located in <b>wp-content/plugins/wp-shopping-cart</b> directory.',
'','', 'english');

insert into wd_pa_integrationsteps
values('wpeco02', 'wpeco01', 2,
'There are following lines at the end of this file:',
'  }\r\n
?>',
'',
'english');

insert into wd_pa_integrationsteps
values('wpeco03', 'wpeco01', 3,
'Add following code before these lines:',
'?>\r\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript"><!--\r\n
var TotalCost="<?php echo  $total?>";\r\n
var OrderID="<?php echo  $purchase_log[\'id\'];?>";\r\n
var ProductID="";\r\n
papSale();\r\n
--></script>\r\n
<?php',
'',
'english');

insert into wd_pa_integrationsteps
values('wpeco04', 'wpeco01', 4,
'After the file has been saved, you will be able to track product price and order ID. If you want to track product price with shipping price, replace <b>$total</b> variable with <b>$total+$total_shipping</b>',
'', '', 'english');



insert into wd_pa_integration
values('actin01',
'Actinic', '',
'Actinic is the most comprehensive low-cost ecommerce package available today. It includes everything a small  business needs to design, build and manage its own secure web store.\r\n\r\n
For integration follow these easy steps:',
'',
0, 1);

insert into wd_pa_integrationsteps
values('actin01', 'actin01', 1,
'Open order04.html file',
'','', 'english');

insert into wd_pa_integrationsteps
values('actin02', 'actin01', 2,
'Add following code anywhere to this file:',
'?>\r\n
<script id="pap_x2s6df8d" src="$SCRIPTDIRsale.js" type="text/javascript"></script>\r\n
<script type="text/javascript"><!--\r\n
var TotalCost="NETQUOTEVAR:FORMATTEDORDERTOTALCGI";\r\n
var OrderID="NETQUOTEVAR:THEORDERNUMBER";\r\n
var ProductID="";\r\n
papSale();\r\n
--></script>\r\n
<?php',
'',
'english');

insert into wd_pa_integrationsteps
values('actin03', 'actin01', 3,
'After the file has been saved, you will be able to track all sales',
'', '', 'english');

update wd_g_settings set value='1000016' where code='Aff_integration_version';
