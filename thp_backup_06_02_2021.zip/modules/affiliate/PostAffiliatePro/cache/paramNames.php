<?php
define('NAME_A_AID', 'aid');
define('NAME_A_BID', 'bid');
define('NAME_DATA1', 'data1');
define('NAME_DATA2', 'data2');
define('NAME_DATA3', 'data3');
define('NAME_DESTURL', 'url');
?>