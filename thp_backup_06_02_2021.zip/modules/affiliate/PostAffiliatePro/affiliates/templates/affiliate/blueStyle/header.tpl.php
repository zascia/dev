<style>
/* TOP MENU - can be changed here  ---------------------------------------------- HYPERTEXT LINKS */

TABLE.pa_menu 
{
    BORDER-TOP: #CDCDCD 1px solid; 
    BORDER-LEFT: #A0A0A0 1px solid; 
    BORDER-RIGHT: #A0A0A0 1px solid; 
    BORDER-BOTTOM: #A0A0A0 1px solid; 
    
    width: 10px; 
    BACKGROUND-COLOR: #FFFFFF;
    CURSOR: default;  
    font-size: 10px;     
}
TD {
    font-size: 10px;     
}
TD.pa_menuPasive 
{
    text-decoration: none;
    font-size: 10px;
}
.pa_menuActive 
{
    text-decoration: underline;
    font-size: 10px;
}
.pa_menuHeader
{
    background-color: #EEEEEE;
    font-weight: bold;
    color: #555555;
    CURSOR: default;
    font-size: 10px;
}

</style>
<?php echo  $this->menu_left ?>

