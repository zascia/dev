<table width="100%" border="0" cellspacing="0" cellpadding="2">
<tr>
    <td class="footer" align="left" valign="middle" width="33%">
      <div class="poweredby"><a target=_blank href="http://www.qualityunit.com/postaffiliatepro/">Affiliate software</a> by QualityUnit</div>
    </td>
    <td class="footer" align="center" valign="middle" width="33%">
        <?php echo L_G_VERSION?> <?php echo POSTGLOBAL_VERSION?>
    </td>
    <td class="footer" align="right" valign="middle" width="33%">
        <?php echo L_G_GENERATEDIN.' '.$this->a_timegenerated.' s., '.L_G_DBREQUESTS.': '.$GLOBALS['dbrequests']?>
        &nbsp;&nbsp;    
    </td>    
</tr>
</table>
