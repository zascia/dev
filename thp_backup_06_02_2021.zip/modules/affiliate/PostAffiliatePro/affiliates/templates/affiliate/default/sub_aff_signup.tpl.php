<table class=tableresult width=600 border=0 cellspacing=0 cellpadding=1>
<tr>
  <td class=listresult2 align=left><b><?php echo L_G_SUBAFFSIGNUP?></b></td>
</tr>
<tr>
  <td class=listresult2 align=left>
  <textarea cols=80 rows=2><?php echo $this->a_signuplink?></textarea></td>
</tr>
</table>
