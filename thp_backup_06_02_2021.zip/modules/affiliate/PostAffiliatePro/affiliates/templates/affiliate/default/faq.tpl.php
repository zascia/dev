    <?php echo $this->a_panel_settings['customdescription'] ?>
    <input type=hidden name=md value='Affiliate_Affiliates_Views_Faq'>
<br>
