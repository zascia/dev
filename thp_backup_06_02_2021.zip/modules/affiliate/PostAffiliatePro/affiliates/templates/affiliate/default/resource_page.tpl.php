<?php echo $this->a_content?>
