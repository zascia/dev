<?php  if($GLOBALS['Auth']->isLogged()) { ?>
  
<table border=0 width=100% cellspacing=0 cellpadding=0>
<tr>
  <td align=left>
  </td>
  <td align=right>
  <a class="leftLink" href=logout.php><?php echo L_G_LOGOUT?></a>
  &nbsp;&nbsp;
  </td>
  </tr>
</table>

<?php } ?>
