<?php
/**
*
*   @author Andrej Harsani
*   @copyright Copyright � 2004
*   @package wrapper
*   @since Version 0.1a
*   $Id: All.class.php,v 1.1.1.1 2005/04/22 10:13:37 jsujan Exp $
*/

class QUnit_Test_All {
    function getTests() {
        return array();
    }
}

?>