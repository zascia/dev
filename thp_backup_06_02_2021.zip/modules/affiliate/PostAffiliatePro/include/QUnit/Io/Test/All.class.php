<?php
/**
*
*   @author Andrej Harsani
*   @copyright Copyright (c) 2004 Quality Unit s.r.o.
*   @package QUnit
*   @since Version 0.1a
*   $Id: All.class.php,v 1.1.1.1 2005/04/22 10:13:34 jsujan Exp $
*/

class QUnit_Io_Test_All {
    function getTests() {
        return array('QUnit_Io_Test_Directory');
    }
}

?>