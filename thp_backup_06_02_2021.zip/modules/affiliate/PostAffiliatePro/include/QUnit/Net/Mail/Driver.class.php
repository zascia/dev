<?php
/**
*
*   @author Juraj Sujan
*   @copyright Copyright (c) 2005
*   @package QUnit
*   @since Version 0.1a
*   $Id: Mail.class.php,v 1.10 2005/07/21 20:06:58 jsujan Exp $
*/

QUnit_Global::includeClass('QUnit_Object');

class QUnit_Net_Mail_Driver extends QUnit_Object {
      
    function QUnit_Net_Mail_Driver($params) {                
    }
    
    function send() {
        
    }

}
?>