<?php
// French
//Category Add
//------------
$Cat_add_head= "CATEGORIE AJOUTER";
$Cat_add= "AJOUTER CATEGORIE";
$cat_success = "CATEGORIE CREE AVEC SUCCES";
$s_go_back = "<p>Please <a href=\"javascript:history.back()\">go back</a> and enter a category.</p>\n";
$cat_name = "CATEGORIE NOM";

//Category delete
//--------------
$cat_del_head = "CATEGORIE EFFACER";
$cat_del = "EFFACER CATEGORIE";
$cat_del_sucess = "CATEGORIE ET FAQ ATTACHEES EFFACER AVEC SUCCES";
$cat_del_ques = "ES CE QUE VOUS ETES SURE D�EFFACER";
$cat_del_ques2= "CETTE FONCTION VA EFFACER  TOUS LES FAQ SOUS CETTE CATEGORIE.";

//Category Edit
//--------------
$cat_edit_head = "EDITION CATEGORIE";
$cat_edit = "CATEGORIE EDITION";
$cat_edit_success="CATEGORIE A JOURS";

//Faq Add
//-------
$faq_add_head = "CATEGORIE EDITION";
$faq_add = "FAQ AJOUTER";
$faq_add_ques="<p>Please <a href=\"javascript:history.back()\">go back</a> and verify that both a question and answer have been entered.</p>\n";
$faq_add_success = "FAQ AJOUTER AVEC SUCCES";

//Faq delete
//----------
$faq_del_head = "CATEGORIE EDITION";
$faq_del= "FAQ EFFECER";
$faq_del_ques = "ES CE QUE VOUS ETES SURE D�EFFACER CE FAQ?";
$faq_del_sucess= "FAQ EFFACER AVEC SUCCES";

//Faq edit
//--------
$faq_edit_head = "Add Category";
$faq_edit = "FAQ Edit";
$faq_edit_sucess = "FAQ Successfully Updated";

//User edit
//----------
$user_edit_head = "Edit User";
$user_edit_success = "User Successfully Updated";


//Common
//--------
$set_uid="Alter Userid/Password";
$db_err="CONNECTION INCORECT A LA DATABASE!";
$s_close = "FERMER";
$s_add = "AJOUTER";
$s_cancel = "ANNULER";
$s_update= "update";
$s_delete= "EFFECER";
$s_edit = "EDITION";
$s_yes = "OUI";
$s_no = "NON";
$s_action = "Action";
$s_faq_cats = " FAQ CATEGORIES";
$s_print_faq = "IMPRIMER FAQ";
$s_faq_add = "AJOUTER NOUVEAU FAQ A";
$faq_admin_head = "FAQ Administration";
$faq_admin = "FAQ Admin";
$login_sucess ="CONNECTION ETABLIE AVEC SUCCES";
$faq_instruct = "appyuez sur la question pour avoir la reponse , appyuez sur la question pour la cacher.";
$faq_title1="Question";
$faq_title2="REPONSE";
$main_page_instruc = "SELECTIONNER UNE CATEGORIE POUR AFFICHER LES QUESTIONS ASSOCIEES.";
?>