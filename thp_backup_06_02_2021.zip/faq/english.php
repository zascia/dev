<?php
//English
//Category Add
//------------
$Cat_add_head= "Category Add";
$Cat_add= "Add Category";
$cat_success = "Category Successfully Created";
$s_go_back = "<p>Please <a href=\"javascript:history.back()\">go back</a> and enter a category.</p>\n";
$cat_dis_name = "Category Name";

//Category delete
//--------------
$cat_del_head = "Delete Category";
$cat_del = "Category Delete";
$cat_del_sucess = "Category and Corresponding FAQs Successfully Deleted";
$cat_del_ques = "Are you sure you wish to delete";
$cat_del_ques2= "This action will delete all FAQs that belong to this category.";

//Category Edit
//--------------
$cat_edit_head = "Edit Category";
$cat_edit = "Category Edit";
$cat_edit_success = "Category Successfully Updated";

//Faq Add
//-------
$faq_add_head = "Edit Category";
$faq_add = "FAQ Add";
$faq_add_ques="<p>Please <a href=\"javascript:history.back()\">go back</a> and verify that both a question and answer have been entered.</p>\n";
$faq_add_success = "FAQ Successfully Added";

//Faq delete
//----------
$faq_del_head = "Edit Category";
$faq_del= "FAQ Delete";
$faq_del_ques = "Are you sure you wish to delete this FAQ?";
$faq_del_sucess= "FAQ Successfully Deleted";

//Faq edit
//--------
$faq_edit_head = "Add Category";
$faq_edit = "FAQ Edit";
$faq_edit_sucess = "FAQ Successfully Updated";

//User edit
//----------
$user_edit_head = "Edit User";
$user_edit_success = "User Successfully Updated";

//Common
//--------
$set_uid="Alter Userid/Password";
$db_err="Incorrect database connection information provided!";
$s_close = "luk";
$s_add = "add";
$s_cancel = "cancel";
$s_update= "update";
$s_delete= "Delete";
$s_edit = "Edit";
$s_yes = "yes";
$s_no = "no";
$s_action = "Action";
$s_faq_cats = "FAQ Categories";
$s_print_faq = "Print FAQs";
$s_faq_add = "Add New FAQ to";
$faq_admin_head = "FAQ Administration";
$faq_admin = "FAQ Admin";
$login_sucess ="Login Successful";
$faq_instruct = "Klik p� sp�rgsm�let for at f� vist svaret, klik p� sp�rgsm�let igen for at skjule det.";
$faq_title1="Question";
$faq_title2="Answer";
$main_page_instruc = "Select a category to view the associated Frequently Asked Questions.";
?>