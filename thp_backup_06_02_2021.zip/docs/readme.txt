
http://epay.bambora.com/en/payment-window-integration

this is the file that has the current setup for ir. The link for the paymentwindow we currently use is in the bottom

I tried only replacing that this this one:
https://ssl.ditonlinebetalingssystem.dk/integration/ewindow/Default.aspx

which ended with error

https://monosnap.com/file/2Uf8x2bKu1lWhtQ7IiQH7BKI10rYhr

https://ssl.ditonlinebetalingssystem.dk/integration/ewindow/Default.aspx


server: ftp.2t-webdesign.net
user: alexander@nyah-beauty.com
pass: password!


in theis folder you have all the files, and the ones in question is here: /public_html/nyah-beauty/modules/gateway/Betalingskort


or /modules/gateway/Betalingskort

You can test by making an order on any product and then log in with flivthp@gmail.com and pass shaft2000

