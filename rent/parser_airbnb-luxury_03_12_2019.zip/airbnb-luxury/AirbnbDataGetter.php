<?php
require_once 'XmlGenerator.php';

class AirbnbDataGetter{

  public $parser_status = true;

  public $key = 'd306zoyjsyarp7ifhu67rjxn52tv0t20';
  public $headers = [
    'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:9.0.1) Gecko/20100101 Firefox/9.0.1',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language: ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
    'Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7',
    'Connection: keep-alive',
    'Cache-Control: no-cache',
  ];

  public $items_per_request = 50;
  public $received_items = 0;

  // Proxy properties
  public $proxy = '';
  public $port = '';
  public $proxy_data = 'https://www.proxy-list.download/api/v0/get?l=en&t=socks4';
  public $proxy_index = 0;

  // Services and descriptions end-points
  public $services_end_point = "https://www.airbnb.com/api/v2/luxury_staff_services/";
  public $descriptions_end_point = "https://www.airbnb.com/api/v2/luxury_pdps/";

  // Destination properties
  public $destinations = [
    ['place_id' => 'ChIJ2WrMN9MDDUsRpY9Doiq3aJk', 'query' => 'Canada'],
    ['place_id' => 'ChIJQbA4_Cu8QW4RbuvrxISzaks', 'query' => 'Oceania'],
    ['place_id' => 'ChIJV-jLJIrxYzYRWfSg0_xrQak', 'query' => 'Asia'],
    ['place_id' => 'ChIJCzYy5IS16lQRQrfeQ5K5Oxw', 'query' => 'United~States'],
    ['place_id' => 'ChIJ1fWMlApsoBARs_CQnslwghA', 'query' => 'Africa'],
    ['place_id' => 'ChIJt_9CgWXEfhURLKdeISCDWwo', 'query' => 'Middle~East'],
    ['place_id' => 'ChIJNfUKtP-e-ZARnLalAr89Z9I', 'query' => 'Latin~America'],
    ['place_id' => 'ChIJhdqtz4aI7UYRefD8s-aZ73I', 'query' => 'Europe'],
    ['place_id' => 'ChIJtzig1QnjuY4R3NvFyjLPfsY', 'query' => 'Caribbean'],
  ];
  public $current_destination = 0;
  public $destination_switcher = false;

  public function __construct() {
    $this->switch_proxy_server();
  }

  public function get_listings_data() {

    if (false === $this->parser_status) {
      return true;
    }

    // Switch destination using flag (using this method for right naming of files)
    if ($this->destination_switcher === true) {
      $this->current_destination = $this->current_destination + 1;
      $this->received_items = 0;
      $this->destination_switcher = false;
    }

    $listings = array();

    $url_parameters = $this->get_listings_request_params();

    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, "https://www.airbnb.com/api/v2/explore_tabs?".$url_parameters);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_PROXY, "$this->proxy:$this->port");
    curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($request, CURLOPT_HTTPHEADER, $this->headers);
    curl_setopt($request, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($request, CURLOPT_MAXREDIRS, 10 );
    curl_setopt($request, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    curl_setopt($request, CURLOPT_HEADER, false);
    curl_setopt($request, CURLOPT_TIMEOUT, 60);
    $output = curl_exec($request);
    $output = json_decode($output, true);
    curl_close($request);

    if (isset($output['explore_tabs'])) {
      $sections = $output['explore_tabs'][0]['sections'];
      $pagination_metadata = $output['explore_tabs'][0]['pagination_metadata'];

      $has_next_page = $pagination_metadata['has_next_page'];

      if (isset($pagination_metadata['items_offset'])) {
        $this->received_items = $pagination_metadata['items_offset'];
      }

      if (isset($sections)) {
        foreach ($sections as $section) {
          if (isset($section['listings'])) {
            $listings[] = $section['listings'];
          }
        }
      }
    }

    if (is_null($output)) {
      return false;
    }

    if (isset($has_next_page) && ($has_next_page === false) ) {
      $this->received_items = $this->items_per_request + $this->received_items;

      // Switching destination till last destination using destination_switcher flag
      if ($this->current_destination < (count($this->destinations) - 1)) {
        $this->destination_switcher = true;
        return $listings;
      }

      // New statuses of work for parser
      $this->parser_status = false;
    }

    if (!empty($listings)) return $listings;

    return false;
  }

  public function get_listings_request_params(){
    $place_id = $this->destinations[$this->current_destination]['place_id'];
    $query    = $this->destinations[$this->current_destination]['query'];

    $url_parameters = 'currency=USD&has_zero_guest_treatment=true&';
    $url_parameters .= 'is_guided_search=true&is_new_cards_experiment=true&';
    $url_parameters .= 'is_standard_search=true&tab_id=luxury&';
    $url_parameters .= "items_offset=$this->received_items&items_per_grid=$this->items_per_request&";
    $url_parameters .= "key=$this->key&locale=en&";
    $url_parameters .= "place_id=$place_id&query=$query&";
    $url_parameters .= 'query_understanding_enabled=true';

    return $url_parameters;
  }

  public function get_listings_descriptions($id){
    $params = "key=$this->key&_format=for_pdp_with_pricing";
    $listings_info = [];

    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, $this->descriptions_end_point . $id . '?' . $params);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_HEADER, false);
    $output = json_decode(curl_exec($request), true);
    curl_close($request);

    if (isset($output['luxury_pdp'])) {
      $listings_info['description'] = json_decode($output['luxury_pdp']['lr_listing_description_string'])->data;
      $listings_info['features'] = json_decode($output['luxury_pdp']['lr_listing_features_string'])->data;

      // get house amenities
      $listings_info['amenities'] = $output['luxury_pdp']['amenities']['items'];

      // get house rules
      if (isset($output['luxury_pdp']['cancellation_rules']['structured_house_rules'])) {
        $listings_info['structured_house_rules'] = $output['luxury_pdp']['cancellation_rules']['structured_house_rules'];
      } else {
        $listings_info['structured_house_rules'] = array();
      }

      // get house cancellation
      if (isset($output['luxury_pdp']['cancellation_rules']['cancellation_info'])) {
        $listings_info['cancellation_info'] = $output['luxury_pdp']['cancellation_rules']['cancellation_info'];
      } else {
        $listings_info['cancellation_info'] = array();
      }
    }

    return $listings_info;
  }

  public function get_listings_services($id){
    $params = "_format=staff_and_service_v2&currency=USD&key=$this->key&locale=en";
    $listings_services = [];

    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, $this->services_end_point . $id . '?' . $params);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_HEADER, false);
    $output = json_decode(curl_exec($request), true);
    curl_close($request);

    if (isset($output['luxury_staff_service'])) {
      $listings_services = $output['luxury_staff_service'];
    }

    return $listings_services;
  }

  public function get_listings_external_info_via_proxy($id, $description = false, $services = false){
    if ($description) {
      $data = $this->get_listings_descriptions($id);
      if ($data === false) {
        while ($data === false) {
          $this->switch_proxy_server();
          $data = $this->get_listings_descriptions($id);
        }
      }
    } elseif ($services) {
      $data = $this->get_listings_services($id);
      if ($data === false) {
        while ($data === false) {
          $this->switch_proxy_server();
          $data = $this->get_listings_services($id);
        }
      }
    } else {
      return false;
    }
    return $data;
  }

  public function total_listing_comparing(){
    $basic_listings = $this->get_listings_data();
    if ($basic_listings === true) return true;

    if ($basic_listings === false) {
      while ($basic_listings === false) {
        $this->switch_proxy_server();
        $basic_listings = $this->get_listings_data();
      }
    }
    $total_listings = [];

    if ($basic_listings !== false) {
      foreach ($basic_listings as $listings) {
        if (is_array($listings)) {
          foreach ($listings as $listing) {
            $l_id = $listing['listing']['id'];

            // Checking listings ids for repeating
            $status = $this->check_and_update_added_ids($l_id);
            if (false === $status) {
              continue;
            }

            if (isset($listing['listing']['public_address'])) {
              $result = $this->get_state_from_public_address($listing['listing']['public_address']);
              if (isset($result['state'])) { $state = $result['state']; }
              if (isset($result['country'])) { $country = $result['country']; }
            }

            if (isset($listing['listing']['picture_urls'])) {
                $listing_pictures = $this->cut_picture_urls($listing['listing']['picture_urls']);
            }

            $total_listings[$l_id]['id'] = $l_id;
            $total_listings[$l_id]['additional_info']        = $this->get_listings_external_info_via_proxy($l_id, true);
            $total_listings[$l_id]['services']               = $this->get_listings_external_info_via_proxy($l_id, false, true);
            $total_listings[$l_id]['name']                   = isset($listing['listing']['name']) ? $listing['listing']['name'] : '';
            $total_listings[$l_id]['pictures']               = isset($listing_pictures) ? $listing_pictures : '';
            $total_listings[$l_id]['address']                = isset($listing['listing']['public_address']) ? $listing['listing']['public_address'] : '';
            $total_listings[$l_id]['city']                   = isset($listing['listing']['city']) ? $listing['listing']['city'] : '';
            $total_listings[$l_id]['state']                  = isset($state) ? $state : '';
            $total_listings[$l_id]['country']                = isset($country) ? $country : '';
            $total_listings[$l_id]['guest_label']            = isset($listing['listing']['guest_label']) ? $listing['listing']['guest_label'] : '';
            $total_listings[$l_id]['beds']                   = isset($listing['listing']['beds']) ? $listing['listing']['beds'] : '';
            $total_listings[$l_id]['bedrooms']               = isset($listing['listing']['bedrooms']) ? $listing['listing']['bedrooms'] : '';
            $total_listings[$l_id]['bedroom_label']          = isset($listing['listing']['bedroom_label']) ? $listing['listing']['bedroom_label'] : '';
            $total_listings[$l_id]['bed_label']              = isset($listing['listing']['bed_label']) ? $listing['listing']['bed_label'] : '';
            $total_listings[$l_id]['bathrooms']              = isset($listing['listing']['bathrooms']) ? $listing['listing']['bathrooms'] : '';
            $total_listings[$l_id]['lat']                    = isset($listing['listing']['lat']) ? $listing['listing']['lat'] : '';
            $total_listings[$l_id]['lng']                    = isset($listing['listing']['lng']) ? $listing['listing']['lng'] : '';
            $total_listings[$l_id]['localized_neighborhood'] = isset($listing['listing']['localized_neighborhood']) ? $listing['listing']['localized_neighborhood'] : '';
            $total_listings[$l_id]['person_capacity']        = isset($listing['listing']['person_capacity']) ? $listing['listing']['person_capacity'] : '';
            $total_listings[$l_id]['space_type']             = isset($listing['listing']['space_type']) ? $listing['listing']['space_type'] : '';
            $total_listings[$l_id]['min_nights']             = isset($listing['listing']['min_nights']) ? $listing['listing']['min_nights'] : '';
            $total_listings[$l_id]['max_nights']             = isset($listing['listing']['max_nights']) ? $listing['listing']['max_nights'] : '';
            $total_listings[$l_id]['can_instant_book']       = isset($listing['pricing_quote']['can_instant_book']) ? $listing['pricing_quote']['can_instant_book'] : '';
            $total_listings[$l_id]['monthly_price_factor']   = isset($listing['pricing_quote']['monthly_price_factor']) ? $listing['pricing_quote']['monthly_price_factor'] : '';
            $total_listings[$l_id]['price_string']           = isset($listing['pricing_quote']['price_string']) ? $listing['pricing_quote']['price_string'] : '';
            $total_listings[$l_id]['rate']                   = isset($listing['pricing_quote']['rate']) ? $listing['pricing_quote']['rate'] : '';
            $total_listings[$l_id]['rate_type']              = isset($listing['pricing_quote']['rate_type']) ? $listing['pricing_quote']['rate_type'] : '';
            $total_listings[$l_id]['rate_with_service_fee']  = isset($listing['pricing_quote']['rate_with_service_fee']) ? $listing['pricing_quote']['rate_with_service_fee'] : '';
            $total_listings[$l_id]['weekly_price_factor']    = isset($listing['pricing_quote']['weekly_price_factor']) ? $listing['pricing_quote']['weekly_price_factor'] : '';
            $total_listings[$l_id]['should_show_from_label'] = isset($listing['pricing_quote']['should_show_from_label']) ? $listing['pricing_quote']['should_show_from_label'] : '';
          }
        }
      }
      return $total_listings;
    }
    return false;
  }

  public function cut_picture_urls($urls){
      $new_pictures = [];
      foreach ($urls as $url) {
          $cut_url = explode('?aki_policy', $url);
          $new_url = $cut_url[0] . '?t=r:w5868-h3300-sfit,e:fjpg-c80';
          $new_pictures[] = $new_url;
      }
      return $new_pictures;
  }

  public function get_state_from_public_address($public_address){
    if (!empty($public_address)) {
      if (is_string($public_address)) {
        $address = explode(',', $public_address);
        if (count($address) > 2) {
          $result['state'] = trim($address[1]);
          $result['country'] = trim($address[2]);
          return $result;
        } elseif (count($address) == 2) {
          $result['country'] = trim($address[1]);
          return $result;
        }
      }
    }
    return false;
  }

  public function generate_xml_file(){
    $data = $this->total_listing_comparing();
    $destination_name = $this->destinations[$this->current_destination]['query'];

    if ($data === true) return true;
    if ($data !== false && is_array($data) && !empty($data) ) {
      new XmlGenerator($data, $this->received_items, $destination_name);
      $this->generate_xml_file();
    } else {
      $this->generate_xml_file();
    }
    return false;
  }

  public function switch_proxy_server(){
    $proxy_data = json_decode(file_get_contents($this->proxy_data), true);
    $proxies = $proxy_data[0]['LISTA'];
    if (count($proxy_data[0]['LISTA']) <= $this->proxy_index) {
      $this->proxy_index = 0;
    }
    if ($this->proxy !== $proxies[$this->proxy_index]['IP']) {
      $this->proxy = $proxies[$this->proxy_index]['IP'];
      $this->port = $proxies[$this->proxy_index]['PORT'];
    }else{
      ++$this->proxy_index;
      $this->proxy = $proxies[$this->proxy_index]['IP'];
      $this->port = $proxies[$this->proxy_index]['PORT'];
    }
    return true;
  }

  // Check id in list of already added listings' ids, if false, we not add this listing to data
  public function check_and_update_added_ids($id){
    if (file_exists(AX_DIR . '/imported_listings/list_of_added_listings.json')) {
      $lists = file_get_contents(AX_DIR . '/imported_listings/list_of_added_listings.json');
      if (is_string($lists)) {
        $current_data = json_decode($lists, true);

        if (array_key_exists($id, $current_data)) {
          return false;
        } else {
          $current_data[$id] = true;
          $newest_data = json_encode($current_data);
          file_put_contents(AX_DIR . '/imported_listings/list_of_added_listings.json', $newest_data);
          return true;
        }
      }
    }

    $data = array();
    $data[$id] = true;
    file_put_contents(AX_DIR . '/imported_listings/list_of_added_listings.json', json_encode($data));
    return true;
  }

}