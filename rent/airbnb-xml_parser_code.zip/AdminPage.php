<?php

class AdminPage{

  public function __construct(){
    add_action('admin_menu', [$this, 'ax_add_submenu_page']);
    add_action('wp_ajax_run_parsing', [$this, 'ax_run_parsing']);
    add_action('admin_enqueue_scripts', [$this, 'ax_enqueue_script']);
  }

  public function ax_add_submenu_page(){
    add_submenu_page(
      'tools.php',
      'Airbnb Xml Export',
      'AX Export Page',
      'manage_options',
      'ax-export',
      [$this, 'ax_submenu_template']
    );
  }

  public function ax_run_parsing(){
    $this->create_listing_folder();
    $parser = new AirbnbDataGetter();
    $parser->generate_xml_file();

    echo 'true';
    wp_die();
  }

  public function create_listing_folder(){
    if (file_exists(AX_DIR . '/imported_listings/')) {
      $dir = AX_DIR . '/imported_listings/';
      $this->rename_old_listing_folder($dir);
    }
    mkdir(AX_DIR . '/imported_listings/');
    return true;
  }

  public function rename_old_listing_folder($dir){
    if (is_dir($dir)) {
      rename($dir, AX_DIR . '/imported_listings_' . time());
      return true;
    }
    return false;
  }

  public function ax_enqueue_script(){
    $path_js = plugins_url('airbnb-xml') . '/js/script.js';
    $path_css = plugins_url('airbnb-xml') . '/css/style.css';
    wp_enqueue_script('ax-script', $path_js, ['jquery'], false, false);
    wp_enqueue_style('ax-style', $path_css);
  }

  public function ax_submenu_template(){
    echo '<div class="wrap">
            <buton id="GetDataAirbnb" class="button button-primary">Get Data from Airbnb</buton>
            <div id="loader"></div>
          </div>';
  }
}
new AdminPage();