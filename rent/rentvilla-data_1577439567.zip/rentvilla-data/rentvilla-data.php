<?php

/**
 *
 * @since             1.0
 * @package           RentVilla_data
 *
 * @wordpress-plugin
 * Plugin Name:       RentVilla data
 * Description:       This is a rentvilla data plugin.
 * Version:           1.0
 * Author:            Maksym Burkhan
 * License:           GPL-2.0+
 * License URI:       http://www.gnu.org/licenses/gpl-2.0.txt
 * Text Domain:       rentvilla-data
 */
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

/**
 * Currently plugin version.
 */
define('RentVilla_data_VERSION', '1.0');

require plugin_dir_path(__FILE__) . 'includes/rentvilla-data-hooks.php';

add_action('admin_menu', 'register_rentvilla_data_menu_page');

function register_rentvilla_data_menu_page() {
    add_menu_page('Reservation statistics', 'Reservation statistics', 'manage_options', 'rentvilla_data_statistics', 'rentvilla_data_statistics_page', 'dashicons-chart-area', 9999);
    add_submenu_page( 'rentvilla_data_statistics', 'Available / Booked', 'Available / Booked', 'manage_options', 'rentvilla_data_available_booked', 'rentvilla_data_available_booked_page' );
    add_submenu_page( 'rentvilla_data_statistics', 'Search or Replace text', 'Search or Replace text', 'manage_options', 'rentvilla_data_replace_text', 'rentvilla_data_replace_text_page' );
}

function rentvilla_data_statistics_page() {
    require plugin_dir_path(__FILE__) . 'templates/rentvilla_data_statistics.php';
}

function rentvilla_data_available_booked_page() {
    require plugin_dir_path(__FILE__) . 'templates/rentvilla_data_available_booked.php';
}

function rentvilla_data_replace_text_page() {
    require plugin_dir_path(__FILE__) . 'templates/rentvilla_data_replace_text.php';
}

add_action('admin_enqueue_scripts', '__page_css_js');

function __page_css_js() {
    wp_enqueue_style('rentvilla_data_style', plugins_url('css/style.css', __FILE__));
    wp_enqueue_script('rentvilla_data_script', plugins_url('js/script.js', __FILE__), array('jquery'), null, true);
}

if (!wp_next_scheduled('rentvilla_data_task_hook')) {
    wp_schedule_event(time(), 'hourly', 'rentvilla_data_task_hook');
}

add_action('rentvilla_data_task_hook', 'rentvilla_data_task_function');

function rentvilla_data_task_function() {
    require plugin_dir_path(__FILE__) . 'templates/rentvilla_data_statistics.php';
}