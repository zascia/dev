<h1><?php echo get_admin_page_title(); ?></h1>
<?php
$template_directory_uri = get_template_directory_uri();
?>
<link href="<?php echo $template_directory_uri; ?>/css/bootstrap.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $template_directory_uri; ?>/css/font-awesome-min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $template_directory_uri; ?>/css/main.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $template_directory_uri; ?>/css/styling-options.css" rel="stylesheet" type="text/css" />
<link href="<?php echo $template_directory_uri; ?>/css/jquery-ui.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css"/>
<link rel="stylesheet" href="https://cdn.datatables.net/select/1.2.0/css/select.dataTables.min.css"/>
<link rel="stylesheet" href="//cdn.datatables.net/buttons/1.2.4/css/buttons.dataTables.min.css"/>
<style>
    .dataTables_filter input[type=search] {
        border-bottom: 1px solid #000!important;
    }
    .th_select_hide select {
        display: none;
    }
</style>
<div class="container">
    <div class="row">
        <div class="col-sm-6 col-xs-12 text-center">
            <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&find_text'); ?>">Find text in content</a>
        </div>
        <div class="col-sm-6 col-xs-12 text-center">
            <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&replace_text'); ?>">Replace text in content</a>
        </div>
    </div>
</div>
<br><br><br>
<?php
if (isset($_GET['replace_text'])) {
    require_once(plugin_dir_path(__FILE__) . 'listings_replace_text_form.php');
}
if (isset($_GET['find_text'])) {
    if (isset($_POST['search_text'])) {
        $text = $_POST['search_text'];
        if (!empty($text)) {
            $listings = rentvilla_result_text($text);
            if ($listings) {
                $table_th = [
                    ['name' => 'Name', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Address', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Zip', 'hide_class' => ''],
                    ['name' => 'Min book days', 'hide_class' => ''],
                    ['name' => 'Max book days', 'hide_class' => ''],
                    ['name' => 'Bedrooms', 'hide_class' => ''],
                    ['name' => 'Guests', 'hide_class' => ''],
                    ['name' => 'Beds', 'hide_class' => ''],
                    ['name' => 'Baths', 'hide_class' => ''],
                    ['name' => 'Size', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Size unit', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Featured', 'hide_class' => ''],
                    ['name' => 'Instant booking', 'hide_class' => ''],
                    ['name' => 'Night price', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Weekends price', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Weekends days', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Price Week', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Price Monthly', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Allow additional guests', 'hide_class' => ''],
                    ['name' => 'Additional guests price', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Cleaning_fee', 'hide_class' => ''],
                    ['name' => 'Cleaning fee type', 'hide_class' => ''],
                    ['name' => 'City fee', 'hide_class' => ''],
                    ['name' => 'City fee type', 'hide_class' => ''],
                    ['name' => 'Security deposit', 'hide_class' => ''],
                    ['name' => 'Smoke', 'hide_class' => ''],
                    ['name' => 'Pets', 'hide_class' => ''],
                    ['name' => 'Party', 'hide_class' => ''],
                    ['name' => 'Children', 'hide_class' => ''],
                    ['name' => 'Total rating', 'hide_class' => ''],
                    ['name' => 'Video url', 'hide_class' => 'th_select_hide'],
                    ['name' => 'Last pending date', 'hide_class' => ''],
                    ['name' => 'Last reservation date', 'hide_class' => ''],
                    ['name' => 'Airbnb', 'hide_class' => ''],
                    ['name' => 'Actions', 'hide_class' => 'th_select_hide'],
                ];
                ?>
                <div class="container">
                    <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&find_text'); ?>">< Back</a><br><br><br>
                </div>
                <div class="table-block dashboard-listing-table dashboard-table">
                    <table class="table table-responsive table-striped datatable select dt-select">
                        <thead>
                            <tr>
                                <?php
                                foreach ($table_th as $h => $thead) {
                                    echo '<th>' . $thead['name'] . '</th>';
                                }
                                ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            $make_featured = homey_option('make_featured');
                            $dashboard = homey_get_template_link('template/dashboard.php');
                            foreach ($listings as $post) {
                                setup_postdata($post);
                                $post_id = $post->ID;
                                $edit_link = get_bloginfo('url') . '/add-listing/?edit_listing=' . $post_id;

                                $values = get_post_meta($post_id);
                                if (!empty($values['homey_featured'][0]) && $values['homey_featured'][0] == 1) {
                                    $homey_featured = 'yes';
                                } else {
                                    $homey_featured = 'no';
                                }
                                if (!empty($values['homey_video_url'][0])) {
                                    $homey_video_url = $values['homey_video_url'][0];
                                } else {
                                    $homey_video_url = 'no';
                                }
                                if (!empty($values['homey_night_price'][0])) {
                                    $homey_night_price = $values['homey_night_price'][0];
                                } else {
                                    $homey_night_price = 'no';
                                }
                                if (!empty($values['homey_additional_guests_price'][0])) {
                                    $homey_additional_guests_price = $values['homey_additional_guests_price'][0];
                                } else {
                                    $homey_additional_guests_price = 'no';
                                }
                                if (!empty($values['rentvilla_listing_parser'][0])) {
                                    $rentvilla_listing_parser = 'airbnb';
                                } else {
                                    $rentvilla_listing_parser = 'custom';
                                }
                                $pending_dates_array = get_post_meta($post_id, 'reservation_pending_dates', true);
                                if (!is_array($pending_dates_array) || empty($pending_dates_array)) {
                                    $reservation_pending_dates = '';
                                } else {
                                    $reservation_pending_dates_key = array_key_last($pending_dates_array);
                                    $reservation_pending_dates = date('Y/m/d', $reservation_pending_dates_key);
                                }
                                $booked_dates_array = get_post_meta($post_id, 'reservation_dates', true);
                                if (!is_array($booked_dates_array) || empty($booked_dates_array)) {
                                    $reservation_dates = '';
                                } else {
                                    $reservation_dates_key = array_key_last($booked_dates_array);
                                    $reservation_dates = date('Y/m/d', $reservation_dates_key);
                                }
                                $tbody_array = [];
                                $tbody_array[] = $post->post_title;
                                $tbody_array[] = $values['homey_listing_address'][0];
                                $tbody_array[] = $values['homey_zip'][0];
                                $tbody_array[] = $values['homey_min_book_days'][0];
                                $tbody_array[] = $values['homey_max_book_days'][0];
                                $tbody_array[] = $values['homey_listing_bedrooms'][0];
                                $tbody_array[] = $values['homey_guests'][0];
                                $tbody_array[] = $values['homey_beds'][0];
                                $tbody_array[] = $values['homey_baths'][0];
                                $tbody_array[] = $values['homey_listing_size'][0];
                                $tbody_array[] = $values['homey_listing_size_unit'][0];
                                $tbody_array[] = $homey_featured;
                                $tbody_array[] = $values['homey_instant_booking'][0];
                                $tbody_array[] = $homey_night_price;
                                $tbody_array[] = $values['homey_weekends_price'][0];
                                $tbody_array[] = $values['homey_weekends_days'][0];
                                $tbody_array[] = $values['homey_priceWeek'][0];
                                $tbody_array[] = $values['homey_priceMonthly'][0];
                                $tbody_array[] = $values['homey_allow_additional_guests'][0];
                                $tbody_array[] = $homey_additional_guests_price;
                                $tbody_array[] = $values['homey_cleaning_fee'][0];
                                $tbody_array[] = $values['homey_cleaning_fee_type'][0];
                                $tbody_array[] = $values['homey_city_fee'][0];
                                $tbody_array[] = $values['homey_city_fee_type'][0];
                                $tbody_array[] = $values['homey_security_deposit'][0];
                                $tbody_array[] = $values['homey_smoke'][0];
                                $tbody_array[] = $values['homey_pets'][0];
                                $tbody_array[] = $values['homey_party'][0];
                                $tbody_array[] = $values['homey_children'][0];
                                $tbody_array[] = $values['listing_total_rating'][0];
                                $tbody_array[] = $homey_video_url;
                                $tbody_array[] = $reservation_pending_dates;
                                $tbody_array[] = $reservation_dates;
                                $tbody_array[] = $rentvilla_listing_parser;
                                echo '<tr entry_id="' . $post_id . '">';
                                $ti = 0;
                                foreach ($table_th as $b => $tbody) {
                                    if ($tbody['name'] != 'Actions') {
                                        echo '<td data-label="' . $tbody['name'] . '">' . $tbody_array[$ti] . '</td>';
                                        $ti++;
                                    }
                                }
                                ?>
                            <td data-label="Actions">
                                <div class="custom-actions">
                                    <a class="btn-action" target="_blanck" href="<?php echo esc_url($edit_link); ?>" data-toggle="tooltip" data-placement="top" data-original-title="Edit"><i class="fa fa-pencil"></i></a>

                                    <a href="<?php the_permalink($post_id); ?>" target="_blank" class="btn-action" data-toggle="tooltip" data-placement="top" data-original-title="View"><i class="fa fa-arrow-right"></i></a>
                                </div>
                            </td>
                            <?php
                            echo '</tr>';
                        };
                        ?>

                        </tbody>
                        <tfoot>        
                            <tr>
                                <?php
                                foreach ($table_th as $f => $tfoot) {
                                    echo '<th class="' . $tfoot['hide_class'] . '">' . $tfoot['name'] . '</th>';
                                }
                                ?>
                            </tr>
                        </tfoot>
                    </table>
                </div>
                <script>
                    var copyButtonTrans = 'copy';
                    var csvButtonTrans = 'csv';
                    var excelButtonTrans = 'excel';
                    var pdfButtonTrans = 'pdf';
                    var printButtonTrans = 'Print';
                    var colvisButtonTrans = 'View';
                </script>
                <script src="<?php echo $template_directory_uri; ?>/js/bootstrap.min.js"></script>
                <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>
                <script src="//cdn.datatables.net/buttons/1.2.4/js/dataTables.buttons.min.js"></script>
                <script src="//cdn.datatables.net/buttons/1.2.4/js/buttons.flash.min.js"></script>
                <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
                <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
                <script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
                <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.html5.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.print.min.js"></script>
                <script src="https://cdn.datatables.net/buttons/1.2.4/js/buttons.colVis.min.js"></script>
                <script src="https://cdn.datatables.net/select/1.2.0/js/dataTables.select.min.js"></script>
                <script src="https://code.jquery.com/ui/1.11.3/jquery-ui.min.js"></script>
                <script>
                    (function ($) {
                        var $window = $(window),
                                $document = $(document);
                        $(document).ready(function () {
                            $.extend(true, $.fn.dataTable.defaults, {
                                "language": {
                                    "url": "//cdn.datatables.net/plug-ins/1.10.15/i18n/English.json"
                                }
                            });
                            window.dtDefaultOptions = {
                                retrieve: true,
                                processing: true,
                                dom: 'lBfrtip<"actions">',
                                columnDefs: [{
                                        targets: [3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31],
                                        visible: false
                                    }],
                                initComplete: function () {
                                    this.api().columns().every(function () {
                                        var column = this;
                                        var select = $('<select><option value=""></option></select>')
                                                .appendTo($(column.footer()).empty())
                                                .on('change', function () {
                                                    var val = $.fn.dataTable.util.escapeRegex($(this).val());
                                                    column.search(val ? '^' + val + '$' : '', true, false).draw();
                                                });
                                        column.data().unique().sort().each(function (d, j) {
                                            select.append('<option value="' + d + '">' + d + '</option>')
                                        });
                                    });
                                },
                                "iDisplayLength": 10,
                                "aaSorting": [],
                                buttons: [
                                    {
                                        extend: 'copy',
                                        text: copyButtonTrans,
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                    {
                                        extend: 'csv',
                                        text: csvButtonTrans,
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                    {
                                        extend: 'excel',
                                        text: excelButtonTrans,
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                    {
                                        extend: 'pdf',
                                        text: pdfButtonTrans,
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                    {
                                        extend: 'print',
                                        text: printButtonTrans,
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                    {
                                        extend: 'colvis',
                                        collectionLayout: 'fixed four-column',
                                        text: colvisButtonTrans,
                                        //                        postfixButtons: [ 'colvisRestore' ],
                                        exportOptions: {
                                            columns: ':visible'
                                        }
                                    },
                                ]
                            };
                            var table = $('.datatable').each(function () {
                                $(this).dataTable(window.dtDefaultOptions);
                            });
                        });
                    }(jQuery, document, window));
                </script>
            <?php } else {
                ?>
                <div class="container">
                    <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&find_text'); ?>">< Back</a>
                    <br><br><br>
                    <div class="alert alert-danger alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>Warning!</strong> No listings by this text: <?php echo $text; ?></div>
                </div>
                <?php
            }
        } else {
            ?>
            <div class="container">
                <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&find_text'); ?>">< Back</a>
                <br><br><br>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <strong>Warning!</strong> Search text is empty.</div>
            </div>
            <?php
        }
    } else {
        require_once(plugin_dir_path(__FILE__) . 'listings_find_text_form.php');
    }
}