<?php

$variable = getcwd();
$path = substr($variable, 0, strpos($variable, "wp-content"));
//echo $path;
require_once( $path . 'wp-load.php' );
//require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

$date_ids = $_POST['date_ids'];
$check_in_date = $_POST['check_in_date'];
$check_out_date = $_POST['check_out_date'];
if (!empty($date_ids)) {
    $ids = explode(',', $date_ids);
    if (!empty($check_in_date)) {
        if (!empty($check_out_date)) {
            $guests = 2;
            $userID = 3;
            $local = homey_get_localization();
            $title = $local['reservation_text'];
            foreach ($ids as $listing_id) {
                echo rentvilla_reservation($listing_id, $check_in_date, $check_out_date, $guests, $userID, $title, true);
            }
        } else {
            echo '<div class="alert alert-danger alert-dismissible">'
            . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
            . '<strong>Warning!</strong> Check out date is empty.</div>';
        }
    } else {
        echo '<div class="alert alert-danger alert-dismissible">'
        . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
        . '<strong>Warning!</strong> Check in date is empty.</div>';
    }
} else {
    echo '<div class="alert alert-danger alert-dismissible">'
    . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
    . '<strong>Warning!</strong> Listings data is empty.</div>';
}