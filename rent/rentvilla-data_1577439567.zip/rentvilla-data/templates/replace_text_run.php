<?php

$variable = getcwd();
$path = substr($variable, 0, strpos($variable, "wp-content"));
//echo $path;
require_once( $path . 'wp-load.php' );
//require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

$text_from = $_POST['text_from'];
$text_to = $_POST['text_to'];
if (!empty($text_from)) {
    if (!empty($text_to)) {
        $replace = rentvilla_replace_text($text_from, $text_to);
        if (false === $replace) {
            echo '<div class="alert alert-danger alert-dismissible">'
            . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
            . '<strong>Warning!</strong> There was an error.</div>';
        } else {
            if ($replace != 0) {
                echo '<div class="alert alert-success alert-dismissible">'
                . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
                . '<strong>Success!</strong> Update ' . $replace . ' listings.<br>Replace text: ' . $text_to . '</div>';
            } else {
                echo '<div class="alert alert-warning alert-dismissible">'
                . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
                . '<strong>Warning!</strong> Update ' . $replace . ' listings.<br>From text: ' . $text_from . '<br>NOT FIND!!!.</div>';
            }
        }
    } else {
        echo '<div class="alert alert-danger alert-dismissible">'
        . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
        . '<strong>Warning!</strong> Text to is empty.</div>';
    }
} else {
    echo '<div class="alert alert-danger alert-dismissible">'
    . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
    . '<strong>Warning!</strong> Text from is empty.</div>';
}