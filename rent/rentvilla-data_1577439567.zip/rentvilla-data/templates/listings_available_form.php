<form action="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked'); ?>" method="post" class="container">
    <legend class="text-center">Listings available</legend>
    <div class="form-group row">
        <label for="check_in_date" class="col-sm-2 col-xs-12 col-form-label">Date from</label>
        <div class="col-sm-4 col-xs-12">
            <input class="form-control" type="date" value="<?php echo $arrive; ?>" id="check_in_date" name="check_in_date">
        </div>
        <label for="check_out_date" class="col-sm-2 col-xs-12 col-form-label">Date to</label>
        <div class="col-sm-4 col-xs-12">
            <input class="form-control" type="date" value="<?php echo $depart; ?>" id="check_out_date" name="check_out_date">
        </div>
    </div>
    <div class="text-center">
        <button type="submit" class="btn btn-primary">Submit</button>
    </div>
</form>
<br>
<br>