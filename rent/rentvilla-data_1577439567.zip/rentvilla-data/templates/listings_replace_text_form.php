<div class="container">
    <form action="javascript:void(null);" method="POST" id="replace_text_run" class="form-horizontal">
        <legend class="text-center">Change text in listings</legend>
        <div class="form-group row">
            <label for="text_from" class="col-sm-2 col-xs-12 col-form-label">Text from</label>
            <div class="col-sm-10 col-xs-12">
                <textarea class="form-control" id="text_from" name="text_from"></textarea>
            </div>
        </div>
        <div class="form-group row">
            <label for="text_to" class="col-sm-2 col-xs-12 col-form-label">Text to</label>
            <div class="col-sm-10 col-xs-12">
                <textarea class="form-control" id="text_to" name="text_to"></textarea>
            </div>
        </div>
        <div class="form-group row">
            <div class="col-sm-12 col-xs-12 text-center">
                <button type="submit" class="btn btn-primary">Replace</button>
            </div>
        </div>
    </form>
    <h1 class="loader" style="display: none">
        <span>L</span>
        <span>O</span>
        <span>A</span>
        <span>D</span>
        <span>I</span>
        <span>N</span>
        <span>G</span>
    </h1>
    <div id="results"></div>
</div>
<script type="text/javascript" language="javascript">
    (function ($) {
        "use strict";
        $(document).ready(function () {
            $('.loader').fadeOut();
            $('#replace_text_run').submit(function (e) {
                e.preventDefault();
                $('#results').html('');
                $('.loader').fadeIn();
                var text_from = $('#text_from').val();
                var text_to = $('#text_to').val();
                $.ajax({
                    type: 'POST',
                    url: "<?php echo plugin_dir_url(__FILE__) . 'replace_text_run.php'; ?>",
                    data: {
                        text_from: text_from,
                        text_to: text_to,
                    },
                    cache: false,
                    success: function (data) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html(data);
                    },
                    error: function (xhr, str) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html('An error has occurred: ' + xhr.responseCode);
                    }
                });
            });
        });
    })(jQuery);
</script>
