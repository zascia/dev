<div class="btn-group" role="group" aria-label="Basic example">
    <a class="btn btn-primary <?php echo (!isset($_GET['offset'])) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked'); ?>">1 - 1000</a>
    <?php if ($published_posts > 1000) { ?>
        <a class="btn btn-primary <?php echo (isset($_GET['offset']) && $_GET['offset'] == 1000) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked&offset=1000'); ?>">1000 - 2000</a>
    <?php } if ($published_posts > 2000) { ?>
        <a class="btn btn-primary <?php echo (isset($_GET['offset']) && $_GET['offset'] == 2000) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked&offset=2000'); ?>">2000 - 3000</a>
    <?php } if ($published_posts > 3000) { ?>
        <a class="btn btn-primary <?php echo (isset($_GET['offset']) && $_GET['offset'] == 3000) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked&offset=3000'); ?>">3000 - 4000</a>
    <?php } if ($published_posts > 4000) { ?>
        <a class="btn btn-primary <?php echo (isset($_GET['offset']) && $_GET['offset'] == 4000) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked&offset=4000'); ?>">4000 - 5000</a>
    <?php } ?>
</div>
<br>
<br>
<br>