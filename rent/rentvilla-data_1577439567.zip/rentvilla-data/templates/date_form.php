<?php
if (isset($_POST['date_ids'])) {
    $date_ids = $_POST['date_ids'];
} else {
    $date_ids = '';
}
$current_time = current_time('d-m-Y');
?>
<div class="container">
    <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked'); ?>">< Back</a>
    <form action="javascript:void(null);" method="POST" id="date_run" class="form-horizontal">
        <legend class="text-center">Add Reservations date</legend>
        <div class="form-group row">
            <label for="check_in_date" class="col-sm-2 col-xs-12 col-form-label">Date from</label>
            <div class="col-sm-4 col-xs-12">
                <input class="form-control" type="date" value="<?php echo $current_time; ?>" id="check_in_date" name="check_in_date">
            </div>
            <label for="check_out_date" class="col-sm-2 col-xs-12 col-form-label">Date to</label>
            <div class="col-sm-4 col-xs-12">
                <input class="form-control" type="date" value="<?php echo $current_time; ?>" id="check_out_date" name="check_out_date">
            </div>
        </div>
        <div class="text-center">
            <button type="submit" class="btn btn-primary">Submit</button>
        </div>
    </form>
    <br>
    <br>
    <h1 class="loader" style="display: none">
        <span>L</span>
        <span>O</span>
        <span>A</span>
        <span>D</span>
        <span>I</span>
        <span>N</span>
        <span>G</span>
    </h1>
    <div id="results"></div>
</div>
<script type="text/javascript" language="javascript">
    (function ($) {
        "use strict";
        $(document).ready(function () {
            $('.loader').fadeOut();
            $('#date_run').submit(function (e) {
                e.preventDefault();
                $('#results').html('');
                $('.loader').fadeIn();
                var check_in_date = $('#check_in_date').val();
                var check_out_date = $('#check_out_date').val();
                $.ajax({
                    type: 'POST',
                    url: "<?php echo plugin_dir_url(__FILE__) . 'date_run.php'; ?>",
                    data: {
                        date_ids: <?php echo json_encode($date_ids); ?>,
                        check_in_date: check_in_date,
                        check_out_date: check_out_date,
                    },
                    cache: false,
                    success: function (data) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html(data);
                    },
                    error: function (xhr, str) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html('An error has occurred: ' + xhr.responseCode);
                    }
                });
            });
        });
    })(jQuery);
</script>
