<?php
/**
 * Plugin Name: AirBnB XML
 * Description: This plugin exports data from airbnb.com web-site via xml-file
 * Version: 0.1
 * Author: Developer
 */

define('AX_DIR', plugin_dir_path(__FILE__));

add_action( 'init', 'ax_activation' );
function ax_activation(){
  require_once AX_DIR . 'AirbnbDataGetter.php';
  require_once AX_DIR . 'AdminPage.php';
  require_once AX_DIR . 'XmlGenerator.php';
}

