'use strict';

let sending_data = {
    action: 'run_parsing',
};

jQuery(document).ready(function(){
    jQuery('#GetDataAirbnb').on('click', function(){
        jQuery.ajax({
            url: ajaxurl,
            method: "POST",
            data: sending_data,
            beforeSend: function () {
                jQuery('#GetDataAirbnb').attr('disabled', true);
                jQuery('#loader').show();
            },
            complete: function () {
                jQuery('#loader').hide();
                jQuery('#GetDataAirbnb').attr('disabled', false);
            }
        });
    });
});