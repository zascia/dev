<?php
if (isset($_POST['price_ids'])) {
    $price_ids = $_POST['price_ids'];
} else {
    $price_ids = '';
}
?>
<div class="container">
    <a class="btn btn-primary" href="<?php echo admin_url('admin.php?page=rentvilla_data_available_booked'); ?>">< Back</a>
    <form action="javascript:void(null);" method="POST" id="price_run" class="form-horizontal">
        <legend class="text-center">Change listings price</legend>
        <div class="form-group row">
            <label for="change_price" class="col-sm-2 col-xs-12 col-form-label">Price</label>
            <div class="col-sm-4 col-xs-12">
                <input class="form-control" type="number" value="" id="change_price" name="change_price">
            </div>
            <div class="col-sm-4 col-xs-12 text-center">
                <button type="submit" class="btn btn-primary">Submit</button>
            </div>
        </div>
    </form>
    <h1 class="loader" style="display: none">
        <span>L</span>
        <span>O</span>
        <span>A</span>
        <span>D</span>
        <span>I</span>
        <span>N</span>
        <span>G</span>
    </h1>
    <div id="results"></div>
</div>
<script type="text/javascript" language="javascript">
    (function ($) {
        "use strict";
        $(document).ready(function () {
            $('.loader').fadeOut();
            $('#price_run').submit(function (e) {
                e.preventDefault();
                $('#results').html('');
                $('.loader').fadeIn();
                var change_price = $('#change_price').val();
                $.ajax({
                    type: 'POST',
                    url: "<?php echo plugin_dir_url(__FILE__) . 'price_run.php'; ?>",
                    data: {
                        price_ids: <?php echo json_encode($price_ids); ?>,
                        change_price: change_price,
                    },
                    cache: false,
                    success: function (data) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html(data);
                    },
                    error: function (xhr, str) {
                        $('.loader').fadeOut();
                        $('html, body').animate({
                            scrollTop: $("#results").offset().top
                        }, 2000);
                        $('#results').html('An error has occurred: ' + xhr.responseCode);
                    }
                });
            });
        });
    })(jQuery);
</script>
