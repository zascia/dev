<?php

$variable = getcwd();
$path = substr($variable, 0, strpos($variable, "wp-content"));
//echo $path;
require_once( $path . 'wp-load.php' );
//require_once($_SERVER['DOCUMENT_ROOT'] . '/wp-load.php');

$price_ids = $_POST['price_ids'];
$change_price = $_POST['change_price'];
if (!empty($price_ids)) {
    $ids = explode(',', $price_ids);
    if (!empty($change_price)) { // homey_night_price
        foreach ($ids as $id) {
            if (!update_post_meta($id, 'homey_night_price', $change_price)) {
                add_post_meta($id, 'homey_night_price', $change_price);
            }
            echo '<div class="alert alert-success alert-dismissible">'
            . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
            . '<strong>Success!</strong> Update listing ' . get_the_title($id) . ' by price ' . $change_price . '.</div>';
        }
    } else {
        echo '<div class="alert alert-danger alert-dismissible">'
        . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
        . '<strong>Warning!</strong> Price value is empty.</div>';
    }
} else {
    echo '<div class="alert alert-danger alert-dismissible">'
    . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
    . '<strong>Warning!</strong> Listings data is empty.</div>';
}