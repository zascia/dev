<?php
if (isset($_GET['charts'])) {
    $charts = true;
} else {
    $charts = false;
}
$args = array(
    'post_type' => 'homey_reservation',
    'posts_per_page' => -1,
    'post_status' => 'publish',
);
$posts = get_posts($args);
//$posts = array_reverse($posts);
$draw_year = '';
$draw_month = '';
$draw_week = '';
$reservations = '';
$reservation_status_title = '["","Total", "Booked","Available","Under review","Declined","Cancelled","Waiting host payment verification"]';
$reservation_status_colors = 'colors: [
                    "#4990e2",
                    "#58cb5d",
                    "#d15959",
                    "#FFC107",
                    "#9a3970",
                    "#9a3971",
                    "#9a3972",
                ]';
foreach ($posts as $post) {
    setup_postdata($post);
    $reservation_checkin_date = get_post_meta($post->ID, 'reservation_checkin_date', true);
    $reservation_checkout_date = get_post_meta($post->ID, 'reservation_checkout_date', true);
    $reservation_listing_id = get_post_meta($post->ID, 'reservation_listing_id', true);
    $reservations .= '{"title": "' . get_the_title($post->ID) . ' ' . get_the_title($reservation_listing_id) . '","start": "' . $reservation_checkin_date . '","end": "' . $reservation_checkout_date . '","url": "' . get_edit_post_link($post->ID) . '"},';
}
wp_reset_postdata();

$today = current_time('Y-m-d');
$today_a = explode("-", $today);
$d = $today_a[2];
$m = $today_a[1];
$y = $today_a[0];

$w = 0;
for ($x = $d; $x >= 1; --$x) {
    $w++;
    $count_m = rentvilla_count_reservation_from_day($y, $m, $x);
    $draw_month .= '["' . $x . '.' . $m . '.' . $y . '",' . $count_m['total'] . ',' . $count_m['booked'] . ',' . $count_m['available'] . ',' . $count_m['under_review'] . ',' . $count_m['declined'] . ',' . $count_m['cancelled'] . ',' . $count_m['waiting_host_payment_verification'] . '],';
    if($w <= 7){
        $draw_week .= '["' . $x . '.' . $m . '.' . $y . '",' . $count_m['total'] . ',' . $count_m['booked'] . ',' . $count_m['available'] . ',' . $count_m['under_review'] . ',' . $count_m['declined'] . ',' . $count_m['cancelled'] . ',' . $count_m['waiting_host_payment_verification'] . '],';
    }
}
for ($i = $m; $i >= 1; --$i) {
    $count = rentvilla_count_reservation_from_month($y, $i);
    $t = $i . '.' . $y;
    $draw_year .= '["' . $t . '",' . $count['total'] . ',' . $count['booked'] . ',' . $count['available'] . ',' . $count['under_review'] . ',' . $count['declined'] . ',' . $count['cancelled'] . ',' . $count['waiting_host_payment_verification'] . '],';
    if ($i == 1) {
        $y = $y - 1;
        $m = 12 - $m;
    }
}
if ($m != 0) {
    for ($k = 12; $k >= 12 - $m; --$k) {
        $count = rentvilla_count_reservation_from_month($y, $k);
        $t = $k . '.' . $y;
        $draw_year .= '["' . $t . '",' . $count['total'] . ',' . $count['booked'] . ',' . $count['available'] . ',' . $count['under_review'] . ',' . $count['declined'] . ',' . $count['cancelled'] . ',' . $count['waiting_host_payment_verification'] . '],';
    }
}
?>
<h1><?php echo get_admin_page_title(); ?></h1>
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<a class="btn with-icon btn-primary <?php echo ($charts) ? '' : 'active'; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_statistics'); ?>"><i class="icon-calendar"></i> Calendar</a>
<a class="btn with-icon btn-primary <?php echo ($charts) ? 'active' : ''; ?>" href="<?php echo admin_url('admin.php?page=rentvilla_data_statistics&charts'); ?>"><i class="icon-chart-bar"></i> Chart bar</a>
<?php if ($charts) { ?>
    <div class="float-right charts-selector">
        <button class="btn btn-primary button_y active">Year</button>
        <button class="btn btn-primary button_m">Month</button>
        <button class="btn btn-primary button_w">Week</button>
    </div>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/chartist/0.10.1/chartist.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/plottable.js/2.2.0/plottable.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/plugins/export/export.css">
    <style>
        @-webkit-keyframes rotate-forever {
            0% {
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            100% {
                -webkit-transform: rotate(360deg);
                -moz-transform: rotate(360deg);
                -ms-transform: rotate(360deg);
                -o-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }
        @-moz-keyframes rotate-forever {
            0% {
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            100% {
                -webkit-transform: rotate(360deg);
                -moz-transform: rotate(360deg);
                -ms-transform: rotate(360deg);
                -o-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }
        @keyframes  rotate-forever {
            0% {
                -webkit-transform: rotate(0deg);
                -moz-transform: rotate(0deg);
                -ms-transform: rotate(0deg);
                -o-transform: rotate(0deg);
                transform: rotate(0deg);
            }
            100% {
                -webkit-transform: rotate(360deg);
                -moz-transform: rotate(360deg);
                -ms-transform: rotate(360deg);
                -o-transform: rotate(360deg);
                transform: rotate(360deg);
            }
        }
        .loading-spinner {
            -webkit-animation-duration: 0.75s;
            -moz-animation-duration: 0.75s;
            animation-duration: 0.75s;
            -webkit-animation-iteration-count: infinite;
            -moz-animation-iteration-count: infinite;
            animation-iteration-count: infinite;
            -webkit-animation-name: rotate-forever;
            -moz-animation-name: rotate-forever;
            animation-name: rotate-forever;
            -webkit-animation-timing-function: linear;
            -moz-animation-timing-function: linear;
            animation-timing-function: linear;
            height: 60px;
            width: 60px;
            border-radius: 50%;
            display: inline-block;
        }
    </style>
    <div class="app">
        <h1>Charts</h1>
        <center>
            <div class="charts" style="background: inherit;">
                <div data-duration="500" class="charts-loader enabled" style="display: none; position: relative; top: 170px; height: 0;">
                    <center>
                        <div class="loading-spinner" style="border: 3px solid #000000; border-right-color: transparent;"></div>
                    </center>
                </div>
                <div class="charts-chart">
                    <div id="charts_clicks" style="height: 400px;"></div>
                </div>
            </div>
        </center>
    </div>
    <script type="text/javascript" src="https://cdn.rawgit.com/Mikhus/canvas-gauges/gh-pages/download/2.1.2/all/gauge.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/chartist/0.10.1/chartist.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.4.0/Chart.min.js"></script>
    <script type="text/javascript" src="https://static.fusioncharts.com/code/latest/fusioncharts.js"></script>
    <script type="text/javascript" src="https://static.fusioncharts.com/code/latest/themes/fusioncharts.theme.fint.js"></script>
    <script type="text/javascript" src="https://www.google.com/jsapi"></script>
    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
    <script type="text/javascript">google.charts.load('current', {'packages': ['corechart', 'gauge', 'geochart', 'bar', 'line']})</script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/highcharts/5.0.7/highcharts.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/highcharts/5.0.7/js/modules/offline-exporting.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/highmaps/5.0.7/js/modules/map.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/highmaps/5.0.7/js/modules/data.js"></script>
    <script type="text/javascript" src="https://code.highcharts.com/mapdata/custom/world.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.2.6/raphael.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/justgage/1.2.2/justgage.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/raphael/2.2.6/raphael.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/plottable.js/2.8.0/plottable.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/progressbar.js/1.0.1/progressbar.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/d3/3.5.5/d3.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/c3/0.4.11/c3.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/echarts/3.6.2/echarts.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/amcharts.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/serial.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/plugins/export/export.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/amcharts/3.21.2/themes/light.js"></script>
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $('.charts').each(function () {
                var chart = $(this).find('.charts-chart');
                var loader = $(this).find('.charts-loader');
                var time = loader.data('duration');

                if (loader.hasClass('enabled')) {
                    chart.css({visibility: 'hidden'});
                    loader.fadeIn(350);

                    setTimeout(function () {
                        loader.fadeOut(350, function () {
                            chart.css({opacity: 0, visibility: 'visible'}).animate({opacity: 1}, 350);
                        });
                    }, time)
                }
            });

            $(".button_y").click(function () {
                $('.charts-selector .btn').removeClass('active');
                $(this).addClass('active');
                google.charts.setOnLoadCallback(draw_year);
            });
            $(".button_m").click(function () {
                $('.charts-selector .btn').removeClass('active');
                $(this).addClass('active');
                google.charts.setOnLoadCallback(draw_month);
            });
            $(".button_w").click(function () {
                $('.charts-selector .btn').removeClass('active');
                $(this).addClass('active');
                google.charts.setOnLoadCallback(draw_week);
            });
            google.charts.load('current', {'packages': ['bar']})
            var charts_clicks;
            google.charts.setOnLoadCallback(draw_year)

            function draw_year() {
                var data = google.visualization.arrayToDataTable([<?php echo $reservation_status_title; ?>,<?php echo $draw_year; ?>])

                var options = {
                    chart: {
                    },<?php echo $reservation_status_colors; ?>,
                };

                charts_clicks = new google.charts.Bar(document.getElementById("charts_clicks"))

                charts_clicks.draw(data, options)
            }
            function draw_month() {
                var data = google.visualization.arrayToDataTable([<?php echo $reservation_status_title; ?>,<?php echo $draw_month; ?>])

                var options = {
                    chart: {
                    },<?php echo $reservation_status_colors; ?>,
                };

                charts_clicks = new google.charts.Bar(document.getElementById("charts_clicks"))

                charts_clicks.draw(data, options)
            }
            function draw_week() {
                var data = google.visualization.arrayToDataTable([<?php echo $reservation_status_title; ?>,<?php echo $draw_week; ?>])

                var options = {
                    chart: {
                    },<?php echo $reservation_status_colors; ?>,
                };

                charts_clicks = new google.charts.Bar(document.getElementById("charts_clicks"));

                charts_clicks.draw(data, options)
            }
        })(jQuery);
    </script>
<?php } else { ?>
    <style>
        .locale-selector .select2-container {
            min-width: 90px;
            text-align: center;
        }
        /*        .fc-time, .fc-title {
                    color: #fff;
                }
                #calendar a:hover * {
                    color: #fd3300;
                } */
    </style>
    <div class="float-right locale-selector">
        <label for="locale-selector">Languages:</label>
        <div class="clearfix"></div>
        <select name="locale-selector" id="locale-selector" class="skin-select"></select>
    </div>
    <h1>Сalendar</h1>
    <div id='calendar'></div>
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.8.0/fullcalendar.min.css'/>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.20.1/moment.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.8.0/fullcalendar.min.js'></script>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.8.0/locale-all.js'></script>
    <script type="text/javascript">
        (function ($) {
            "use strict";
            $(document).ready(function () {
                var initialLocaleCode = 'en';
                var reservations = [<?php echo $reservations; ?>];
                $('#calendar').fullCalendar({
                    header: {
                        left: 'prevYear prev today next nextYear',
                        center: 'title',
                        right: 'year,month,agendaWeek,agendaDay listYear,listMonth,listWeek,listDay'
                    },
                    views: {
                        listDay: {buttonText: 'last day'},
                        listWeek: {buttonText: 'last week'},
                        listMonth: {buttonText: 'last month'},
                        listYear: {buttonText: 'last year'},
                    },
                    locale: initialLocaleCode,
                    weekNumbers: true,
                    navLinks: true,
                    editable: true,
                    eventLimit: true,
                    events: reservations,
                    eventClick: function (event) {
                        if (event.url) {
                            window.open(event.url, "_blank");
                            return false;
                        }
                    }
                });
                $.each($.fullCalendar.locales, function (localeCode) {
                    $('#locale-selector').append(
                            $('<option/>')
                            .attr('value', localeCode)
                            .prop('selected', localeCode == initialLocaleCode)
                            .text(localeCode)
                            );
                });
                $('#locale-selector').on('change', function () {
                    if (this.value) {
                        $('#calendar').fullCalendar('option', 'locale', this.value);
                    }
                });
            });
        })(jQuery);
    </script>
    <?php
}?>