<form action="<?php echo admin_url('admin.php?page=rentvilla_data_replace_text&find_text'); ?>" method="post" class="container">
    <legend class="text-center">Find Listings by text</legend>
    <div class="form-group row">
        <label for="check_in_date" class="col-sm-2 col-xs-12 col-form-label">Search text</label>
        <div class="col-sm-8 col-xs-12">
            <input class="form-control" type="text" value="<?php echo $text; ?>" id="search_text" name="search_text">
        </div>
        <div class="text-center col-sm-2 col-xs-12">
            <button type="submit" class="btn btn-primary">Find</button>
        </div>
    </div>
</form>
<br>
<br>