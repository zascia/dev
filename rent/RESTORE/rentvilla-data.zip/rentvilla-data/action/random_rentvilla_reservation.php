<?php

$variable = getcwd();
$path = substr($variable, 0, strpos($variable, "wp-content"));
//echo $path;
require_once( $path . 'wp-load.php' );
//require_once( $_SERVER['DOCUMENT_ROOT'] . '/wp-load.php' );
if (false) {
    $args = array(
        'post_type' => 'listing',
        'posts_per_page' => '-1'
    );
    $posts = get_posts($args);
    foreach ($posts as $post) {
        setup_postdata($post);
        $reservation_pending_dates = get_post_meta($post->ID, 'reservation_pending_dates', true);
        print_a($reservation_pending_dates);
        for ($index = 1879; $index < 2139; $index++) {
            if (in_array($index, $reservation_pending_dates)) {
                $reservation_pending_dates = [];
                update_post_meta($post->ID, 'reservation_pending_dates', $reservation_pending_dates);
                echo 'reservation_pending_dates ' . $post->ID . '<br>';
            }
        }
    }
    wp_reset_postdata();
} else {
    $reservation = get_posts(array(
        'fields' => 'ids', // Only get post IDs
        'posts_per_page' => -1,
        'post_type' => 'homey_reservation',
        'meta_key' => 'random_rentvilla_reservation',
        'meta_value' => 1,
        'suppress_filters' => true,
    ));

    foreach ($reservation as $postid) {
        $listing_id = get_post_meta($postid, 'reservation_listing_id', true);
        homey_remove_booking_booked_days($listing_id, $postid);
        homey_remove_booking_pending_days($listing_id, $postid);
        $deleted = wp_delete_post($postid, true);
        echo 'deleted ' . $deleted->post_title . '<br>';
    }
    $n_days = 10;
    $n_count = 10;
    $check_in_date = current_time('Y-m-d');
    $check_out_date = date("Y-m-d", strtotime($check_in_date . '+' . $n_days . 'day'));
    $guests = 2;
    $userID = 3;
    $local = homey_get_localization();


    $extra_options = '';
    $title = 'Reservation';
    $guest_message = $title . ' random';

//$owner = homey_usermeta($listing_owner_id);
//        $owner_email = $owner['email'];
    $owner_email = 'burhan.maxim@gmail.com';

    $listing = get_posts(array(
        'fields' => 'ids',
        'posts_per_page' => $n_count,
        'post_type' => 'listing',
        'suppress_filters' => true,
        'orderby' => 'rand'
    ));
    print_a($listing);
    foreach ($listing as $listing_id) {
        rentvilla_reservation($listing_id, $check_in_date, $check_out_date, $guests, $userID);
    }
}
