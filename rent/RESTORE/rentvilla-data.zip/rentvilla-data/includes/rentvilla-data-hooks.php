<?php

/**
 * The core hooks.
 */
function print_a($a) {
    if (!empty($a)) {
        echo '<pre>';
        print_r($a);
        echo '</pre>';
    } else {
        echo 'empty value';
    }
}

register_sidebar(array(
    'name' => 'Sidebar Destinations',
    'id' => 'sidebar-destinations',
    'description' => 'Default sidebar Destinations',
    'before_widget' => '<div id="%1$s" class="widget %2$s">',
    'after_widget' => '</div>',
    'before_title' => '<h4 class="widget-title">',
    'after_title' => '</h4>',
));

function homey_reservation_random_reservation_columns($columns) {
    $columns["random_reservation"] = "Generated";
    return $columns;
}

add_filter('manage_edit-homey_reservation_columns', 'homey_reservation_random_reservation_columns');
add_filter('manage_edit-homey_reservation_sortable_columns', 'homey_reservation_random_reservation_columns');

function homey_reservation_random_reservation_column_show($colname, $cptid) {
    if ($colname == 'random_reservation') {
        $random_rentvilla_reservation = get_post_meta($cptid, 'random_rentvilla_reservation', true);
        if (!empty($random_rentvilla_reservation)) {
            echo 'yes';
        } else {
            echo 'no';
        }
    }
}

add_action('manage_homey_reservation_posts_custom_column', 'homey_reservation_random_reservation_column_show', 10, 2);

function rentvilla_listing_columns($columns) {
    $columns["rentvilla_listing_parser"] = "Airbnb";
    return $columns;
}

add_filter('manage_edit-listing_columns', 'rentvilla_listing_columns');
add_filter('manage_edit-listing_sortable_columns', 'rentvilla_listing_columns');

function rentvilla_listing_column_show($colname, $cptid) {
    if ($colname == 'rentvilla_listing_parser') {
        $rentvilla_listing_parser = get_post_meta($cptid, 'rentvilla_listing_parser', true);
        if (!empty($rentvilla_listing_parser)) {
            echo 'airbnb';
        } else {
            echo 'custom';
        }
    }
}

add_action('manage_listing_posts_custom_column', 'rentvilla_listing_column_show', 10, 2);

function homey_reservation_sort_anguage($vars) {
    if (array_key_exists('orderby', $vars)) {
        if ('Random' == $vars['orderby']) {
            $vars['orderby'] = 'meta_value';
            $vars['meta_key'] = 'random_rentvilla_reservation';
        }
    }
    return $vars;
}

function rentvilla_count_reservation_from_month($year = null, $month = null) {
    $count = ['booked' => 0, 'available' => 0, 'under_review' => 0, 'declined' => 0, 'cancelled' => 0, 'waiting_host_payment_verification' => 0];
    $today = getdate();
    if (null == $year) {
        $year = $today['year'];
    }
    if (null == $month) {
        $month = $today['mon'];
    }
    $args = array(
        'year' => $year,
        'monthnum' => $month,
        'post_type' => 'homey_reservation',
        'posts_per_page' => -1,
    );

    $the_query = new WP_Query($args);
    $count['total'] = $the_query->post_count;
    while ($the_query->have_posts()) {
        $the_query->the_post();
        $id = get_the_ID();
        $reservation_status = get_post_meta($id, 'reservation_status', true);
        if ($reservation_status == 'booked') {
            $count['booked'] = $count['booked'] + 1;
        }
        if ($reservation_status == 'available') {
            $count['available'] = $count['available'] + 1;
        }
        if ($reservation_status == 'under_review') {
            $count['under_review'] = $count['under_review'] + 1;
        }
        if ($reservation_status == 'declined') {
            $count['declined'] = $count['declined'] + 1;
        }
        if ($reservation_status == 'cancelled') {
            $count['cancelled'] = $count['cancelled'] + 1;
        }
        if ($reservation_status == 'waiting_host_payment_verification') {
            $count['waiting_host_payment_verification'] = $count['waiting_host_payment_verification'] + 1;
        }
    }

    wp_reset_postdata();
    return $count;
}

function rentvilla_count_reservation_from_day($year = null, $month = null, $day = null) {
    $count = ['booked' => 0, 'available' => 0, 'under_review' => 0, 'declined' => 0, 'cancelled' => 0, 'waiting_host_payment_verification' => 0];
    $today = getdate();
    if (null == $year) {
        $year = $today['year'];
    }
    if (null == $month) {
        $month = $today['mon'];
    }
    if (null == $day) {
        $day = $today['mday'];
    }
    $args = array(
        'year' => $year,
        'monthnum' => $month,
        'day' => $day,
        'post_type' => 'homey_reservation',
        'posts_per_page' => -1,
    );

    $the_query = new WP_Query($args);
    $count['total'] = $the_query->post_count;
    while ($the_query->have_posts()) {
        $the_query->the_post();
        $id = get_the_ID();
        $reservation_status = get_post_meta($id, 'reservation_status', true);
        if ($reservation_status == 'booked') {
            $count['booked'] = $count['booked'] + 1;
        }
        if ($reservation_status == 'available') {
            $count['available'] = $count['available'] + 1;
        }
        if ($reservation_status == 'under_review') {
            $count['under_review'] = $count['under_review'] + 1;
        }
        if ($reservation_status == 'declined') {
            $count['declined'] = $count['declined'] + 1;
        }
        if ($reservation_status == 'cancelled') {
            $count['cancelled'] = $count['cancelled'] + 1;
        }
        if ($reservation_status == 'waiting_host_payment_verification') {
            $count['waiting_host_payment_verification'] = $count['waiting_host_payment_verification'] + 1;
        }
    }
    wp_reset_postdata();
    return $count;
}

if (!function_exists('check_listing_availability_for_rentvilla_data')) {

    function check_listing_availability_for_rentvilla_data($check_in_date, $check_out_date, $listing_id) {
        $return_array = array();
        $local = homey_get_localization();

        $reservation_booked_array = get_post_meta($listing_id, 'reservation_dates', true);
        if (empty($reservation_booked_array)) {
            $reservation_booked_array = homey_get_booked_days($listing_id);
        }

        $reservation_pending_array = get_post_meta($listing_id, 'reservation_pending_dates', true);
        if (empty($reservation_pending_array)) {
            $reservation_pending_array = homey_get_booking_pending_days($listing_id);
        }

        $reservation_unavailable_array = get_post_meta($listing_id, 'reservation_unavailable', true);
        if (empty($reservation_unavailable_array)) {
            $reservation_unavailable_array = array();
        }

        $check_in = new DateTime($check_in_date);
        $check_in_unix = $check_in->getTimestamp();

        $check_out = new DateTime($check_out_date);
        $check_out->modify('yesterday');
        $check_out_unix = $check_out->getTimestamp();

        while ($check_in_unix <= $check_out_unix) {

            if (array_key_exists($check_in_unix, $reservation_booked_array) || array_key_exists($check_in_unix, $reservation_pending_array) || array_key_exists($check_in_unix, $reservation_unavailable_array)) {

                return false; //dates are not available
            }
            $check_in->modify('tomorrow');
            $check_in_unix = $check_in->getTimestamp();
        }

        return true; //dates are available
    }

}

function rentvilla_reservation($listing_id, $check_in_date, $check_out_date, $guests, $userID, $alert = false) {
    $title = 'Reservation';
    $extra_options = '';
    $allowded_html = array();
    $reservation_meta = array();
    $listing_owner_id = get_post_field('post_author', $listing_id);
    $reservation_pending_dates = get_post_meta($listing_id, 'reservation_pending_dates');
    $check_availability = check_booking_availability($check_in_date, $check_out_date, $listing_id, $guests);
    $is_available = $check_availability['success'];
    $check_message = $check_availability['message'];

    if ($is_available) {
        $prices_array = homey_get_prices($check_in_date, $check_out_date, $listing_id, $guests, $extra_options);

        $reservation_meta['no_of_days'] = $prices_array['days_count'];
        $reservation_meta['additional_guests'] = $prices_array['additional_guests'];

        $upfront_payment = $prices_array['upfront_payment'];
        $balance = $prices_array['balance'];
        $total_price = $prices_array['total_price'];
        $price_per_night = $prices_array['price_per_night'];
        $nights_total_price = $prices_array['nights_total_price'];
        $cleaning_fee = $prices_array['cleaning_fee'];
        $city_fee = $prices_array['city_fee'];
        $services_fee = $prices_array['services_fee'];
        $days_count = $prices_array['days_count'];
        $period_days = $prices_array['period_days'];
        $taxes = $prices_array['taxes'];
        $taxes_percent = $prices_array['taxes_percent'];
        $security_deposit = $prices_array['security_deposit'];
        $additional_guests = $prices_array['additional_guests'];
        $additional_guests_price = $prices_array['additional_guests_price'];
        $additional_guests_total_price = $prices_array['additional_guests_total_price'];
        $booking_has_weekend = $prices_array['booking_has_weekend'];
        $booking_has_custom_pricing = $prices_array['booking_has_custom_pricing'];

        $reservation_meta['check_in_date'] = $check_in_date;
        $reservation_meta['check_out_date'] = $check_out_date;
        $reservation_meta['guests'] = $guests;
        $reservation_meta['listing_id'] = $listing_id;
        $reservation_meta['upfront'] = $upfront_payment;
        $reservation_meta['balance'] = $balance;
        $reservation_meta['total'] = $total_price;
        $reservation_meta['price_per_night'] = $price_per_night;
        $reservation_meta['nights_total_price'] = $nights_total_price;
        $reservation_meta['cleaning_fee'] = $cleaning_fee;
        $reservation_meta['city_fee'] = $city_fee;
        $reservation_meta['services_fee'] = $services_fee;
        $reservation_meta['period_days'] = $period_days;
        $reservation_meta['taxes'] = $taxes;
        $reservation_meta['taxes_percent'] = $taxes_percent;
        $reservation_meta['security_deposit'] = $security_deposit;
        $reservation_meta['additional_guests_price'] = $additional_guests_price;
        $reservation_meta['additional_guests_total_price'] = $additional_guests_total_price;
        $reservation_meta['booking_has_weekend'] = $booking_has_weekend;
        $reservation_meta['booking_has_custom_pricing'] = $booking_has_custom_pricing;

        $reservation = array(
            'post_title' => $title,
            'post_status' => 'publish',
            'post_type' => 'homey_reservation',
            'post_author' => $userID
        );
        $reservation_id = wp_insert_post($reservation);

        $reservation_update = array(
            'ID' => $reservation_id,
            'post_title' => $title . ' ' . $reservation_id
        );
        wp_update_post($reservation_update);

        update_post_meta($reservation_id, 'reservation_listing_id', $listing_id);
        update_post_meta($reservation_id, 'listing_owner', $listing_owner_id);
        update_post_meta($reservation_id, 'listing_renter', $userID);
        update_post_meta($reservation_id, 'reservation_checkin_date', $check_in_date);
        update_post_meta($reservation_id, 'reservation_checkout_date', $check_out_date);
        update_post_meta($reservation_id, 'reservation_guests', $guests);
        update_post_meta($reservation_id, 'reservation_meta', $reservation_meta);
        update_post_meta($reservation_id, 'reservation_status', 'booked');
        update_post_meta($reservation_id, 'is_hourly', 'no');
        update_post_meta($reservation_id, 'extra_options', $extra_options);

        update_post_meta($reservation_id, 'reservation_upfront', $upfront_payment);
        update_post_meta($reservation_id, 'reservation_balance', $balance);
        update_post_meta($reservation_id, 'reservation_total', $total_price);
        update_post_meta($reservation_id, 'random_rentvilla_reservation', 1);

        $pending_dates_array = homey_get_booking_pending_days($listing_id);
        update_post_meta($listing_id, 'reservation_pending_dates', $pending_dates_array);
        if ($alert) {
            echo '<div class="alert alert-success alert-dismissible">'
            . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
            . '<strong>Success!</strong> Update listing ' . get_the_title($listing_id) . ' by date ' . $check_in_date . ' to ' . $check_out_date . '.</div>';
        } else {
            echo json_encode(
                    array(
                        'success' => true,
                        'message' => $local['request_sent']
                    )
            ) . '<br>';
        }
//        do_action('homey_create_messages_thread', $guest_message, $reservation_id);
//
//        $message_link = homey_thread_link_after_reservation($reservation_id);
//        $email_args = array(
//            'reservation_detail_url' => reservation_detail_link($reservation_id),
//            'guest_message' => $guest_message,
//            'message_link' => $message_link
//        );
//        homey_email_composer($owner_email, 'new_reservation', $email_args);
//        wp_die();
    } else { // end $check_availability
        if ($alert) {
            echo '<div class="alert alert-danger alert-dismissible">'
            . '<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>'
            . '<strong>Warning!</strong> Not update listing ' . get_the_title($listing_id) . ': ' . $check_message . '.</div>';
        } else {
            echo json_encode(
                    array(
                        'success' => false,
                        'message' => $check_message
                    )
            ) . $listing_id . '<br>';
//        wp_die();
        }
    }
}

function rentvilla_replace_text($text_from, $text_to) {
    global $wpdb;
    $replace = $wpdb->query(
            $wpdb->prepare(
                    "UPDATE $wpdb->posts SET post_content = replace(post_content, %s, %s) WHERE post_type = 'listing'",
                    $text_from,
                    $text_to
            )
    );
    return $replace;
}

function rentvilla_result_text($text) {
    global $wpdb;
    $text_like = '%' . $wpdb->esc_like($text) . '%';
    $listings = $wpdb->get_results($wpdb->prepare(
                    "
	SELECT * 
	FROM $wpdb->posts
	WHERE post_status = 'publish' 
	AND post_type = 'listing' 
        AND post_content LIKE %s
	", $text_like
    ));
    return $listings;
}
