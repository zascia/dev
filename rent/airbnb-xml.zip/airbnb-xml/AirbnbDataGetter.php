<?php
require_once 'XmlGenerator.php';

class AirbnbDataGetter{

  public $key = 'd306zoyjsyarp7ifhu67rjxn52tv0t20';
  public $headers = [
    'User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; rv:9.0.1) Gecko/20100101 Firefox/9.0.1',
    'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language: ru-ru,ru;q=0.8,en-us;q=0.5,en;q=0.3',
    'Accept-Charset: windows-1251,utf-8;q=0.7,*;q=0.7',
    'Connection: keep-alive',
    'Cache-Control: no-cache',
  ];
  public $proxy = '192.169.215.114';
  public $port = '49035';
  public $items_per_request = 50;
  public $received_items = 0;
  public $proxy_data = 'https://www.proxy-list.download/api/v0/get?l=en&t=socks5';
  public $proxy_index = 0;
  public $services_end_point = "https://www.airbnb.com/api/v2/luxury_staff_services/";
  public $descriptions_end_point = "https://www.airbnb.com/api/v2/luxury_pdps/";

  public function get_listings_data() {
    $listings = array();

    $url_parameters = $this->get_listings_request_params();

    $request = curl_init();

    curl_setopt($request, CURLOPT_URL, "https://www.airbnb.com/api/v2/explore_tabs?".$url_parameters);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_PROXY, "$this->proxy:$this->port");
    curl_setopt($request, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($request, CURLOPT_HTTPHEADER, $this->headers);
    curl_setopt($request, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($request, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($request, CURLOPT_MAXREDIRS, 10 );
    curl_setopt($request, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    curl_setopt($request, CURLOPT_HEADER, false);

    $output = curl_exec($request);
    $output = json_decode($output, true);
    curl_close($request);

    if (isset($output['explore_tabs'][0])) {
      $ex_tab = $output['explore_tabs'][0];
      $items_offset = $ex_tab['pagination_metadata']['items_offset'];
      $has_next_page = $ex_tab['pagination_metadata']['has_next_page'];
      $response_listings = $ex_tab['sections'][0]['listings'];
      $response_listings_second = isset($ex_tab['sections'][2]['listings']) ? $ex_tab['sections'][2]['listings'] : false;
    }

    if (isset($items_offset)) {
      $this->received_items = $items_offset;
    }

    if (isset($response_listings)) {
      $listings[] = $response_listings;
      if ($response_listings_second) {
        $listings[] = $response_listings_second;
      }
    }

    if (isset($has_next_page) && ($has_next_page === false) ) return true; // || ($this->received_items >= 30)

    if (isset($has_next_page) && ($has_next_page === true)) {
      return $listings;
    }

    return false;
  }

  public function get_listings_request_params(){
    $url_parameters = 'auto_ib=true&currency=USD&';
    $url_parameters .= 'fetch_filters=true&guidebooks_per_grid=20&';
    $url_parameters .= 'has_zero_guest_treatment=true&is_guided_search=true&';
    $url_parameters .= 'is_new_cards_experiment=true&is_standard_search=true&';
    $url_parameters .= "items_offset=$this->received_items&items_per_grid=$this->items_per_request&";
    $url_parameters .= 'locale=en&metadata_only=false&';
    $url_parameters .= 'query_understanding_enabled=true&refinement_paths%5B%5D=%2Fluxury&';
    $url_parameters .= 'screen_size=large&section_offset=4&';
    $url_parameters .= 'show_groupings=true&supports_for_you_v3=true&';
    $url_parameters .= "tab_id=luxury&key=$this->key";

    return $url_parameters;
  }

  public function get_listings_descriptions($id){
    $params = "key=$this->key&_format=for_pdp_with_pricing";
    $listings_info = [];
    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, $this->descriptions_end_point . $id . '?' . $params);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_HEADER, false);
    $output = json_decode(curl_exec($request), true);
    curl_close($request);
    if (isset($output['luxury_pdp'])) {
      $listings_info['description'] = json_decode($output['luxury_pdp']['lr_listing_description_string'])->data;
      $listings_info['features'] = json_decode($output['luxury_pdp']['lr_listing_features_string'])->data;
      // get house amenities
      $listings_info['amenities'] = $output['luxury_pdp']['amenities']['items'];
      // get house rules
      if (isset($output['luxury_pdp']['cancellation_rules']['structured_house_rules'])) {
        $listings_info['structured_house_rules'] = $output['luxury_pdp']['cancellation_rules']['structured_house_rules'];
      } else {
        $listings_info['structured_house_rules'] = array();
      }
      // get house cancellation
      if (isset($output['luxury_pdp']['cancellation_rules']['cancellation_info'])) {
        $listings_info['cancellation_info'] = $output['luxury_pdp']['cancellation_rules']['cancellation_info'];
      } else {
        $listings_info['cancellation_info'] = array();
      }
    }
    return $listings_info;
  }

  public function get_listings_services($id){
    $params = "_format=staff_and_service_v2&currency=USD&key=$this->key&locale=en";
    $listings_services = [];
    $request = curl_init();
    curl_setopt($request, CURLOPT_URL, $this->services_end_point . $id . '?' . $params);
    curl_setopt($request, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($request, CURLOPT_HEADER, false);
    $output = json_decode(curl_exec($request), true);
    curl_close($request);
    if (isset($output['luxury_staff_service'])) {
      $listings_services = $output['luxury_staff_service'];
    }
    return $listings_services;
  }

  public function get_listings_external_info_via_proxy($id, $description = false, $services = false){
    if ($description) {
      $data = $this->get_listings_descriptions($id);
      if ($data === false) {
        while ($data === false) {
          $this->switch_proxy_server();
          $data = $this->get_listings_descriptions($id);
        }
      }
    } elseif ($services) {
      $data = $this->get_listings_services($id);
      if ($data === false) {
        while ($data === false) {
          $this->switch_proxy_server();
          $data = $this->get_listings_services($id);
        }
      }
    } else {
      return false;
    }
    return $data;
  }

  public function total_listing_comparing(){
    $basic_listings = $this->get_listings_data();

    if ($basic_listings === true) return true;

    if ($basic_listings === false) {
      while ($basic_listings === false) {
        $this->switch_proxy_server();
        $basic_listings = $this->get_listings_data();
      }
    }
    $total_listings = [];

    if ($basic_listings !== false) {
      foreach ($basic_listings as $listings) {
        if (is_array($listings)) {
          foreach ($listings as $listing) {
            if (isset($listing['listing']['public_address'])) {
              $state = $this->get_state_from_public_address($listing['listing']['public_address']);
            }

            $l_id = $listing['listing']['id'];
            $total_listings[$l_id]['id'] = $l_id;
            $total_listings[$l_id]['additional_info']        = $this->get_listings_external_info_via_proxy($l_id, true);
            $total_listings[$l_id]['services']               = $this->get_listings_external_info_via_proxy($l_id, false, true);
            $total_listings[$l_id]['name']                   = isset($listing['listing']['name']) ? $listing['listing']['name'] : '';
            $total_listings[$l_id]['pictures']               = isset($listing['listing']['picture_urls']) ? $listing['listing']['picture_urls'] : '';
            $total_listings[$l_id]['address']                = isset($listing['listing']['public_address']) ? $listing['listing']['public_address'] : '';
            $total_listings[$l_id]['city']                   = isset($listing['listing']['city']) ? $listing['listing']['city'] : '';
            $total_listings[$l_id]['state']                  = isset($state) ? $state : '';
            $total_listings[$l_id]['guest_label']            = isset($listing['listing']['guest_label']) ? $listing['listing']['guest_label'] : '';
            $total_listings[$l_id]['beds']                   = isset($listing['listing']['beds']) ? $listing['listing']['beds'] : '';
            $total_listings[$l_id]['bedrooms']               = isset($listing['listing']['bedrooms']) ? $listing['listing']['bedrooms'] : '';
            $total_listings[$l_id]['bedroom_label']          = isset($listing['listing']['bedroom_label']) ? $listing['listing']['bedroom_label'] : '';
            $total_listings[$l_id]['bed_label']              = isset($listing['listing']['bed_label']) ? $listing['listing']['bed_label'] : '';
            $total_listings[$l_id]['bathrooms']              = isset($listing['listing']['bathrooms']) ? $listing['listing']['bathrooms'] : '';
            $total_listings[$l_id]['lat']                    = isset($listing['listing']['lat']) ? $listing['listing']['lat'] : '';
            $total_listings[$l_id]['lng']                    = isset($listing['listing']['lng']) ? $listing['listing']['lng'] : '';
            $total_listings[$l_id]['localized_neighborhood'] = isset($listing['listing']['localized_neighborhood']) ? $listing['listing']['localized_neighborhood'] : '';
            $total_listings[$l_id]['person_capacity']        = isset($listing['listing']['person_capacity']) ? $listing['listing']['person_capacity'] : '';
            $total_listings[$l_id]['space_type']             = isset($listing['listing']['space_type']) ? $listing['listing']['space_type'] : '';
            $total_listings[$l_id]['min_nights']             = isset($listing['listing']['min_nights']) ? $listing['listing']['min_nights'] : '';
            $total_listings[$l_id]['max_nights']             = isset($listing['listing']['max_nights']) ? $listing['listing']['max_nights'] : '';
            $total_listings[$l_id]['can_instant_book']       = isset($listing['pricing_quote']['can_instant_book']) ? $listing['pricing_quote']['can_instant_book'] : '';
            $total_listings[$l_id]['monthly_price_factor']   = isset($listing['pricing_quote']['monthly_price_factor']) ? $listing['pricing_quote']['monthly_price_factor'] : '';
            $total_listings[$l_id]['price_string']           = isset($listing['pricing_quote']['price_string']) ? $listing['pricing_quote']['price_string'] : '';
            $total_listings[$l_id]['rate']                   = isset($listing['pricing_quote']['rate']) ? $listing['pricing_quote']['rate'] : '';
            $total_listings[$l_id]['rate_type']              = isset($listing['pricing_quote']['rate_type']) ? $listing['pricing_quote']['rate_type'] : '';
            $total_listings[$l_id]['rate_with_service_fee']  = isset($listing['pricing_quote']['rate_with_service_fee']) ? $listing['pricing_quote']['rate_with_service_fee'] : '';
            $total_listings[$l_id]['weekly_price_factor']    = isset($listing['pricing_quote']['weekly_price_factor']) ? $listing['pricing_quote']['weekly_price_factor'] : '';
            $total_listings[$l_id]['should_show_from_label'] = isset($listing['pricing_quote']['should_show_from_label']) ? $listing['pricing_quote']['should_show_from_label'] : '';
          }
        }
      }
      return $total_listings;
    }
    return false;
  }

  public function get_state_from_public_address($public_address){
    if (!empty($public_address)) {
      if (is_string($public_address)) {
        $address = explode(',', $public_address);
        if (count($address) > 2) {
          $state = trim($address[1]);
          return $state;
        }
      }
    }
    return false;
  }

  public function generate_xml_file(){
    $data = $this->total_listing_comparing();

    // Checking previous listings
    reset($data);
    $first_listing_id = key($data);
    $status = $this->check_listing_id_in_prev_files($first_listing_id);

    if ($data === true) return true;

    if ($status) return true;

    if ($data !== false) {
      new XmlGenerator($data, $this->received_items);
      sleep(30);
      $this->generate_xml_file();
    }

    return false;
  }

  public function switch_proxy_server(){
    $proxy_data = json_decode(file_get_contents($this->proxy_data), true);
    $proxies = $proxy_data[0]['LISTA'];
    if ($this->proxy !== $proxies[$this->proxy_index]['IP']) {
      $this->proxy = $proxies[$this->proxy_index]['IP'];
      $this->port = $proxies[$this->proxy_index]['PORT'];
    }else{
      ++$this->proxy_index;
      $this->proxy = $proxies[$this->proxy_index]['IP'];
      $this->port = $proxies[$this->proxy_index]['PORT'];
    }
    return true;
  }

  // Checks is exist id in previous file with listings
  public function check_listing_id_in_prev_files($id){
    $files_dir = plugin_dir_path( __FILE__ ).'/imported_listings/';
    $files = scandir($files_dir, 0);
    natcasesort($files);
    $last_file = array_pop($files);
    if (strlen($last_file) < 7) return false;
    $xml = file_get_contents($files_dir . '/' . $last_file);
    $obj_xml = new SimpleXMLElement($xml);
    $ids = $obj_xml->xpath('/listings/listing/listing_id');
    foreach ($ids as $id_element) {
      $str = $id_element->__toString();
      if ($str == $id) return true;
    }
    return false;
  }

}
