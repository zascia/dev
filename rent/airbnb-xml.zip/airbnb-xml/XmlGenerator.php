<?php

class XmlGenerator{
  public $data;
  public $xml_document;
  public $xml_number;

  public function __construct($data, $received_items){
    $this->data = $data;
    $this->xml_document = new DOMDocument('1.0', 'utf-8');
    $this->xml_number = $received_items;

    $this->generate_xml_document();
  }

  public function generate_xml_document(){
    $xml = $this->xml_document;
    $data = $this->data;

    $listings = $xml->appendChild($xml->createElement('listings'));
    foreach ($data as $d_listing) {

      //create listing
      $listing = $listings->appendChild($xml->createElement('listing'));

      //add listing's name
      $this->add_listing_name($listing, $d_listing['name']);

      //add listing's id
      $listing_id = $listing->appendChild($xml->createElement('listing_id'));
      $listing_id->appendChild($xml->createTextNode($d_listing['id']));

      //add listing's amenities
      $listing_amenities = $listing->appendChild($xml->createElement('listing_amenities'));
      if (isset($d_listing['additional_info']['amenities'])) {
        foreach ($d_listing['additional_info']['amenities'] as $amenity) {
          if(!empty($amenity)){
            $amenity_kit = $listing_amenities->appendChild($xml->createElement('amenity_kit'));
            $category = $amenity_kit->appendChild($xml->createElement('amenity_category'));
            $category->appendChild($xml->createTextNode($amenity['category']));
            if (is_array($amenity['amenities']) && !empty($amenity['amenities'])) {
              foreach ($amenity['amenities'] as $amenity_item) {
                $amenity_element = $amenity_kit->appendChild($xml->createElement('amenity'));
                $amenity_element->appendChild($xml->createTextNode($amenity_item['title']));
              }
            }
          }else{
            $listing_amenities->appendChild($xml->createTextNode(''));
          }
        }
      }

      //add listing's cancellation_info
      $listing_cancellation_info = $listing->appendChild($xml->createElement('listing_cancellation_info'));
      if (isset($d_listing['additional_info']['cancellation_info']['subtitles'])) {
        foreach ($d_listing['additional_info']['cancellation_info']['subtitles'] as $cancellation) {
          if(!empty($cancellation)){
            $cancellation_elem = $listing_cancellation_info->appendChild($xml->createElement('cancellation'));
            $cancellation_elem->appendChild($xml->createTextNode($cancellation));
          }else{
            $listing_amenities->appendChild($xml->createTextNode(''));
          }
        }
      }

      //add listing's services
      $listing_services = $listing->appendChild($xml->createElement('listing_services'));
      if (isset($d_listing['services'])) {
        foreach ($d_listing['services'] as $service_typename => $services_kit) {
          if(!empty($services_kit)){
            if (is_array($services_kit)) {
              if (is_array($services_kit['items']) && !empty($services_kit['items'])) {
                foreach ($services_kit['items'] as $service) {
                  $service_element = $listing_services->appendChild($xml->createElement('service'));
                  $service_name = $service_element->appendChild($xml->createElement('service_name'));
                  $service_name->appendChild($xml->createTextNode($service['title']));
                  $service_img = $service_element->appendChild($xml->createElement('service_img'));
                  if (isset($service['image']) && is_array($service['image'])){
                    $service_img->appendChild($xml->createTextNode($service['image']['image_url']));
                  } else {
                    $service_img->appendChild($xml->createTextNode(''));
                  }
                }
              }
            }

          }else{
            $listing_services->appendChild($xml->createTextNode(''));
          }
        }
      }

      //add listing's description
      $listing_description = $listing->appendChild($xml->createElement('listing_description'));
      if (isset($d_listing['additional_info']['description'])) {
        foreach ($d_listing['additional_info']['description'] as $description) {
          if(isset($description->text)){
            $listing_description->appendChild($xml->createTextNode($description->text));
          }else{
            $listing_description->appendChild($xml->createTextNode(''));
          }
        }
      }

      //add listing's features
      $listing_features = $listing->appendChild($xml->createElement('listing_features'));
      //add features one by one
      $feature = $listing_features->appendChild($xml->createElement('feature'));
      if (isset($d_listing['additional_info']['features'])) {
        foreach ($d_listing['additional_info']['features'] as $features) {
          switch ($features->type) {
            case 'bold_text':
              $bold_text = $feature->appendChild($xml->createElement('strong'));
              $bold_text->appendChild($xml->createTextNode($features->text));
              break;
            case 'horizontal_rule':
              $feature = $listing_features->appendChild($xml->createElement('feature'));
              break;
            case 'plain_text':
              $plain_text = $feature->appendChild($xml->createElement('p'));
              $plain_text->appendChild($xml->createTextNode($features->text));
              break;
            case 'bullets':
              $bullets = $feature->appendChild($xml->createElement('ul'));
              foreach ($features->items as $item) {
                $li = $bullets->appendChild($xml->createElement('li'));
                $li->appendChild($xml->createTextNode($item->text));
              }
              break;
          }
        }
      }

      //add listing's house rules
      $listing_house_rules = $listing->appendChild($xml->createElement('listing_house_rules'));
      if (isset($d_listing['additional_info']['structured_house_rules'])) {
        foreach ($d_listing['additional_info']['structured_house_rules'] as $rule) {
          if(!empty($rule)){
            $rule_tag = $listing_house_rules->appendChild($xml->createElement('rule'));
            $rule_tag->appendChild($xml->createTextNode($rule));
          }
        }
      }

      // adding listing's pictures
      $listing_pictures = $listing->appendChild($xml->createElement('listing_pictures'));
      foreach ($d_listing['pictures'] as $picture_link) {
        $picture = $listing_pictures->appendChild($xml->createElement('picture'));
        $picture->appendChild($xml->createTextNode($picture_link));
      }

      //add listing's address
      $listing_address = $listing->appendChild($xml->createElement('listing_address'));
      $listing_address->appendChild($xml->createTextNode($d_listing['address']));

      //add listing's city
      $listing_city = $listing->appendChild($xml->createElement('listing_city'));
      $listing_city->appendChild($xml->createTextNode($d_listing['city']));

      //add listing's state
      $listing_state = $listing->appendChild($xml->createElement('listing_state'));
      $listing_state->appendChild($xml->createTextNode($d_listing['state']));

      //add listing's guest_label
      $listing_guest_label = $listing->appendChild($xml->createElement('listing_guest_label'));
      $listing_guest_label->appendChild($xml->createTextNode($d_listing['guest_label']));

      //add listing's beds
      $listing_beds = $listing->appendChild($xml->createElement('listing_beds'));
      $listing_beds->appendChild($xml->createTextNode($d_listing['beds']));

      //add listing's bed_label
      $listing_bed_label = $listing->appendChild($xml->createElement('listing_bed_label'));
      $listing_bed_label->appendChild($xml->createTextNode($d_listing['bed_label']));

      //add listing's bedrooms
      $listing_bedrooms = $listing->appendChild($xml->createElement('listing_bedrooms'));
      $listing_bedrooms->appendChild($xml->createTextNode($d_listing['bedrooms']));

      //add listing's bedroom_label
      $listing_bedroom_label = $listing->appendChild($xml->createElement('listing_bedroom_label'));
      $listing_bedroom_label->appendChild($xml->createTextNode($d_listing['bedroom_label']));

      //add listing's bathrooms
      $listing_bathrooms = $listing->appendChild($xml->createElement('listing_bathrooms'));
      $listing_bathrooms->appendChild($xml->createTextNode($d_listing['bathrooms']));

      //add listing's latitude
      $listing_lat = $listing->appendChild($xml->createElement('listing_latitude'));
      $listing_lat->appendChild($xml->createTextNode($d_listing['lat']));

      //add listing's longitude
      $listing_lng = $listing->appendChild($xml->createElement('listing_longitude'));
      $listing_lng->appendChild($xml->createTextNode($d_listing['lng']));

      //add listing's localized_neighborhood
      $listing_localized_neighborhood = $listing->appendChild($xml->createElement('listing_localized_neighborhood'));
      $listing_localized_neighborhood->appendChild($xml->createTextNode($d_listing['localized_neighborhood']));

      //add listing's person_capacity
      $listing_person_capacity = $listing->appendChild($xml->createElement('listing_person_capacity'));
      $listing_person_capacity->appendChild($xml->createTextNode($d_listing['person_capacity']));

      //add listing's space_type
      $listing_space_type = $listing->appendChild($xml->createElement('listing_space_type'));
      $listing_space_type->appendChild($xml->createTextNode($d_listing['space_type']));

      //add listing's min_nights
      $listing_min_nights = $listing->appendChild($xml->createElement('listing_min_nights'));
      $listing_min_nights->appendChild($xml->createTextNode($d_listing['min_nights']));

      //add listing's max_nights
      $listing_max_nights = $listing->appendChild($xml->createElement('listing_max_nights'));
      $listing_max_nights->appendChild($xml->createTextNode($d_listing['max_nights']));

      //add listing's can_instant_book
      $listing_can_instant_book = $listing->appendChild($xml->createElement('listing_can_instant_book'));
      $listing_can_instant_book->appendChild($xml->createTextNode($d_listing['can_instant_book']));

      //add listing's monthly_price_factor
      $listing_monthly_price_factor = $listing->appendChild($xml->createElement('listing_monthly_price_factor'));
      $listing_monthly_price_factor->appendChild($xml->createTextNode($d_listing['monthly_price_factor']));

      //add listing's price_string
      $listing_price_string = $listing->appendChild($xml->createElement('listing_price_string'));
      $listing_price_string->appendChild($xml->createTextNode($d_listing['price_string']));

      //add listing's rate
      $listing_rate = $listing->appendChild($xml->createElement('listing_rate'));
      $listing_rate_amount = $listing_rate->appendChild($xml->createElement('amount'));
      $listing_rate_amount->appendChild($xml->createTextNode($d_listing['rate']['amount']));

      $listing_rate_amount_formatted = $listing_rate->appendChild($xml->createElement('amount_formatted'));
      $listing_rate_amount_formatted->appendChild($xml->createTextNode($d_listing['rate']['amount_formatted']));

      $listing_rate_currency = $listing_rate->appendChild($xml->createElement('currency'));
      $listing_rate_currency->appendChild($xml->createTextNode($d_listing['rate']['currency']));

      //add listing's rate_type
      $listing_rate_type = $listing->appendChild($xml->createElement('listing_rate_type'));
      $listing_rate_type->appendChild($xml->createTextNode($d_listing['rate_type']));

      //add listing's rate_with_service_fee
      $listing_rate_with_service_fee = $listing->appendChild($xml->createElement('listing_rate_with_service_fee'));
      $listing_rwsf_amount = $listing_rate_with_service_fee->appendChild($xml->createElement('amount'));
      $listing_rwsf_amount->appendChild($xml->createTextNode($d_listing['rate_with_service_fee']['amount']));

      $listing_rwsf_amount_formatted = $listing_rate_with_service_fee->appendChild($xml->createElement('amount_formatted'));
      $listing_rwsf_amount_formatted->appendChild($xml->createTextNode($d_listing['rate_with_service_fee']['amount_formatted']));

      $listing_rwsf_currency = $listing_rate_with_service_fee->appendChild($xml->createElement('currency'));
      $listing_rwsf_currency->appendChild($xml->createTextNode($d_listing['rate_with_service_fee']['currency']));

      //add listing's weekly_price_factor
      $listing_weekly_price_factor = $listing->appendChild($xml->createElement('listing_weekly_price_factor'));
      $listing_weekly_price_factor->appendChild($xml->createTextNode($d_listing['weekly_price_factor']));

      //add listing's should_show_from_label
      $listing_should_show_from_label = $listing->appendChild($xml->createElement('listing_should_show_from_label'));
      $listing_should_show_from_label->appendChild($xml->createTextNode($d_listing['should_show_from_label']));

    }

    $xml->formatOutput = true;
    $xml->save(plugin_dir_path( __FILE__ ).'/imported_listings/listings_'.$this->xml_number.'.xml');
  }

  public function add_listing_name(&$listing, $name){
    $listing_name = $listing->appendChild($this->xml_document->createElement('listing_name'));
    $listing_name->appendChild($this->xml_document->createTextNode($name));
  }

}