$(document).ready(function(){
    $( ".form-inner" ).load( "company-form.html" );
});